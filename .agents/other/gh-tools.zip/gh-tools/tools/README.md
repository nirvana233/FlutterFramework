# tools/

个人命令行工具的源码目录。

## refresh-gh-tools

刷新 Codex、Claude Code、WorkBuddy / CodeBuddy 中已经安装的本仓库插件，以及
Cursor / OpenCode / Kiro 的 skills 目录软链。默认只预览，
不会安装客户端、marketplace 或新插件，也不会直接编辑用户配置文件。

```bash
# 预览 Codex / Claude Code / WorkBuddy 刷新计划
refresh-gh-tools

# 实际刷新三端
refresh-gh-tools --apply

# 只刷新指定客户端（选择器可以组合）
refresh-gh-tools --codex --claude --apply

# 只同步 Cursor skills
refresh-gh-tools --cursor --apply

# 只同步 OpenCode skills（与 --cursor 同机制，目标是 ~/.config/opencode/skills/）
refresh-gh-tools --opencode --apply

# 只同步 Kiro skills（与 --cursor 同机制，目标是 ~/.kiro/skills/）
refresh-gh-tools --kiro --apply
```

Claude Code 和 WorkBuddy 使用各自的 `plugin update`。Codex 会先升级 `gh-tools`
marketplace snapshot，再重装当前已启用的已安装插件；已禁用插件会保留现状。Git 来源只能
刷新到已经推送的版本，本地开发来源仍按仓库根目录 README 配置。

Cursor 现在也有自己的 plugin 机制，但本仓库尚未提供 `.cursor-plugin/plugin.json`，因此
工具只提供 Agent Skills 目录同步，不负责 Cursor plugin / MCP / marketplace 安装。`--cursor`
会把仓库里
`plugins/**/skills/` 下的所有 skill 软链到 `~/.cursor/skills/`，并且只创建 / 更新 / 删除
指向本仓库的软链，不碰该目录下的其他内容（第三方 skill、普通文件一律不动）。git pull
之后重跑一次 `--cursor --apply` 即完成更新，改完 SKILL.md 立即生效，无需重启 Cursor 的
安装流程。链接类型区分 OS 平台：macOS/Linux 用符号链接，Windows 用 junction（免开发者
模式）。

OpenCode、Kiro 与 Cursor 共用同一套 Agent Skills 目录同步机制，只是目标目录不同：
OpenCode 是 `~/.config/opencode/skills/`，Kiro 是 `~/.kiro/skills/`，布局同样是
`<skill 名>/SKILL.md`。Kiro 的用户级目录由 Kiro IDE 与本机 `kiro-cli` 共用，项目级
`.kiro/skills/` 不在本工具范围内。三者的软链规则、不碰外部内容的边界与平台差异处理
和 `--cursor` 完全一致。

## 两条消费路径

**你自己用** — 脚本放这里并 `chmod +x`，然后：

```bash
node scripts/link-bin.mjs --apply
```

它会在 `bin/` 下建立入口（macOS/Linux 是软链，Windows 是 `.cmd` shim）。`bin/` 加进 PATH 后直接敲名字即可：

```bash
export PATH="$HOME/code/gh-tools/bin:$PATH"
```

**agent 用** — 裸脚本 agent 是发现不了的，它不会去猜你有什么工具。想让 agent 主动调用，得在某个 plugin 下写一个 skill 说明「什么时候该用这个工具、参数怎么给」，并在 frontmatter 里声明白名单：

```yaml
allowed-tools: Bash(foo:*)
```

两条路径共用同一份脚本源码，不需要复制。
