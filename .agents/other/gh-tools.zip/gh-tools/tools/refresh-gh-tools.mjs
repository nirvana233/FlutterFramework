#!/usr/bin/env node

import { accessSync, constants, existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, readlinkSync, realpathSync, renameSync, statSync, symlinkSync, unlinkSync } from 'node:fs'
import { randomUUID } from 'node:crypto'
import { basename, delimiter, dirname, isAbsolute, join, resolve, sep } from 'node:path'
import { homedir } from 'node:os'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const MARKETPLACE_PATH = join(ROOT, '.claude-plugin', 'marketplace.json')
const ALL_CLIENTS = ['codex', 'claude', 'workbuddy']
const OPTIONAL_CLIENTS = ['cursor', 'opencode', 'kiro']
const IS_WINDOWS = process.platform === 'win32'

/** Windows 上 junction 免开发者模式/管理员权限；POSIX 用普通符号链接 */
export function symlinkTypeFor(platform = process.platform) {
  return platform === 'win32' ? 'junction' : undefined
}

/** 软链目标比较用：junction 的 readlink 可能带 \\?\ 前缀、尾分隔符，且 Windows 大小写不敏感 */
function normalizeForCompare(path) {
  const normalized = resolve(path)
    .replace(/^\\\\\?\\/, '')
    .replace(/[\\/]+$/, '')
  return IS_WINDOWS ? normalized.toLowerCase() : normalized
}

const CLIENTS = {
  codex: {
    candidates: ['codex'],
    listArgs: (marketplace) => ['plugin', 'list', '--marketplace', marketplace, '--json'],
  },
  claude: {
    candidates: ['claude'],
    listArgs: () => ['plugin', 'list', '--json'],
  },
  workbuddy: {
    candidates: workbuddyCandidates(),
    listArgs: () => ['plugin', 'list', '--json'],
  },
  // Cursor、OpenCode 与 Kiro 都只作 Agent Skills 目录同步目标：各自扫描
  // <skillsDir>/<name>/SKILL.md，机制相同，目标目录不同。
  cursor: {
    skillsDir: join(homedir(), '.cursor', 'skills'),
  },
  opencode: {
    skillsDir: join(homedir(), '.config', 'opencode', 'skills'),
  },
  kiro: {
    skillsDir: join(homedir(), '.kiro', 'skills'),
  },
}

export function workbuddyCandidates(
  platform = process.platform,
  environment = process.env,
) {
  const candidates = ['workbuddy', 'codebuddy', 'cbc']
  if (platform === 'darwin') {
    candidates.push(
      '/Applications/WorkBuddy.app/Contents/Resources/app.asar.unpacked/cli/bin/codebuddy',
    )
  }
  if (platform === 'win32') {
    const roots = [
      environment.LOCALAPPDATA,
      environment.ProgramFiles,
      environment.ProgramW6432,
      environment['ProgramFiles(x86)'],
    ].filter(Boolean)
    for (const root of roots) {
      for (const product of ['WorkBuddy', 'CodeBuddy']) {
        candidates.push(
          join(root, product, 'resources', 'app.asar.unpacked', 'cli', 'bin', 'codebuddy'),
          join(root, 'Programs', product, 'resources', 'app.asar.unpacked', 'cli', 'bin', 'codebuddy'),
        )
      }
    }
  }
  return candidates
}

export function parseArgs(argv) {
  const selected = []
  let apply = false
  let help = false

  for (const arg of argv) {
    if (arg === '--apply') {
      apply = true
    } else if (arg === '--help' || arg === '-h') {
      help = true
    } else if (
      arg.startsWith('--') &&
      [...ALL_CLIENTS, ...OPTIONAL_CLIENTS].includes(arg.slice(2))
    ) {
      selected.push(arg.slice(2))
    } else {
      throw new Error(`未知参数：${arg}`)
    }
  }

  return {
    apply,
    help,
    clients: selected.length > 0 ? [...new Set(selected)] : [...ALL_CLIENTS],
    explicitClients: selected.length > 0,
  }
}

export function normalizeInstalled(client, payload) {
  const entries = client === 'codex' ? payload?.installed : payload
  if (!Array.isArray(entries)) {
    throw new Error(`${client} 的插件列表不是预期的 JSON 数组`)
  }

  return entries.map((entry) => ({
    id: entry.pluginId ?? entry.id ?? '',
    enabled: entry.enabled,
    scope: entry.scope ?? 'user',
    projectPath: entry.projectPath,
    marketplaceSourceType: entry.marketplaceSource?.sourceType,
  }))
}

export function selectMarketplacePlugins(entries, marketplace, repositoryPluginNames) {
  const suffix = `@${marketplace}`
  const repositoryNames = new Set(repositoryPluginNames)
  const selected = []
  const stale = []

  for (const entry of entries) {
    if (!entry.id.endsWith(suffix)) continue
    const name = entry.id.slice(0, -suffix.length)
    if (!repositoryNames.has(name)) {
      stale.push(entry)
      continue
    }
    selected.push({ ...entry, name })
  }

  return { selected, stale }
}

export function buildActions(client, plugins, marketplace) {
  if (client === 'codex') {
    const enabled = plugins.filter((plugin) => plugin.enabled !== false)
    return [
      {
        kind: 'upgrade',
        args: ['plugin', 'marketplace', 'upgrade', marketplace, '--json'],
      },
      ...enabled.flatMap((plugin) => [
        {
          kind: 'remove',
          pluginId: plugin.id,
          args: ['plugin', 'remove', plugin.id, '--json'],
        },
        {
          kind: 'add',
          pluginId: plugin.id,
          args: ['plugin', 'add', plugin.id, '--json'],
        },
      ]),
    ]
  }

  return plugins.map((plugin) => ({
    kind: 'update',
    pluginId: plugin.id,
    args: ['plugin', 'update', '--scope', plugin.scope, plugin.id],
    cwd: plugin.projectPath,
  }))
}

/** 递归收集 plugins/ 下所有 skills/<名>/SKILL.md，返回 [{ name, path }] */
export function collectSkills(root) {
  const skillsRoot = join(root, 'plugins')
  const found = []

  const walk = (dir) => {
    for (const name of readdirSync(dir)) {
      if (name.startsWith('.')) continue
      const path = join(dir, name)
      let st
      try {
        st = statSync(path)
      } catch {
        continue
      }
      if (!st.isDirectory()) continue
      if (name === 'skills') {
        for (const skill of readdirSync(path)) {
          if (skill.startsWith('.')) continue
          const skillPath = join(path, skill)
          if (existsSync(join(skillPath, 'SKILL.md'))) {
            found.push({ name: skill, path: skillPath })
          }
        }
        continue
      }
      walk(path)
    }
  }

  walk(skillsRoot)
  return found.sort((a, b) => a.name.localeCompare(b.name))
}

function isInsideRoot(path, root) {
  return path === root || path.startsWith(root + sep)
}

/**
 * 对比 skills 目录现状与仓库 skill，生成同步动作。
 * 只动指向本仓库的软链；外部软链和普通文件一律不碰。
 */
export function planCursorActions(repoSkills, skillsDir, root = ROOT) {
  const desired = new Map(repoSkills.map((skill) => [resolve(skill.path), skill]))
  const desiredByName = new Map(repoSkills.map((skill) => [skill.name, skill]))
  const actions = []
  const conflicts = []

  const entries = existsSync(skillsDir) ? readdirSync(skillsDir) : []
  for (const name of entries) {
    const linkPath = join(skillsDir, name)
    let st
    try {
      st = lstatSync(linkPath)
    } catch {
      continue
    }

    const source = desiredByName.has(name) ? resolve(desiredByName.get(name).path) : null
    if (!st.isSymbolicLink()) {
      conflicts.push({ name, linkPath })
      if (source) desired.delete(source)
      continue
    }

    let current
    try {
      current = resolve(skillsDir, readlinkSync(linkPath))
    } catch {
      current = null
    }

    if (!source) {
      // 仓库已删除该 skill：只有指向本仓库的链才归我们清理
      if (
        current &&
        isInsideRoot(normalizeForCompare(current), normalizeForCompare(root))
      ) {
        actions.push({ kind: 'remove', name, linkPath })
      }
      continue
    }

    if (current && !isInsideRoot(normalizeForCompare(current), normalizeForCompare(root))) {
      conflicts.push({
        name,
        linkPath,
        reason: '已有指向仓库外部的软链，未改动',
      })
      desired.delete(source)
      continue
    }

    desired.delete(source)
    if (!current || normalizeForCompare(current) !== normalizeForCompare(source)) {
      actions.push({ kind: 'relink', name, linkPath, target: source })
    }
  }

  for (const [source, skill] of desired) {
    actions.push({
      kind: 'create',
      name: skill.name,
      linkPath: join(skillsDir, skill.name),
      target: source,
    })
  }

  return { actions, conflicts }
}

/** 执行光标同步动作，返回失败数 */
function createCursorLink(target, linkPath) {
  const temporaryPath = `${linkPath}.gh-tools-${randomUUID()}`
  symlinkSync(target, temporaryPath, symlinkTypeFor())

  try {
    renameSync(temporaryPath, linkPath)
  } catch (error) {
    // POSIX rename replaces a symlink atomically. Windows may reject the
    // destination, so move it aside first and restore it if replacement fails.
    const backupPath = `${linkPath}.gh-tools-backup-${randomUUID()}`
    let movedExisting = false
    try {
      renameSync(linkPath, backupPath)
      movedExisting = true
      renameSync(temporaryPath, linkPath)
      unlinkSync(backupPath)
    } catch (replacementError) {
      try {
        if (existsSync(temporaryPath)) unlinkSync(temporaryPath)
        if (movedExisting && !existsSync(linkPath)) renameSync(backupPath, linkPath)
      } catch {
        // Keep the original replacement error as the actionable failure.
      }
      throw replacementError
    }
    if (existsSync(temporaryPath)) unlinkSync(temporaryPath)
  }
}

function applyCursorActions(actions, skillsDir, client) {
  let failures = 0
  try {
    mkdirSync(skillsDir, { recursive: true })
  } catch (error) {
    console.error(`error ${client}: 无法创建 ${skillsDir}：${error.message}`)
    return 1
  }

  for (const action of actions) {
    try {
      if (action.kind === 'remove') {
        unlinkSync(action.linkPath)
      } else {
        createCursorLink(action.target, action.linkPath)
      }
      console.log(`link  ${action.linkPath} -> ${action.target}`)
    } catch (e) {
      failures += 1
      if (e.code === 'EPERM') {
        console.error(
          `error ${action.linkPath}：创建链接被系统拒绝（${e.message}）。` +
            `Windows 已默认使用 junction（免提权），此错误通常意味着目录被占用或策略限制，请检查后重试。`,
        )
      } else {
        console.error(`error ${action.linkPath}：${e.message}`)
      }
    }
  }

  return failures
}

function readMarketplace() {
  let marketplace
  try {
    marketplace = JSON.parse(readFileSync(MARKETPLACE_PATH, 'utf8'))
  } catch (error) {
    throw new Error(`无法读取 ${MARKETPLACE_PATH}：${error.message}`)
  }

  if (!marketplace.name || !Array.isArray(marketplace.plugins)) {
    throw new Error(`${MARKETPLACE_PATH} 缺少 name 或 plugins`)
  }

  return {
    name: marketplace.name,
    version: marketplace.metadata?.version ?? 'unknown',
    pluginNames: marketplace.plugins.map((plugin) => plugin.name).filter(Boolean),
  }
}

export function expandExecutableCandidates(
  candidate,
  platform = process.platform,
  pathExt = process.env.PATHEXT,
) {
  if (platform !== 'win32' || /\.[^\\/]+$/.test(candidate)) return [candidate]
  const extensions = (pathExt || '.EXE;.CMD;.BAT;.COM')
    .split(';')
    .filter(Boolean)
    .map((extension) => extension.toLowerCase())
  return [candidate, ...extensions.map((extension) => `${candidate}${extension}`)]
}

export function findExecutable(
  candidates,
  envPath = process.env.PATH ?? process.env.Path ?? '',
  platform = process.platform,
) {
  for (const candidate of candidates) {
    for (const executableCandidate of expandExecutableCandidates(candidate, platform)) {
      if (executableCandidate.includes('/') || isAbsolute(executableCandidate)) {
        if (isExecutable(executableCandidate, platform)) return executableCandidate
        continue
      }

      for (const directory of envPath.split(delimiter)) {
        if (!directory) continue
        const path = join(directory, executableCandidate)
        if (isExecutable(path, platform)) return path
      }
    }
  }
  return null
}

function isExecutable(path, platform = process.platform) {
  if (platform === 'win32') {
    try {
      return statSync(path).isFile()
    } catch {
      return false
    }
  }
  try {
    accessSync(path, constants.X_OK)
    return true
  } catch {
    return false
  }
}

export function needsWindowsShell(executable, platform = process.platform) {
  return platform === 'win32' && /\.(?:cmd|bat)$/i.test(executable)
}

function run(executable, args, options = {}) {
  return spawnSync(executable, args, {
    cwd: options.cwd ?? ROOT,
    encoding: 'utf8',
    stdio: options.inherit ? 'inherit' : 'pipe',
    // Windows 无法直接通过 CreateProcess 启动 .cmd/.bat；客户端由本机 PATH
    // 或受信任的安装目录解析，参数也只来自仓库清单和客户端插件列表。
    shell: needsWindowsShell(executable),
  })
}

function parseCommandJson(client, executable, args) {
  const result = run(executable, args)
  if (result.error) throw result.error
  if (result.status !== 0) {
    const detail = result.stderr?.trim() || result.stdout?.trim() || `退出码 ${result.status}`
    throw new Error(detail)
  }
  try {
    return JSON.parse(result.stdout)
  } catch (error) {
    throw new Error(`${client} 返回了无效 JSON：${error.message}`)
  }
}

function quote(value) {
  if (/^[A-Za-z0-9_./:@=-]+$/.test(value)) return value
  return `'${value.replaceAll("'", "'\\''")}'`
}

function formatCommand(executable, action) {
  const command = [quote(basename(executable)), ...action.args.map(quote)].join(' ')
  return action.cwd ? `(cd ${quote(action.cwd)} && ${command})` : command
}

function printHelp() {
  console.log(`刷新本仓库已安装的 gh-tools 插件快照。

用法：
  refresh-gh-tools                         预览所有已检测客户端
  refresh-gh-tools --apply                 实际刷新
  refresh-gh-tools --codex --claude        只处理指定客户端

选项：
  --apply       执行刷新；省略时只打印计划
  --codex       处理 Codex
  --claude      处理 Claude Code
  --workbuddy   处理 WorkBuddy / CodeBuddy
  --cursor      把仓库 skill 软链到 ~/.cursor/skills/（当前仅同步 skills）
  --opencode    把仓库 skill 软链到 ~/.config/opencode/skills/（与 --cursor 同机制）
  --kiro        把仓库 skill 软链到 ~/.kiro/skills/（与 --cursor 同机制）
  -h, --help    显示帮助

说明：只刷新已经安装且仍存在于仓库清单中的插件，不安装客户端、marketplace
或新插件，也不直接编辑用户配置文件。Cursor / OpenCode / Kiro 走 skills 目录同步：
只在各自 skills 目录下创建/更新/删除指向本仓库的软链，不碰其他内容。
Git marketplace 只能刷新到已经推送的版本。`)
}

function executeActions(client, executable, actions) {
  let failures = 0
  let codexRemoveFailed = false

  for (const action of actions) {
    if (client === 'codex' && action.kind === 'add' && codexRemoveFailed) {
      console.warn(`skip  codex: ${action.pluginId} 的移除未成功，不继续安装`)
      codexRemoveFailed = false
      continue
    }

    console.log(`run   ${formatCommand(executable, action)}`)
    const result = run(executable, action.args, { cwd: action.cwd, inherit: true })
    if (!result.error && result.status === 0) {
      if (client === 'codex' && action.kind === 'remove') codexRemoveFailed = false
      continue
    }

    failures += 1
    console.error(
      `error ${client}: ${action.pluginId ?? action.kind} 刷新失败` +
        (result.error ? `：${result.error.message}` : `（退出码 ${result.status}）`),
    )

    if (client === 'codex' && action.kind === 'upgrade') break
    if (client === 'codex' && action.kind === 'remove') codexRemoveFailed = true
  }

  return failures
}

export function main(argv = process.argv.slice(2)) {
  let options
  try {
    options = parseArgs(argv)
  } catch (error) {
    console.error(`error ${error.message}`)
    console.error('运行 refresh-gh-tools --help 查看用法。')
    return 2
  }

  if (options.help) {
    printHelp()
    return 0
  }

  let marketplace
  try {
    marketplace = readMarketplace()
  } catch (error) {
    console.error(`error ${error.message}`)
    return 1
  }

  console.log(
    `${options.apply ? '刷新' : '预览'} ${marketplace.name} ${marketplace.version}：` +
      `${options.clients.join(', ')}`,
  )

  let planned = 0
  let failures = 0

  for (const client of options.clients) {
    const definition = CLIENTS[client]

    if (definition.skillsDir) {
      let repoSkills
      try {
        repoSkills = collectSkills(ROOT)
      } catch (error) {
        console.error(`error ${client}: 无法扫描仓库 skills：${error.message}`)
        failures += 1
        continue
      }
      const byName = new Map()
      let clash = false
      for (const skill of repoSkills) {
        const existing = byName.get(skill.name)
        if (existing) {
          console.error(`error ${client}: ${existing.path} 与 ${skill.path} 的 skill 同名（${skill.name}），请先解决冲突`)
          clash = true
        }
        byName.set(skill.name, skill)
      }
      if (clash) {
        failures += 1
        continue
      }

      const { actions, conflicts } = planCursorActions(repoSkills, definition.skillsDir)
      for (const conflict of conflicts) {
        console.warn(`skip  ${client}: ${conflict.linkPath} ${conflict.reason ?? '已存在且未改动'}`)
      }
      if (actions.length === 0) {
        console.log(`skip  ${client}: ${definition.skillsDir} 已是最新（${repoSkills.length} 个 skill）`)
        continue
      }
      planned += actions.length
      console.log(`${client}: ${repoSkills.length} 个仓库 skill，${actions.length} 项同步`)
      if (!options.apply) {
        for (const action of actions) {
          const verb = action.kind === 'remove' ? '删除' : action.kind === 'relink' ? '更新' : '创建'
          console.log(`plan  ${verb} ${action.linkPath} -> ${action.target}`)
        }
      } else {
        failures += applyCursorActions(actions, definition.skillsDir, client)
      }
      continue
    }

    const executable = findExecutable(definition.candidates)
    if (!executable) {
      console.warn(`skip  ${client}: 未找到客户端`)
      if (options.explicitClients) failures += 1
      continue
    }

    let entries
    try {
      const payload = parseCommandJson(
        client,
        executable,
        definition.listArgs(marketplace.name),
      )
      entries = normalizeInstalled(client, payload)
    } catch (error) {
      console.warn(`skip  ${client}: 无法读取已安装插件（${error.message}）`)
      if (options.explicitClients) failures += 1
      continue
    }

    const { selected, stale } = selectMarketplacePlugins(
      entries,
      marketplace.name,
      marketplace.pluginNames,
    )
    for (const plugin of stale) {
      console.warn(`skip  ${client}: ${plugin.id} 已不在仓库清单中`)
    }

    if (selected.length === 0) {
      console.log(`skip  ${client}: 没有已安装的 ${marketplace.name} 插件`)
      continue
    }

    if (
      client === 'codex' &&
      selected.every((plugin) => plugin.marketplaceSourceType === 'local')
    ) {
      console.log('skip  codex: local marketplace 已直接读取工作区；开启新任务即可生效')
      continue
    }

    if (client === 'codex') {
      for (const plugin of selected.filter((item) => item.enabled === false)) {
        console.warn(`skip  codex: ${plugin.id} 当前已禁用，保留其启用状态`)
      }
    }

    const actions = buildActions(client, selected, marketplace.name)
    if (actions.length === 1 && client === 'codex') {
      console.log(`skip  codex: 没有可安全重装的已启用插件`)
      continue
    }

    planned += actions.filter((action) => action.kind !== 'upgrade').length
    console.log(`${client}: ${selected.length} 个已安装插件`)

    if (!options.apply) {
      for (const action of actions) console.log(`plan  ${formatCommand(executable, action)}`)
      continue
    }

    failures += executeActions(client, executable, actions)
  }

  if (!options.apply) {
    console.log(`\n预览完成：${planned} 个插件操作。加 --apply 实际刷新。`)
  } else if (failures === 0) {
    console.log(`\n刷新完成：${planned} 个插件操作。请重启客户端或开启新任务。`)
  } else {
    console.error(`\n刷新结束：${failures} 个操作失败，其余客户端已继续处理。`)
  }

  return failures === 0 ? 0 : 1
}

if (process.argv[1] && realpathSync(process.argv[1]) === fileURLToPath(import.meta.url)) {
  process.exitCode = main()
}
