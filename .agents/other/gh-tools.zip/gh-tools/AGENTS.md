# AGENTS.md

给在本仓库工作的 agent 看的结构约定。

## 默认行为准则

处理本仓库任务时，先加载并遵循 [gh-supervisor](plugins/common/supervisor/skills/gh-supervisor/SKILL.md)；当前上下文已有完整正文时直接沿用。行为对照实验中的加载范围按下文 L2 要求执行。

## 协作入口

用户明确要求多代理协作时，加载并遵循 [gh-subagents](plugins/common/subagents/skills/gh-subagents/SKILL.md) 中的协作规则与模型建议，当前上下文已有完整正文时直接沿用。用户明确配置优先；原生自动分派保持原有适用边界。行为对照实验中的目标 Skill 加载范围按下文 L2 要求执行。

## 这是什么

一个多平台 plugin marketplace（Claude Code + Codex）+ 个人命令行工具集。权威源分两层：根目录的 `.claude-plugin/marketplace.json` 定插件列表（Claude Code 直接读它），各插件自己的 `.claude-plugin/plugin.json` 定该插件的 `description`。Codex 读的 `.agents/plugins/marketplace.json`、以及散落在清单与 Codex plugin.json 里的 description 副本，都由生成器产出。`plugins/` 按领域分组存放插件，`tools/` 存放个人脚本。

## 目录

```text
.claude-plugin/marketplace.json   权威清单：插件列表手写，description 由生成器从各 plugin.json 派生
.agents/plugins/marketplace.json  Codex 读的清单，整份由生成器产出，不要手改
plugins/common/                   通用插件
  <插件名>/.claude-plugin/plugin.json   插件配置；其中 description 是权威源
  <插件名>/.codex-plugin/plugin.json    Codex 插件配置；description 由生成器派生
  <插件名>/skills/<skill>/SKILL.md      skill 正文（两平台共用）
  <插件名>/skills/<skill>/agents/openai.yaml  Codex 专属配置
  <插件名>/skills/<skill>/test-prompts.json   行为实测语料（见「改动分级验证」）
  <插件名>/commands/<命令>.md           slash command（仅 Claude Code）
plugins/flutter/                  Flutter 专属插件
plugins/web/                      Web 专属插件
tools/                            个人命令行工具源码
bin/                              link-bin.mjs 生成的命令入口，不入库
scripts/                          仓库自用脚本（Node，ESM，.mjs）
  validate.mjs                    清单与安装文档的结构校验（提交前必跑）
  validate.test.mjs               校验的回归测试（复制仓库树当夹具 + 负例）
  sync-install-docs.mjs           生成器：Codex 清单 + 两处安装片段 + README 的 sync 区块 + 各 description 副本
docs/settings-snippet.json        Claude Code 团队安装配置片段
docs/codex-config-snippet.toml    Codex 团队安装配置片段
```

## 硬性约束

**全仓库统一版本。** 权威清单的 `metadata.version` 与其中每个 plugin 的 `version`、以及每个 `.claude-plugin/plugin.json` 和 `.codex-plugin/plugin.json` 的 `version` 必须全部相同。改版本号时一个都不能漏，`scripts/validate.mjs` 会拦。

**Codex 清单是生成物，不要手改。** `.agents/plugins/marketplace.json` 的每个字段都能从权威清单推出来（`name` / `interface` 取自市场名，`source.path` 取清单里的 `source`），`validate.mjs` 逐字节比对，手改必被拦。要调 Codex 侧独有的取值——`category` 对照表、`policy`——改 `scripts/sync-install-docs.mjs` 顶部那两个常量，不要改生成结果。

**每个 plugin 必须同时有两个配置文件。** `.claude-plugin/plugin.json` 和 `.codex-plugin/plugin.json`，validate 会检查。

**每个 skill 必须有 `agents/openai.yaml`。** Codex 需要这个文件，validate 会检查。

**skill 目录名必须等于 frontmatter 的 `name`。** 路径固定为 `plugins/<领域>/<插件>/skills/<skill 名>/SKILL.md`。

**插件与 Skill 统一使用 `gh-` 完整名称。** 插件安装名、Skill 目录名、frontmatter `name` 及显式调用名保持一致；命令文件也使用同名入口。显示名保留完整名称，可追加 ` · 中文说明`；Codex 插件与 Skill 的显示名、Claude Code command 的 `description` 使用同一文案。功能词写完整（如 `generation`、`initialization`、`compatibility`），不注册简称或别名。市场名 `gh-tools` 不能替代列表中的名称辨识。

**第三方 skill 不进本仓库。** 那些由 cc-switch 管理。本仓库只放自建内容。

**安装文档、description 副本与 Codex 清单都是生成的，不要手抄。** 生成物由 `scripts/sync-install-docs.mjs` 产出：`.agents/plugins/marketplace.json`、`docs/settings-snippet.json`、`docs/codex-config-snippet.toml`、`README.md` 的几个 `<!-- sync:begin ... -->` 区块，以及**清单条目和各 `.codex-plugin/plugin.json` 里的 `description`**。改完源后跑：

```bash
node scripts/sync-install-docs.mjs --apply
```

`validate.mjs` 会拦下没重新生成的生成物，所以漏不了。**需要手写的只剩三处**：

- 各插件自己 `.claude-plugin/plugin.json` 里的 `description`——这是描述的唯一来源，清单条目和 Codex 副本都逐字复制它；
- README「插件清单」表格的说明文案——插件名与顺序由校验核对，文案是给人读的中文说明，没有机械来源；
- Codex 侧独有的取值（`category` 对照、`policy`），集中在生成器顶部的常量里。

description 的派生是**字段级替换**：只改那一个值，`keywords` 数组的写法、缩进、键顺序一个字节都不动。所以别用「解析 JSON 再序列化」的方式改这些文件——那会把单行数组展开成多行，产生几百字节的噪声 diff。

别再把同一份内容手抄到别处。上一版规则要求两个清单手工保持一致，实测照样漏；再上一版要求五处安装入口手工同步，实测也漏。一处权威 + 生成 + 校验才是收得住的做法。

**改动后跑校验：** `node scripts/validate.mjs`。没有 CI，这是唯一常驻防线，但它只查结构和格式，不查内容质量。还要跑到哪一层，见下节。

## 改动分级验证

**验证分层，按破坏面决定跑到哪一层。** 改完只跑 `validate.mjs` 不算验证完毕。

|改了什么|必须跑到|
|---|---|
|清单、版本号、source 路径、增删插件、plugin 的 `description`|L0（先跑 `node scripts/sync-install-docs.mjs --apply` 重新生成，再校验）|
|SKILL.md 的 `description`、触发词、Gate 措辞、边界条款|L0 + L1|
|流程步骤、失败分支、检查点、完成判定|L0 + L1 + L2|
|`scripts/`、`tools/` 下脚本的对外行为（参数、输出、退出码）|L0 + L2，并留下可复现的输入与期望输出|

**`references/` 下的内容与 `SKILL.md` 正文同等对待。** 判据是**内容属于哪一类，不看它写在哪个文件**。本仓库多数 skill 的行为主体在 references 里（4 个 skill 约八成内容在其中），而 `validate.mjs` 完全看不见它们——只改 references 就以为不用验证，是这里最容易漏的一种。

**L0 结构** — `node scripts/validate.mjs`。常驻，任何改动都跑。改动校验规则本身时，还要跑 `node --test scripts/validate.test.mjs`（复制一份仓库树当夹具，用负例验证新规则真的会拦）。

**L1 规则文本** — 审阅规则表述本身：是否越权、是否造成不必要阻塞、是否与其他文件冲突、是否歧义。默认只出报告不改文件，确认后才动。

**L2 行为实测** — 用 `test-prompts.json` 实际跑一遍，确认 Skill 宣称的能力真的成立。**跑法是比对产物，不是打分发**：同一 prompt 跑两组（加载该 Skill / 不加载），比对客观产物——新增与修改了哪些文件、内容是什么、退出状态如何。产物差异才是证据。

两组使用相同的模型、推理配置、工具权限、原始夹具和辅助 Skill 访问范围，仅切换目标 Skill 的加载。baseline 只排除目标 Skill 及其副本，不能额外禁止其他 Skill。保存实际提示词和运行配置；条件不一致的结果可作单组行为证据，不能把差异归因于目标 Skill。

**不要用 LLM judge 给 with_skill / baseline 两臂打分。** 已实测三轮、分数全部作废：加载 Skill 的行为轨迹天然可辨（必然读取技能包），judge 又拿不到 prompt 上下文，会把「读被指定的技能包」判成越界读取，系统性压低处理组——三轮的分数差方向都能被这个缺陷预测，与 Skill 质量无关。要判「边界是否守住」，由人直接核产物。

**未被观察到的行为标成证据缺口，不要折算成分数。** 分数只作排序，不作证据。

**每个 Skill 必须带 `test-prompts.json`。** 格式为 `[{ "id", "prompt", "expected" }]`；`prompt` 里的 `{{FIXTURE_ROOT}}` 是隔离夹具目录的占位符，执行前替换成实际路径。没有语料的 Skill 做不了 L2，等于长期只有 L0 保护。

## 平台差异

- **Slash commands**：只在 Claude Code 上有效（`commands/*.md`）。Codex 没有 slash command，通过 `$skill-name` 调用 skill。
- **Skill 共用**：`SKILL.md` 两平台共用同一份，写作时保持 agent-neutral。
- **openai.yaml**：Codex 专属，包含 `interface`（display_name/short_description/default_prompt/brand_color）和 `policy`（allow_implicit_invocation）。
- **配置格式**：Claude Code 用 JSON（`~/.claude/settings.json`），Codex 用 TOML（`~/.codex/config.toml`）。

## 写 skill 的约定

正文中文，frontmatter 的 `name` / `description` 英文。`description` 要写清「什么时候用」并列出中英文触发词——这是 agent 判断是否加载的唯一依据，写太短会导致该触发时不触发。

内容保持 agent-neutral：不要硬编码某个 agent 专有的工具名（写「读取工作区状态」而不是「用 Bash 工具跑 git status」），`.claude-plugin/` 和 `.codex-plugin/` 目录只作为平台适配层。这样以后换 agent 不用重写正文。

同一条原则适用于插件的 `description`。它同时出现在 `.claude-plugin/plugin.json`、`.codex-plugin/plugin.json` 和权威清单三处，派生时逐字复制，所以**不要在里面写平台专有的调用语法**（`/skill`、`$skill`）——写了这三处就没法一致，Codex 副本会退化成第二个手写点。要表达「只能手动触发」就写 `Manual invocation only.`，具体怎么调用交给平台自己声明：Claude Code 把 `commands/*.md` 注册成斜杠命令，Codex 的调用名写在 `agents/openai.yaml` 的 `default_prompt` 里。

`Manual invocation only.` 是个有内容的断言，写之前先确认对应 `agents/openai.yaml` 的 `policy.allow_implicit_invocation` 是 `false`；是 `true` 就别写这句，否则描述与实现自相矛盾。

## 脚本约定

`scripts/` 下用 Node ESM（`.mjs`），无第三方依赖。会改动文件系统的脚本默认 dry-run，加 `--apply` 才写盘。不要写会修改用户 `~/.claude/settings.json` 或 `~/.codex/config.toml` 的脚本——那是用户的个人全局配置，安装引导靠 `docs/` 下的片段加 README 里的提示词让用户自行合并。

## 本地开发回环

### Claude Code

本机用 `claude plugin marketplace add ./` 把仓库注册成 directory 源，插件以 `<名字>@gh-tools` 形式可用，改完刷新即生效。团队那边走 git tag，不要把半成品 push 上去。

**不要把 directory 源配置提交进仓库的 `.claude/settings.json`。** 市场名固定为 `gh-tools`（取自 `marketplace.json` 的 `name`，`extraKnownMarketplaces` 的 key 必须与之一致，否则条目被忽略），提交 directory 源会与团队成员 user settings 里的 git 源同名冲突。且 `path` 只接受绝对路径，本身就是机器特定的。

### Codex

编辑 `~/.codex/config.toml`，使用 `source_type = "local"` 和绝对路径。参考 `docs/codex-config-snippet.toml`。修改后开启新对话线程测试。
