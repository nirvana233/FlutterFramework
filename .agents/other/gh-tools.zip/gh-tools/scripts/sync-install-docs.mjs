#!/usr/bin/env node
/**
 * 安装文档生成器：把「市场里有哪些插件」收敛成一份权威 + 若干生成物。
 *
 * 权威源分两层：
 *   - .claude-plugin/marketplace.json      插件列表、source、category（手写）
 *   - 各插件的 .claude-plugin/plugin.json  description（手写，唯一）
 * 生成物：
 *   - .agents/plugins/marketplace.json  （整份，Codex 读的清单）
 *   - docs/settings-snippet.json        （整份）
 *   - docs/codex-config-snippet.toml    （整份）
 *   - README.md 内 5 个 <!-- sync:begin 名字 --> 区块
 *   - .claude-plugin/marketplace.json 里每个 plugin 的 description（字段级）
 *   - 各 .codex-plugin/plugin.json 的 description（字段级）
 * 仍靠手写、但 validate 会核对的部分：
 *   - README「插件清单」表格（说明文案手写，插件名与顺序必须与清单一致）
 *
 * 用法：
 *   node scripts/sync-install-docs.mjs            预览差异，不写盘
 *   node scripts/sync-install-docs.mjs --apply    写盘
 * 退出码：0 = 已是最新（或已写入）；1 = 有差异/无法生成；2 = 参数错误
 */

import {
  existsSync,
  readdirSync,
  readFileSync,
  realpathSync,
  statSync,
  writeFileSync,
} from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')

// 分发地址只在这里定义一次。README 的叙述文字里还有几处手写的同款 URL，
// 换地址时要一起搜（搜 doc-git.hmserver.club）。
const REPO_URL = 'https://doc-git.hmserver.club/gaohao/gh-tools.git'

/** 生成内容使用 LF；更新已有文件时沿用其 CRLF，新文件默认 LF。 */
function preserveLineEndings(content, current) {
  return current?.includes('\r\n') ? content.replace(/\n/g, '\r\n') : content
}

/** 读权威清单 */
export function readMarketplace(root = ROOT) {
  const path = join(root, '.claude-plugin', 'marketplace.json')
  const manifest = JSON.parse(readFileSync(path, 'utf8'))
  if (!manifest.name) throw new Error(`${path}: 缺少 name`)
  if (!Array.isArray(manifest.plugins)) throw new Error(`${path}: plugins 必须是数组`)
  return manifest
}

/**
 * 每个插件的权威 description，来自它自己的 .claude-plugin/plugin.json。
 * 这是「插件怎么描述自己」的唯一手写点：清单条目和 Codex plugin.json 都从它派生。
 */
export function readAuthoritativeDescriptions(root, marketplace) {
  const descriptions = new Map()
  for (const plugin of marketplace.plugins) {
    const path = join(root, plugin.source, '.claude-plugin', 'plugin.json')
    if (!existsSync(path)) throw new Error(`${path}: 不存在，无法取 description`)
    const manifest = JSON.parse(readFileSync(path, 'utf8'))
    if (typeof manifest.description !== 'string' || manifest.description === '') {
      throw new Error(`${path}: 缺少 description`)
    }
    descriptions.set(plugin.name, manifest.description)
  }
  return descriptions
}

/**
 * 把文本里某个 JSON 字符串值替换成新值，其余一个字节都不动。
 *
 * 为什么不用 JSON.parse + stringify 重写整个文件：这些文件把 keywords 数组写在一行，
 * 序列化会把它们展开成多行，产生几百字节的噪声 diff，掩盖真正的改动。
 * 定位靠「旧值本身」而非行号或键路径，并要求它在文件里唯一。
 */
function replaceJsonString(text, oldValue, newValue, label, problems) {
  if (typeof oldValue !== 'string') {
    problems.push(`${label}: 当前不是字符串，无法替换`)
    return text
  }
  if (oldValue === newValue) return text

  const needle = JSON.stringify(oldValue)
  const at = text.indexOf(needle)
  if (at === -1) {
    problems.push(`${label}: 文件里找不到当前值，无法替换（被手工改过？）`)
    return text
  }
  if (text.indexOf(needle, at + 1) !== -1) {
    problems.push(`${label}: 当前值在文件里出现多次，无法安全替换`)
    return text
  }
  return text.slice(0, at) + JSON.stringify(newValue) + text.slice(at + needle.length)
}

/** 某个插件下所有 skill 的调用名（目录名即调用名），按目录名排序 */
export function collectSkillNames(root, pluginSource) {
  const skillsDir = join(root, pluginSource, 'skills')
  if (!existsSync(skillsDir)) return []
  return readdirSync(skillsDir)
    .filter((name) => statSync(join(skillsDir, name)).isDirectory())
    .sort()
}

/** 形如 name@market 的安装 ID，顺序跟随清单 */
function pluginIds(marketplace) {
  return marketplace.plugins.map((plugin) => `${plugin.name}@${marketplace.name}`)
}

/**
 * Codex 清单独有的取值就集中在这两个常量里——它整份是生成物，
 * 要调 Codex 侧的展示分类或安装策略，改这里，不要改生成结果。
 */

/** Claude 侧的 category 比 Codex 细（如 code-review），枚举不同，显式对照，不靠猜 */
const CODEX_CATEGORY = {
  engineering: 'Engineering',
  'code-review': 'Engineering',
  media: 'Media',
  productivity: 'Productivity',
}

/** Codex 清单每个插件的 policy，当前所有插件同一套取值 */
const CODEX_POLICY = { installation: 'AVAILABLE', authentication: 'ON_INSTALL' }

/** 未进对照表的 category 按首字母大写兜底，保证加插件时不被卡住 */
function codexCategory(category) {
  if (!category) return undefined
  return CODEX_CATEGORY[category] ?? category[0].toUpperCase() + category.slice(1)
}

/** .agents/plugins/marketplace.json 整份内容（Codex 直接读这个文件） */
function renderCodexMarketplace(marketplace) {
  const manifest = {
    name: marketplace.name,
    interface: { displayName: marketplace.name },
    plugins: marketplace.plugins.map((plugin) => ({
      name: plugin.name,
      source: { source: 'local', path: plugin.source },
      policy: { ...CODEX_POLICY },
      category: codexCategory(plugin.category),
    })),
  }
  return `${JSON.stringify(manifest, null, 2)}\n`
}

/** docs/settings-snippet.json：纯 JSON，不能带注释，靠文档说明它是生成物 */
function renderSettingsSnippet(marketplace) {
  const enabled = pluginIds(marketplace)
    .map((id) => `    "${id}": true`)
    .join(',\n')

  const lines = [
    '{',
    '  "extraKnownMarketplaces": {',
    `    "${marketplace.name}": {`,
    '      "source": {',
    '        "source": "git",',
    `        "url": "${REPO_URL}"`,
    '      }',
    '    }',
    '  },',
    '  "enabledPlugins": {',
    enabled,
    '  }',
    '}',
  ]
  return `${lines.join('\n')}\n`
}

/** Claude Code 的命令行安装序列 */
function renderClaudeInstallCommands(marketplace, marketplaceAdd) {
  const lines = [`claude plugin marketplace add ${marketplaceAdd}`]
  for (const id of pluginIds(marketplace)) lines.push(`claude plugin install ${id}`)
  return lines
}

/** Codex 的 [plugins."..."] 段落，空行分隔 */
function renderCodexPluginTables(marketplace) {
  return pluginIds(marketplace)
    .map((id) => `[plugins."${id}"]\nenabled = true`)
    .join('\n\n')
}

/** `$a` / `$b` 形式的 skill 调用名列表，顺序跟随清单 */
function renderSkillNames(marketplace, root) {
  return marketplace.plugins
    .flatMap((plugin) => collectSkillNames(root, plugin.source).map((name) => `\`$${name}\``))
    .join(' / ')
}

/** Codex 调用名说明行：- Codex 不支持自定义斜杠命令，通过 `$a` / `$b` 调用对应 skill */
function renderSkillNameLine(marketplace, root) {
  return `- Codex 不支持自定义斜杠命令，通过 ${renderSkillNames(marketplace, root)} 调用对应 skill\n`
}

/** docs/codex-config-snippet.toml 整份内容 */
function renderCodexSnippet(marketplace, root) {
  const name = marketplace.name
  const localTables = renderCodexPluginTables(marketplace)

  const body = [
    '# 本文件由 scripts/sync-install-docs.mjs 生成，不要手改。',
    '# 改了市场清单后跑：node scripts/sync-install-docs.mjs --apply',
    '',
    '# Codex 配置片段',
    '',
    '将以下内容合并到 `~/.codex/config.toml`：',
    '',
    '```toml',
    `# ${name} 插件市场`,
    `[marketplaces.${name}]`,
    'source_type = "local"',
    'source = "/Users/你的用户名/code/gh-tools"',
    '',
    '# 启用的插件',
    localTables,
    '```',
    '',
    '## 团队使用 git 源',
    '',
    '如果需要通过 GitLab 分发（而非本地开发），将 `source_type` 和 `source` 改为：',
    '',
    '```toml',
    `[marketplaces.${name}]`,
    'source_type = "git"',
    `source = "${REPO_URL}"`,
    '```',
    '',
    '## 安装提示词',
    '',
    '在 Codex 对话中，向 agent 发送以下提示：',
    '',
    `> 把 ${name} 仓库里 \`docs/codex-config-snippet.toml\` 的内容合并进我的 \`~/.codex/config.toml\`：保留我已有的所有 \`[marketplaces.*]\` 和 \`[plugins.*]\` 条目，只增量添加 \`${name}\` 相关的配置，不要覆盖整个文件。`,
    '',
    '## 注意事项',
    '',
    '1. **路径必须是绝对路径**：本地开发时 `source` 必须写完整路径，Codex 不支持相对路径',
    '2. **config.toml 使用 TOML 语法**：字符串值需要用引号包裹',
    '3. **重启 Codex**：修改配置后需要重启 Codex 或开启新对话线程才能生效',
    `4. **不支持自定义斜杠命令**：通过 ${renderSkillNames(marketplace, root)} 调用对应 skill`,
  ]
  return `${body.join('\n')}\n`
}

/** README 的生成区块：标记名 → 内容（含尾随换行，替换时连标记一起定位） */
export function buildBlocks(marketplace, root = ROOT) {
  const name = marketplace.name
  const fenced = (language, lines) => ['```' + language, ...lines, '```', ''].join('\n')

  return {
    'claude-install-json': fenced('json', renderSettingsSnippet(marketplace).trimEnd().split('\n')),
    'claude-install-cli': fenced('bash', renderClaudeInstallCommands(marketplace, REPO_URL)),
    'claude-install-cli-local': fenced('bash', [
      'cd /path/to/gh-tools',
      ...renderClaudeInstallCommands(marketplace, './'),
    ]),
    'codex-config-git': fenced('toml', [
      `[marketplaces.${name}]`,
      'source_type = "git"',
      `source = "${REPO_URL}"`,
      '',
      renderCodexPluginTables(marketplace),
    ]),
    'codex-skill-names': renderSkillNameLine(marketplace, root),
  }
}

/**
 * 生成全部产物的期望内容。
 *
 * 每个产物是 { path, render(currentText) → 期望文本 | null }：整份生成的产物沿用当前换行；
 * 字段级派生的产物（清单 description、Codex plugin.json description）需要读磁盘上的
 * 当前内容才能算出期望值——这样「期望 == 当前」就等价于「已经是最新」。
 * render 返回 null 表示它已把原因写进 problems。
 *
 * 返回 { artifacts, problems }；problems 非空时不要写盘。
 */
export function buildArtifacts(root = ROOT) {
  const problems = []
  let marketplace
  let descriptions
  try {
    marketplace = readMarketplace(root)
    descriptions = readAuthoritativeDescriptions(root, marketplace)
  } catch (error) {
    return { artifacts: [], problems: [error.message] }
  }

  const blocks = buildBlocks(marketplace, root)
  const artifacts = [
    {
      path: '.agents/plugins/marketplace.json',
      render: (current) => preserveLineEndings(renderCodexMarketplace(marketplace), current),
    },
    {
      path: 'docs/settings-snippet.json',
      render: (current) => preserveLineEndings(renderSettingsSnippet(marketplace), current),
    },
    {
      path: 'docs/codex-config-snippet.toml',
      render: (current) => preserveLineEndings(renderCodexSnippet(marketplace, root), current),
    },
  ]

  const readmePath = join(root, 'README.md')
  if (!existsSync(readmePath)) {
    problems.push('README.md 不存在')
  } else {
    artifacts.push({
      path: 'README.md',
      render: (current) => {
        let content = current
        for (const [blockName, blockContent] of Object.entries(blocks)) {
          const pattern = new RegExp(
            `(<!-- sync:begin ${blockName} -->\\r?\\n)[\\s\\S]*?(<!-- sync:end ${blockName} -->)`,
          )
          if (!pattern.test(content)) {
            problems.push(`README.md 缺少 sync 标记：${blockName}`)
            continue
          }
          // 用函数式替换：生成内容里的 $skill 之类会被当成捕获组引用，不能直接传字符串。
          content = content.replace(
            pattern,
            (_match, head, tail) => head + preserveLineEndings(blockContent, head) + tail,
          )
        }
        return content
      },
    })
  }

  // 清单条目的 description：权威值是各插件自己的 .claude-plugin/plugin.json，清单这份是副本。
  artifacts.push({
    path: '.claude-plugin/marketplace.json',
    // 这个文件本身是权威清单，而 description 是它唯一的派生字段。所以「不一致」不能笼统地
    // 报成「与市场清单不同步」——它自己就是市场清单，那句话是自指的，读者不知道改哪儿。
    // 这里列出漂了的插件名，由调用方组织文案（校验报错 / 写盘提示）。
    mismatchedDescriptions: () =>
      marketplace.plugins
        .filter((plugin) => {
          const target = descriptions.get(plugin.name)
          return target !== undefined && plugin.description !== target
        })
        .map((plugin) => plugin.name),
    render: (current) => {
      if (current === null) return null
      let text = current
      for (const plugin of marketplace.plugins) {
        const target = descriptions.get(plugin.name)
        if (target === undefined) continue
        text = replaceJsonString(
          text,
          plugin.description,
          target,
          `清单里 plugin "${plugin.name}" 的 description`,
          problems,
        )
      }
      return text
    },
  })

  // Codex plugin.json 的 description：同样是副本，派生的同时保证两平台一字不差。
  for (const plugin of marketplace.plugins) {
    const target = descriptions.get(plugin.name)
    if (target === undefined) continue
    const label = `${plugin.source.replace(/^\.\//, '')}/.codex-plugin/plugin.json`
    artifacts.push({
      path: label,
      render: (current) => {
        if (current === null) {
          problems.push(`${label}: 文件不存在，无法派生 description`)
          return null
        }
        let manifest
        try {
          manifest = JSON.parse(current)
        } catch (error) {
          problems.push(`${label}: 无法解析 JSON — ${error.message}`)
          return null
        }
        return replaceJsonString(
          current,
          manifest.description,
          target,
          `${label} 的 description`,
          problems,
        )
      },
    })
  }

  return { artifacts, problems }
}

function printHelp() {
  console.log(
    [
      '用法：node scripts/sync-install-docs.mjs [--apply]',
      '',
      '从 .claude-plugin/marketplace.json 生成安装文档与 Codex 清单：',
      '  .agents/plugins/marketplace.json',
      '  docs/settings-snippet.json',
      '  docs/codex-config-snippet.toml',
      '  README.md 的 5 个 <!-- sync:begin ... --> 区块',
      '  .claude-plugin/marketplace.json 里每个 plugin 的 description',
      '  各 .codex-plugin/plugin.json 的 description',
      '',
      'description 的权威源是各插件自己的 .claude-plugin/plugin.json。',
      '不带 --apply 时只预览，不改文件。',
    ].join('\n'),
  )
}

export function main(argv = process.argv.slice(2)) {
  const known = new Set(['--apply', '--help', '-h'])
  const unknown = argv.filter((arg) => !known.has(arg))
  if (unknown.length > 0) {
    console.error(`error 未知参数：${unknown.join(', ')}`)
    console.error('运行 node scripts/sync-install-docs.mjs --help 查看用法。')
    return 2
  }
  if (argv.includes('--help') || argv.includes('-h')) {
    printHelp()
    return 0
  }

  const apply = argv.includes('--apply')
  const { artifacts, problems } = buildArtifacts(ROOT)

  // 先把每个产物的期望内容都算出来再决定写不写：字段级产物要读磁盘当前内容才能算，
  // 而且只要有一个 problem 就整体不写盘，避免留下写了一半的状态。
  // 整份生成的产物只参考当前换行——文件被删掉时 render 照样给出期望内容，--apply 能补回来。
  const stale = []
  for (const artifact of artifacts) {
    const path = join(ROOT, artifact.path)
    const current = existsSync(path) ? readFileSync(path, 'utf8') : null
    const expected = artifact.render(current)
    if (expected === null) continue
    if (expected !== current) stale.push({ path: artifact.path, content: expected, artifact })
  }

  for (const problem of problems) console.error(`error ${problem}`)
  if (problems.length > 0) return 1

  if (stale.length === 0) {
    console.log(`安装文档已是最新：${artifacts.length} 个生成物`)
    return 0
  }
  if (!apply) {
    console.log(`待更新 ${stale.length} 个：`)
    for (const item of stale) console.log(`  - ${item.path}`)
    console.log('跑 node scripts/sync-install-docs.mjs --apply 写入。')
    return 1
  }
  for (const item of stale) {
    writeFileSync(join(ROOT, item.path), item.content)
    console.log(`write ${item.path}`)
    // 清单里的 description 是副本，写盘会覆盖掉手写的内容。不说明的话，改动凭空消失，
    // 用户只会以为生成器出了问题。
    for (const name of item.artifact.mismatchedDescriptions?.() ?? []) {
      console.log(
        `  note 清单里 "${name}" 的 description 已按插件自己的 .claude-plugin/plugin.json 覆盖（权威在 plugin.json）`,
      )
    }
  }
  console.log(`已写入 ${stale.length} 个文件。`)
  return 0
}

if (process.argv[1] && realpathSync(process.argv[1]) === fileURLToPath(import.meta.url)) {
  process.exit(main())
}
