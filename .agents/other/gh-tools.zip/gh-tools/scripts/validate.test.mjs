import test from 'node:test'
import assert from 'node:assert/strict'

import { cpSync, mkdtempSync, readFileSync, readdirSync, renameSync, rmSync, unlinkSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'

const REPO_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')

// validate.mjs 的 ROOT 写死在自己所在目录的上一层，也没有参数入口。
// 所以夹具不是「一个插件目录」，而是整棵仓库树的副本——把树复制出去跑，
// 负例就不必改真仓库，ROOT 也自然指向夹具。
const COPIED_DIRS = ['.claude-plugin', '.agents', 'plugins', 'scripts', 'docs']
const COPIED_FILES = ['README.md']
const VALIDATE = 'validate.mjs'
const SYNC = 'sync-install-docs.mjs'

// 显式模拟 checkout 的换行，避免用例结果依赖运行机器的 core.autocrlf。
function setFixtureLineEndings(root, lineEnding) {
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    const path = join(root, entry.name)
    if (entry.isDirectory()) {
      setFixtureLineEndings(path, lineEnding)
    } else if (/\.(md|json|toml|mjs|ya?ml)$/.test(entry.name)) {
      const content = readFileSync(path, 'utf8').replace(/\r\n/g, '\n')
      writeFileSync(path, content.replace(/\n/g, lineEnding))
    }
  }
}

function withFixture(fn, lineEnding = '\n') {
  const fixture = mkdtempSync(join(tmpdir(), 'gh tools 校验-'))
  try {
    for (const entry of COPIED_DIRS) {
      cpSync(join(REPO_ROOT, entry), join(fixture, entry), { recursive: true })
    }
    for (const entry of COPIED_FILES) {
      cpSync(join(REPO_ROOT, entry), join(fixture, entry))
    }
    if (lineEnding !== null) setFixtureLineEndings(fixture, lineEnding)
    return fn(fixture)
  } finally {
    rmSync(fixture, { recursive: true, force: true })
  }
}

function runScript(fixture, script, args = []) {
  const result = spawnSync(process.execPath, [join(fixture, 'scripts', script), ...args], {
    encoding: 'utf8',
  })
  return { status: result.status, stdout: result.stdout, stderr: result.stderr }
}

const readFixture = (fixture, ...parts) => readFileSync(join(fixture, ...parts), 'utf8')

// 插件数量跟随夹具的权威清单，新增插件时无需改写成功摘要的预期。
function assertValidationSummary(fixture, stdout, warningCount = 0) {
  const manifest = JSON.parse(readFixture(fixture, '.claude-plugin', 'marketplace.json'))
  assert.equal(stdout, `校验通过：${manifest.plugins.length} 个插件，${warningCount} 个警告\n`)
}

/** 在夹具里改文本，并确认真的改到了——否则用例会因为「没造成破坏」而假通过 */
function patchFile(fixture, ...parts) {
  const path = join(fixture, ...parts)
  return (pattern, replacement) => {
    const before = readFileSync(path, 'utf8')
    const after = before.replace(pattern, replacement)
    assert.notEqual(after, before, `夹具改动没生效，用例本身失效：${pattern}`)
    writeFileSync(path, after)
  }
}

test('仓库原样复制出去跑，不转换换行也能校验通过', () => {
  withFixture((fixture) => {
    const { status, stdout, stderr } = runScript(fixture, VALIDATE)
    assert.equal(status, 0)
    assert.equal(stderr, '')
    assertValidationSummary(fixture, stdout)
  }, null)
})

for (const invalidName of ['prompt-assistant', 'gh-asset-gen', 'gh-project-init', 'gh-version-compat-review']) {
  test(`安装名 ${invalidName}：缺前缀或功能词缩写会被拦截`, () => {
    withFixture((fixture) => {
      patchFile(fixture, '.claude-plugin/marketplace.json')(
        /"name": "gh-prompt-assistant"/,
        `"name": "${invalidName}"`,
      )
      const result = runScript(fixture, VALIDATE)
      assert.equal(result.status, 1)
      assert.match(result.stderr, /安装名必须使用 gh- 完整名称/)
    })
  })
}

test('Skill 目录和 frontmatter 同时退回旧名称：仍被完整名称规则拦截', () => {
  withFixture((fixture) => {
    const root = 'plugins/common/prompt-assistant/skills/'
    renameSync(join(fixture, root, 'gh-prompt-assistant'), join(fixture, root, 'gh'))
    patchFile(fixture, root, 'gh/SKILL.md')(/^name: gh-prompt-assistant$/m, 'name: gh')
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /skills\/gh 必须使用 gh- 完整名称/)
  })
})

test('插件安装名与唯一 Skill 名必须一致，即使两者都带 gh- 前缀', () => {
  withFixture((fixture) => {
    patchFile(fixture, '.claude-plugin/marketplace.json')(
      /"name": "gh-prompt-assistant"/,
      '"name": "gh-other-assistant"',
    )
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /安装名与唯一 Skill 调用名 "gh-prompt-assistant" 不一致/)
  })
})

for (const displayName of ['提示词补全', 'GH', 'gh-other-assistant · 提示词补全']) {
  test(`显示名 ${displayName}：必须保留完整调用名`, () => {
    withFixture((fixture) => {
      patchFile(fixture, 'plugins/common/prompt-assistant/skills/gh-prompt-assistant/agents/openai.yaml')(
        /display_name: "[^"]*"/,
        `display_name: "${displayName}"`,
      )
      const result = runScript(fixture, VALIDATE)
      assert.equal(result.status, 1)
      assert.match(result.stderr, /display_name 必须保留完整调用名/)
    })
  })
}

test('插件与 Skill 的中文显示说明也必须一致', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'plugins/common/prompt-assistant/.codex-plugin/plugin.json')(
      /"displayName": "[^"]*"/,
      '"displayName": "gh-prompt-assistant · 指令助手"',
    )
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /displayName 与 Skill 显示名不一致/)
  })
})

test('description 内的冒号未加引号：拦截会导致 Claude 元数据丢失的 YAML', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'plugins/common/skill-optimizer/skills/gh-skill-optimizer/SKILL.md')(
      /^description: "([^"]+)"$/m,
      'description: Optimize Skills: improve real usage outcomes.',
    )
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /description 含冒号时必须加引号或使用多行块/)
  })
})

for (const invocation of ['$gh', '$gh-prompt-assistant-extra']) {
  test(`默认提示词入口 ${invocation}：不能替代完整调用名`, () => {
    withFixture((fixture) => {
      patchFile(fixture, 'plugins/common/prompt-assistant/skills/gh-prompt-assistant/agents/openai.yaml')(
        /default_prompt: "[^"]*"/,
        `default_prompt: "Use ${invocation} to clarify this request."`,
      )
      const result = runScript(fixture, VALIDATE)
      assert.equal(result.status, 1)
      assert.match(result.stderr, /default_prompt 必须使用完整入口 \$gh-prompt-assistant/)
    })
  })
}

test('插件默认提示词也必须至少包含一个完整调用入口', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'plugins/common/prompt-assistant/.codex-plugin/plugin.json')(
      /\$gh-prompt-assistant/g,
      '$gh',
    )
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /defaultPrompt 必须包含完整入口 \$gh-prompt-assistant/)
  })
})

test('Claude command 保留旧简称，即使引用有效 Skill 也会被拦截', () => {
  withFixture((fixture) => {
    const root = 'plugins/common/prompt-assistant'
    renameSync(join(fixture, root, 'commands/gh-prompt-assistant.md'), join(fixture, root, 'commands/gh.md'))
    patchFile(fixture, root, '.claude-plugin/plugin.json')(/commands\/gh-prompt-assistant\.md/, 'commands/gh.md')
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /commands\/gh.md 的命令名必须与完整 Skill 调用名 gh-prompt-assistant 一致/)
  })
})

test('Claude command 指向已删除的 Skill 名称：明确报失效入口', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'plugins/common/prompt-assistant/commands/gh-prompt-assistant.md')(
      /skills\/gh-prompt-assistant\/SKILL.md/,
      'skills/gh/SKILL.md',
    )
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /必须引用当前 Skill 的有效入口/)
  })
})

test('Claude command 的显示说明必须与 Codex 使用同一完整名称和中文说明', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'plugins/common/prompt-assistant/commands/gh-prompt-assistant.md')(
      /^description:.*$/m,
      'description: GH 指令助手',
    )
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /commands\/gh-prompt-assistant.md 的 description 与 Skill 显示名不一致/)
  })
})

for (const [label, lineEnding] of [
  ['LF', '\n'],
  ['CRLF', '\r\n'],
]) {
  test(`${label}：中英文显示名接受 YAML 空行、注释和单引号`, () => {
    withFixture((fixture) => {
      const path = 'plugins/common/prompt-assistant/skills/gh-prompt-assistant/agents/openai.yaml'
      patchFile(fixture, path)(/interface:\r?\n/, `interface: # labels${lineEnding}${lineEnding}# comment${lineEnding}`)
      patchFile(fixture, path)(
        /display_name: "gh-prompt-assistant · 提示词补全"/,
        "display_name: 'gh-prompt-assistant · 提示词补全' # label",
      )
      patchFile(fixture, path)(/default_prompt: ("[^\r\n]*")/, 'default_prompt: $1 # invocation')
      const result = runScript(fixture, VALIDATE)
      assert.equal(result.status, 0, result.stderr)
      assertValidationSummary(fixture, result.stdout)
    }, lineEnding)
  })

  test(`${label}：调用策略接受 YAML 注释和空行，仍拦截真实策略冲突`, () => {
    withFixture((fixture) => {
      for (const path of [
        'plugins/common/workflow/skills/gh-workflow/SKILL.md',
        'plugins/common/workflow/commands/gh-workflow.md',
      ]) {
        patchFile(fixture, path)(
          /disable-model-invocation: true/,
          'disable-model-invocation: true # manual only',
        )
      }
      const policy = 'plugins/common/workflow/skills/gh-workflow/agents/openai.yaml'
      patchFile(fixture, policy)(
        /policy:\r?\n/,
        `policy: # invocation${lineEnding}${lineEnding}# comment${lineEnding}  # indented comment${lineEnding}`,
      )
      patchFile(fixture, policy)(/allow_implicit_invocation: false/, 'allow_implicit_invocation: false # manual only')
      const valid = runScript(fixture, VALIDATE)
      assert.equal(valid.status, 0, valid.stderr)
      assertValidationSummary(fixture, valid.stdout)
      patchFile(fixture, policy)(/allow_implicit_invocation: false/, 'allow_implicit_invocation: true')
      const invalid = runScript(fixture, VALIDATE)
      assert.equal(invalid.status, 1)
      assert.match(invalid.stderr, /gh-workflow.*allow_implicit_invocation/)
    }, lineEnding)
  })

  test(`${label}：校验和生成器均通过，dry-run 与 --apply 都不改已同步文件`, () => {
    withFixture((fixture) => {
      const manifest = JSON.parse(readFixture(fixture, '.claude-plugin', 'marketplace.json'))
      const paths = [
        '.agents/plugins/marketplace.json',
        'docs/settings-snippet.json',
        'docs/codex-config-snippet.toml',
        'README.md',
        '.claude-plugin/marketplace.json',
        ...manifest.plugins.map((plugin) => `${plugin.source}/.codex-plugin/plugin.json`),
      ]
      const before = paths.map((path) => readFixture(fixture, path))
      const checked = runScript(fixture, VALIDATE)
      assert.equal(checked.status, 0, checked.stderr)
      assertValidationSummary(fixture, checked.stdout)
      for (const args of [[], ['--apply']]) {
        const result = runScript(fixture, SYNC, args)
        assert.equal(result.status, 0, result.stderr)
        assert.match(result.stdout, /安装文档已是最新/)
        assert.equal(result.stderr, '')
        assert.deepEqual(paths.map((path) => readFixture(fixture, path)), before)
      }
    }, lineEnding)
  })

  test(`${label}：真实内容差异仍被拦，--apply 修复且保留原换行与手写内容`, () => {
    withFixture((fixture) => {
      const paths = [
        '.agents/plugins/marketplace.json',
        'docs/settings-snippet.json',
        'docs/codex-config-snippet.toml',
        'README.md',
        '.claude-plugin/marketplace.json',
        'plugins/common/workflow/.codex-plugin/plugin.json',
      ]
      const before = paths.map((path) => readFixture(fixture, path))
      patchFile(fixture, paths[0])(/"category": "Productivity"/, '"category": "Misc"')
      patchFile(fixture, paths[1])(
        /"gh-skill-optimizer@gh-tools": true/,
        '"gh-skill-optimizer@gh-tools": false',
      )
      patchFile(fixture, paths[2])(/enabled = true/, 'enabled = false')
      patchFile(fixture, paths[3])(
        /claude plugin marketplace add https:\/\/[^\r\n]+/,
        'claude plugin marketplace add https://wrong.example/repo.git',
      )
      patchFile(fixture, paths[4])(
        /("name": "gh-workflow",[\s\S]*?"description": ")[^"]*(")/,
        '$1hand written description$2',
      )
      patchFile(fixture, paths[5])(
        /"description": "[^"]*"/,
        '"description": "hand written description"',
      )

      const changed = paths.map((path) => readFixture(fixture, path))
      const checked = runScript(fixture, VALIDATE)
      assert.equal(checked.status, 1)
      for (const path of [paths[0], paths[1], paths[2], paths[3], paths[5]]) {
        assert.ok(checked.stderr.includes(`${path} 与市场清单不同步`), checked.stderr)
      }
      assert.match(checked.stderr, /清单里 plugin "gh-workflow" 的 description/)
      const dryRun = runScript(fixture, SYNC)
      assert.equal(dryRun.status, 1)
      assert.match(dryRun.stdout, /待更新 6 个/)
      assert.deepEqual(paths.map((path) => readFixture(fixture, path)), changed)

      const applied = runScript(fixture, SYNC, ['--apply'])
      assert.equal(applied.status, 0, applied.stderr)
      assert.deepEqual(paths.map((path) => readFixture(fixture, path)), before)
      assert.equal(runScript(fixture, VALIDATE).status, 0)
      assert.equal(runScript(fixture, SYNC).status, 0)
    }, lineEnding)
  })

  test(`${label}：README 同步标记真的缺失时 --apply 拒绝写入全部产物`, () => {
    withFixture((fixture) => {
      patchFile(fixture, 'README.md')(/<!-- sync:end claude-install-cli -->\r?\n/, '')
      patchFile(fixture, 'docs/settings-snippet.json')(
        /"gh-skill-optimizer@gh-tools": true/,
        '"gh-skill-optimizer@gh-tools": false',
      )
      const paths = ['README.md', 'docs/settings-snippet.json']
      const before = paths.map((path) => readFixture(fixture, path))
      assert.equal(runScript(fixture, VALIDATE).status, 1)
      const result = runScript(fixture, SYNC, ['--apply'])
      assert.equal(result.status, 1)
      assert.match(result.stderr, /README\.md 缺少 sync 标记：claude-install-cli/)
      assert.deepEqual(paths.map((path) => readFixture(fixture, path)), before)
    }, lineEnding)
  })

  test(`${label}：README 插件表格的真实缺失仍被拦`, () => {
    withFixture((fixture) => {
      patchFile(fixture, 'README.md')(/^\|`gh-skill-optimizer`\|[^\n]*\n/m, '')
      const result = runScript(fixture, VALIDATE)
      assert.equal(result.status, 1)
      assert.match(result.stderr, /表格的插件名或顺序与市场清单不一致/)
      assert.doesNotMatch(result.stderr, /找不到「插件清单」章节/)
    }, lineEnding)
  })
}

test('手改生成物 settings-snippet.json：报不同步并退出 1', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'docs', 'settings-snippet.json')(
      /\s*"gh-skill-optimizer@gh-tools": true,/,
      '',
    )
    const { status, stderr } = runScript(fixture, VALIDATE)
    assert.equal(status, 1)
    assert.match(stderr, /docs\/settings-snippet\.json 与市场清单不同步/)
  })
})

test('手改生成物 codex-config-snippet.toml：报不同步并退出 1', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'docs', 'codex-config-snippet.toml')(
      /\[plugins\."gh-skill-optimizer@gh-tools"\]\nenabled = true\n\n/,
      '',
    )
    const { status, stderr } = runScript(fixture, VALIDATE)
    assert.equal(status, 1)
    assert.match(stderr, /docs\/codex-config-snippet\.toml 与市场清单不同步/)
  })
})

test('手改 README 的 sync 区块：报不同步并退出 1', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'README.md')(
      /(<!-- sync:begin claude-install-cli -->\n```bash\n)claude plugin marketplace add [^\n]*\n/,
      '$1',
    )
    const { status, stderr } = runScript(fixture, VALIDATE)
    assert.equal(status, 1)
    assert.match(stderr, /README\.md 与市场清单不同步/)
  })
})

test('清单改了却没重新生成文档：生成物与表格一起报不一致', () => {
  withFixture((fixture) => {
    const path = join(fixture, '.claude-plugin', 'marketplace.json')
    const manifest = JSON.parse(readFileSync(path, 'utf8'))
    manifest.plugins.reverse()
    writeFileSync(path, `${JSON.stringify(manifest, null, 2)}\n`)

    const { status, stderr } = runScript(fixture, VALIDATE)
    assert.equal(status, 1)
    assert.match(stderr, /\.agents\/plugins\/marketplace\.json 与市场清单不同步/)
    assert.match(stderr, /docs\/settings-snippet\.json 与市场清单不同步/)
    assert.match(stderr, /README\.md 与市场清单不同步/)
    assert.match(stderr, /表格的插件名或顺序与市场清单不一致/)
  })
})

test('手改 Codex 清单：报不同步并退出 1', () => {
  withFixture((fixture) => {
    // 模拟「想在 Codex 侧单独调分类」——规则要求改生成器里的对照表，不许改生成结果
    patchFile(fixture, '.agents', 'plugins', 'marketplace.json')(
      /"category": "Productivity"/,
      '"category": "Misc"',
    )
    const { status, stderr } = runScript(fixture, VALIDATE)
    assert.equal(status, 1)
    assert.match(stderr, /\.agents\/plugins\/marketplace\.json 与市场清单不同步/)
  })
})

test('新增未映射的 category：走首字母大写兜底，不阻塞加插件', () => {
  withFixture((fixture) => {
    patchFile(fixture, '.claude-plugin', 'marketplace.json')(
      /"category": "engineering",\s*"source": "\.\/plugins\/common\/workflow"/,
      '"category": "automation",\n      "source": "./plugins/common/workflow"',
    )
    // 只改清单、没重新生成 → Codex 清单被拦
    assert.equal(runScript(fixture, VALIDATE).status, 1)

    assert.equal(runScript(fixture, SYNC, ['--apply']).status, 0)
    const codex = JSON.parse(readFixture(fixture, '.agents', 'plugins', 'marketplace.json'))
    assert.equal(codex.plugins.find((plugin) => plugin.name === 'gh-workflow').category, 'Automation')
    assert.equal(runScript(fixture, VALIDATE).status, 0)
  })
})

test('Codex 清单被删：报缺少，--apply 能补回来', () => {
  withFixture((fixture) => {
    unlinkSync(join(fixture, '.agents', 'plugins', 'marketplace.json'))
    const { status, stderr } = runScript(fixture, VALIDATE)
    assert.equal(status, 1)
    assert.match(stderr, /缺少 \.agents\/plugins\/marketplace\.json/)

    assert.equal(runScript(fixture, SYNC, ['--apply']).status, 0)
    const restored = readFixture(fixture, '.agents', 'plugins', 'marketplace.json')
    assert.match(restored, /"plugins": \[/)
    assert.match(restored, /"gh-skill-optimizer"/)
    assert.equal(runScript(fixture, VALIDATE).status, 0)
  })
})

test('README 表格少了插件：报表格不一致', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'README.md')(/^\|`gh-skill-optimizer`\|[^\n]*\n/m, '')
    const { status, stderr } = runScript(fixture, VALIDATE)
    assert.equal(status, 1)
    assert.match(stderr, /表格的插件名或顺序与市场清单不一致/)
  })
})

test('README 表格顺序与清单不一致：同样报错', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'README.md')(
      /^(\|`[^`]+`\|[^\n]*\n)(\|`[^`]+`\|[^\n]*\n)/m,
      (_match, first, second) => second + first,
    )
    const { status, stderr } = runScript(fixture, VALIDATE)
    assert.equal(status, 1)
    assert.match(stderr, /表格的插件名或顺序与市场清单不一致/)
  })
})

test('缺 test-prompts.json：只警告，退出码仍为 0', () => {
  withFixture((fixture) => {
    unlinkSync(join(fixture, 'plugins/common/workflow/skills/gh-workflow/test-prompts.json'))
    const { status, stdout, stderr } = runScript(fixture, VALIDATE)
    assert.equal(status, 0)
    assert.match(stderr, /skills\/gh-workflow 缺少 test-prompts\.json，无法做 L2 行为实测/)
    assertValidationSummary(fixture, stdout, 1)
  })
})

test('Claude skill invocation must agree with the Codex manual-only policy', () => {
  withFixture((fixture) => {
    const path = join(fixture, 'plugins/common/workflow/skills/gh-workflow/SKILL.md')
    const before = readFileSync(path, 'utf8')
    writeFileSync(path, before.replace(/^disable-model-invocation:.*\n/m, ''))
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /gh-workflow.*disable-model-invocation/)
  })
})

test('manual-only command wrappers cannot allow implicit invocation', () => {
  withFixture((fixture) => {
    const path = join(fixture, 'plugins/common/workflow/commands/gh-workflow.md')
    writeFileSync(path, readFileSync(path, 'utf8').replace(/^disable-model-invocation:.*\n/m, ''))
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /commands\/gh-workflow.md.*disable-model-invocation/)
  })
})

test('a manual-only claim cannot enable implicit invocation in Codex', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'plugins/common/workflow/skills/gh-workflow/agents/openai.yaml')(
      /allow_implicit_invocation: false/,
      'allow_implicit_invocation: true',
    )
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /gh-workflow.*allow_implicit_invocation/)
  })
})

test('folded descriptions are valid; descriptions above 1024 characters are rejected', () => {
  withFixture((fixture) => {
    const path = join(fixture, 'plugins/common/skill-optimizer/skills/gh-skill-optimizer/SKILL.md')
    const original = readFileSync(path, 'utf8')
    const concise = 'description: >\n  Review agent instructions.\n  Use for skill reviews,\n  rule conflicts,\n  and unclear workflows.\n'
    writeFileSync(path, original.replace(/^description:.*\n/m, concise))
    assert.equal(runScript(fixture, VALIDATE).status, 0)
    writeFileSync(path, original.replace(/^description:.*\n/m, `description: ${'x'.repeat(1025)}\n`))
    const result = runScript(fixture, VALIDATE)
    assert.equal(result.status, 1)
    assert.match(result.stderr, /gh-skill-optimizer.*1024/)
  })
})

test('生成器：dry-run 不写盘，--apply 修复后校验通过', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'docs', 'settings-snippet.json')(
      /\s*"gh-skill-optimizer@gh-tools": true,/,
      '',
    )
    assert.equal(runScript(fixture, VALIDATE).status, 1)

    const dryRun = runScript(fixture, SYNC)
    assert.equal(dryRun.status, 1)
    assert.match(dryRun.stdout, /待更新 1 个/)
    assert.doesNotMatch(
      readFixture(fixture, 'docs', 'settings-snippet.json'),
      /gh-skill-optimizer/,
      'dry-run 不该写盘',
    )

    const applied = runScript(fixture, SYNC, ['--apply'])
    assert.equal(applied.status, 0)
    assert.match(readFixture(fixture, 'docs', 'settings-snippet.json'), /gh-skill-optimizer/)

    const after = runScript(fixture, VALIDATE)
    assert.equal(after.status, 0)
    assertValidationSummary(fixture, after.stdout)
  })
})

test('生成器：标记缺失时拒绝生成', () => {
  withFixture((fixture) => {
    patchFile(fixture, 'README.md')(/<!-- sync:end claude-install-cli -->\n/, '')
    const { status, stderr } = runScript(fixture, SYNC)
    assert.equal(status, 1)
    assert.match(stderr, /README\.md 缺少 sync 标记：claude-install-cli/)
  })
})

test('改权威 description：清单与 Codex 副本一起被拦，一次 --apply 全部跟上', () => {
  withFixture((fixture) => {
    // 权威在插件自己的 .claude-plugin/plugin.json，另外两处是副本
    patchFile(fixture, 'plugins', 'common', 'workflow', '.claude-plugin', 'plugin.json')(
      /"description": "[^"]*"/,
      '"description": "Changed authoritative workflow description. Manual invocation only."',
    )

    const checked = runScript(fixture, VALIDATE)
    assert.equal(checked.status, 1)
    assert.match(
      checked.stderr,
      /清单里 plugin "gh-workflow" 的 description 与它自己的 \.claude-plugin\/plugin\.json 不一致/,
    )
    assert.match(
      checked.stderr,
      /plugins\/common\/workflow\/\.codex-plugin\/plugin\.json 与市场清单不同步/,
    )

    assert.equal(runScript(fixture, SYNC, ['--apply']).status, 0)

    const claude = JSON.parse(
      readFixture(fixture, 'plugins', 'common', 'workflow', '.claude-plugin', 'plugin.json'),
    )
    const codex = JSON.parse(
      readFixture(fixture, 'plugins', 'common', 'workflow', '.codex-plugin', 'plugin.json'),
    )
    const listed = JSON.parse(readFixture(fixture, '.claude-plugin', 'marketplace.json')).plugins.find(
      (plugin) => plugin.name === 'gh-workflow',
    )

    assert.equal(claude.description, 'Changed authoritative workflow description. Manual invocation only.')
    assert.equal(codex.description, claude.description, 'Codex 副本没跟上')
    assert.equal(listed.description, claude.description, '清单条目没跟上')
    assert.equal(runScript(fixture, VALIDATE).status, 0)
  })
})

test('手改 Codex description：被拦，--apply 逐字节修回且不留格式噪声', () => {
  withFixture((fixture) => {
    const rel = ['plugins', 'common', 'workflow', '.codex-plugin', 'plugin.json']
    const pristine = readFixture(fixture, ...rel)

    patchFile(fixture, ...rel)(
      /"description": "[^"]*"/,
      '"description": "hand written, manual via /gh-workflow"',
    )

    const checked = runScript(fixture, VALIDATE)
    assert.equal(checked.status, 1)
    assert.match(
      checked.stderr,
      /plugins\/common\/workflow\/\.codex-plugin\/plugin\.json 与市场清单不同步/,
    )

    assert.equal(runScript(fixture, SYNC, ['--apply']).status, 0)
    // 逐字节比回原文：证明替换只动了 description 那一个值。
    // 若改成 JSON.parse + stringify 重写，keywords 数组会被展开成多行，这条立刻失败。
    assert.equal(readFixture(fixture, ...rel), pristine)
  })
})

test('手改清单条目的 description：报错指名插件与权威，不再自指', () => {
  withFixture((fixture) => {
    patchFile(fixture, '.claude-plugin', 'marketplace.json')(
      /("name": "gh-workflow",[\s\S]*?"description": ")[^"]*(")/,
      '$1workflow description edited by hand$2',
    )
    const { status, stderr } = runScript(fixture, VALIDATE)
    assert.equal(status, 1)
    assert.match(
      stderr,
      /清单里 plugin "gh-workflow" 的 description 与它自己的 \.claude-plugin\/plugin\.json 不一致/,
    )
    // 旧文案是「.claude-plugin/marketplace.json 与市场清单不同步」——它自己就是市场清单，
    // 既自指又没说是哪个字段。这条钉住它不会再回来。
    assert.doesNotMatch(stderr, /\.claude-plugin\/marketplace\.json 与市场清单不同步/)
  })
})

test('--apply 覆盖手写的清单 description：输出说明覆盖了哪一项', () => {
  withFixture((fixture) => {
    patchFile(fixture, '.claude-plugin', 'marketplace.json')(
      /("name": "gh-workflow",[\s\S]*?"description": ")[^"]*(")/,
      '$1hand written description$2',
    )
    const applied = runScript(fixture, SYNC, ['--apply'])
    assert.equal(applied.status, 0)
    // 手写内容会被丢弃——输出必须说明是「被覆盖」，否则改动凭空消失，看起来像生成器出错
    assert.match(
      applied.stdout,
      /note 清单里 "gh-workflow" 的 description 已按插件自己的 \.claude-plugin\/plugin\.json 覆盖/,
    )
    // 被覆盖后应与权威值逐字相同（不写死文案，避免描述改措辞时用例失效）
    const authoritative = JSON.parse(
      readFixture(fixture, 'plugins', 'common', 'workflow', '.claude-plugin', 'plugin.json'),
    )
    const listed = JSON.parse(
      readFixture(fixture, '.claude-plugin', 'marketplace.json'),
    ).plugins.find((plugin) => plugin.name === 'gh-workflow')
    assert.equal(listed.description, authoritative.description)
  })
})
