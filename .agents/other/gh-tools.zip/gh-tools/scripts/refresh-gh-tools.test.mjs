import test from 'node:test'
import assert from 'node:assert/strict'

import { lstatSync, mkdtempSync, mkdirSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import {
  buildActions,
  collectSkills,
  expandExecutableCandidates,
  findExecutable,
  main,
  needsWindowsShell,
  normalizeInstalled,
  parseArgs,
  planCursorActions,
  selectMarketplacePlugins,
  symlinkTypeFor,
  workbuddyCandidates,
} from '../tools/refresh-gh-tools.mjs'

test('parseArgs defaults to every supported client in dry-run mode', () => {
  assert.deepEqual(parseArgs([]), {
    apply: false,
    help: false,
    clients: ['codex', 'claude', 'workbuddy'],
    explicitClients: false,
  })
})

test('parseArgs accepts multiple client selectors without duplicates', () => {
  assert.deepEqual(parseArgs(['--apply', '--claude', '--codex', '--claude']), {
    apply: true,
    help: false,
    clients: ['claude', 'codex'],
    explicitClients: true,
  })
})

test('parseArgs keeps Cursor opt-in while accepting its selector', () => {
  assert.deepEqual(parseArgs(['--cursor']), {
    apply: false,
    help: false,
    clients: ['cursor'],
    explicitClients: true,
  })
})

test('parseArgs keeps OpenCode opt-in while accepting its selector', () => {
  assert.deepEqual(parseArgs(['--opencode']), {
    apply: false,
    help: false,
    clients: ['opencode'],
    explicitClients: true,
  })
})

test('parseArgs keeps Kiro opt-in while accepting its selector', () => {
  assert.deepEqual(parseArgs(['--kiro']), {
    apply: false,
    help: false,
    clients: ['kiro'],
    explicitClients: true,
  })
})

test('opencode preview runs the shared skills-dir sync without writes', () => {
  assert.equal(main(['--opencode']), 0)
})

test('kiro preview runs the shared skills-dir sync without writes', () => {
  assert.equal(main(['--kiro']), 0)
})

test('parseArgs rejects unknown options', () => {
  assert.throws(() => parseArgs(['--all']), /未知参数/)
})

test('normalizeInstalled understands Codex and Claude-compatible list shapes', () => {
  assert.deepEqual(
    normalizeInstalled('codex', {
      installed: [{ pluginId: 'gh-workflow@gh-tools', enabled: true }],
    }),
    [
      {
        id: 'gh-workflow@gh-tools',
        enabled: true,
        scope: 'user',
        projectPath: undefined,
        marketplaceSourceType: undefined,
      },
    ],
  )

  assert.deepEqual(
    normalizeInstalled('claude', [
      { id: 'gh-prompt-assistant@gh-tools', scope: 'project', projectPath: '/tmp/project' },
    ]),
    [
      {
        id: 'gh-prompt-assistant@gh-tools',
        enabled: undefined,
        scope: 'project',
        projectPath: '/tmp/project',
        marketplaceSourceType: undefined,
      },
    ],
  )
})

test('selection keeps installed repository plugins and reports stale entries', () => {
  const result = selectMarketplacePlugins(
    [
      { id: 'gh-workflow@gh-tools' },
      { id: 'removed@gh-tools' },
      { id: 'other@elsewhere' },
    ],
    'gh-tools',
    ['gh-workflow'],
  )

  assert.deepEqual(result.selected.map((plugin) => plugin.name), ['gh-workflow'])
  assert.deepEqual(result.stale.map((plugin) => plugin.id), ['removed@gh-tools'])
})

test('Codex actions upgrade once and reinstall only enabled plugins', () => {
  const actions = buildActions(
    'codex',
    [
      { id: 'gh-workflow@gh-tools', enabled: true },
      { id: 'gh-review@gh-tools', enabled: false },
    ],
    'gh-tools',
  )

  assert.deepEqual(
    actions.map((action) => action.kind),
    ['upgrade', 'remove', 'add'],
  )
  assert.equal(actions[1].pluginId, 'gh-workflow@gh-tools')
})

test('Claude-compatible actions preserve scope and project directory', () => {
  const [action] = buildActions(
    'workbuddy',
    [
      {
        id: 'gh-workflow@gh-tools',
        scope: 'project',
        projectPath: '/tmp/project',
      },
    ],
    'gh-tools',
  )

  assert.deepEqual(action.args, [
    'plugin',
    'update',
    '--scope',
    'project',
    'gh-workflow@gh-tools',
  ])
  assert.equal(action.cwd, '/tmp/project')
})

test('symlink type uses junction on Windows only, plain links elsewhere', () => {
  assert.equal(symlinkTypeFor('darwin'), undefined)
  assert.equal(symlinkTypeFor('linux'), undefined)
  assert.equal(symlinkTypeFor('win32'), 'junction')
})

test('Windows executable discovery tries PATHEXT candidates', () => {
  assert.deepEqual(expandExecutableCandidates('codex', 'win32', '.EXE;.CMD'), [
    'codex',
    'codex.exe',
    'codex.cmd',
  ])
  assert.deepEqual(expandExecutableCandidates('codex.exe', 'win32', '.CMD'), ['codex.exe'])
})

test('Windows command shims are launched through the command shell', () => {
  assert.equal(needsWindowsShell('C:\\tools\\codex.cmd', 'win32'), true)
  assert.equal(needsWindowsShell('C:\\tools\\claude.bat', 'win32'), true)
  assert.equal(needsWindowsShell('C:\\tools\\codex.exe', 'win32'), false)
  assert.equal(needsWindowsShell('/usr/local/bin/codex.cmd', 'darwin'), false)
})

test('WorkBuddy discovery includes the real ProgramFiles(x86) environment key', () => {
  const candidates = workbuddyCandidates('win32', {
    'ProgramFiles(x86)': 'C:\\Program Files (x86)',
  })
  assert.equal(
    candidates.some((candidate) => candidate.includes('Program Files (x86)')),
    true,
  )
})

test('executable discovery works with a Windows-style extension in a fake PATH', () => {
  const root = mkdtempSync(join(tmpdir(), 'gh-tools-bin-'))
  try {
    const executable = join(root, 'codex.exe')
    writeFileSync(executable, '')
    // chmod is intentionally omitted: Windows discovery does not use POSIX mode bits.
    assert.equal(findExecutable(['codex'], root, 'win32'), executable)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('explicitly requested missing client returns a failure exit code', () => {
  const previousPath = process.env.PATH
  const hadPath = Object.hasOwn(process.env, 'PATH')
  process.env.PATH = ''
  try {
    assert.equal(main(['--codex']), 1)
  } finally {
    if (hadPath) process.env.PATH = previousPath
    else delete process.env.PATH
  }
})

function makeFakeRepo() {
  const root = mkdtempSync(join(tmpdir(), 'gh-tools-test-'))
  const skillA = join(root, 'plugins', 'common', 'alpha', 'skills', 'skill-a')
  const skillB = join(root, 'plugins', 'flutter', 'beta', 'skills', 'skill-b')
  for (const dir of [skillA, skillB]) {
    mkdirSync(dir, { recursive: true })
    writeFileSync(join(dir, 'SKILL.md'), '---\nname: x\ndescription: x\n---\n')
  }
  return { root, skillA, skillB }
}

test('collectSkills finds every SKILL.md under plugins/ with sorted names', () => {
  const { root, skillA, skillB } = makeFakeRepo()
  try {
    assert.deepEqual(collectSkills(root), [
      { name: 'skill-a', path: skillA },
      { name: 'skill-b', path: skillB },
    ])
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('planCursorActions creates missing links and relinks outdated ones', () => {
  const { root, skillA, skillB } = makeFakeRepo()
  const skillsDir = mkdtempSync(join(tmpdir(), 'cursor-skills-'))
  try {
    // skill-a 已存在但指向别处；skill-b 缺失
    const stale = join(root, 'elsewhere')
    mkdirSync(stale)
    symlinkSync(stale, join(skillsDir, 'skill-a'))

    const { actions, conflicts } = planCursorActions(
      collectSkills(root),
      skillsDir,
      root,
    )

    assert.deepEqual(conflicts, [])
    const byKind = Object.fromEntries(actions.map((a) => [a.kind, a]))
    assert.equal(byKind.relink.name, 'skill-a')
    assert.equal(byKind.relink.target, skillA)
    assert.equal(byKind.create.name, 'skill-b')
    assert.equal(byKind.create.target, skillB)
  } finally {
    rmSync(skillsDir, { recursive: true, force: true })
    rmSync(root, { recursive: true, force: true })
  }
})

test('planCursorActions removes only orphan links pointing into the repo', () => {
  const { root } = makeFakeRepo()
  const skillsDir = mkdtempSync(join(tmpdir(), 'cursor-skills-'))
  try {
    // repo-gone 指向本仓库但 skill 已删除；foreign 指向外部，不动
    symlinkSync(join(root, 'plugins', 'removed'), join(skillsDir, 'repo-gone'))
    const foreignTarget = mkdtempSync(join(tmpdir(), 'foreign-'))
    symlinkSync(foreignTarget, join(skillsDir, 'foreign'))
    // no-symlink 是普通目录，报 conflict 而不是动作
    mkdirSync(join(skillsDir, 'no-symlink'))

    const { actions, conflicts } = planCursorActions(
      collectSkills(root),
      skillsDir,
      root,
    )

    assert.deepEqual(actions.map((a) => a.kind).sort(), ['create', 'create', 'remove'])
    const removed = actions.find((a) => a.kind === 'remove')
    assert.equal(removed.name, 'repo-gone')
    assert.deepEqual(conflicts.map((c) => c.name), ['no-symlink'])
    rmSync(foreignTarget, { recursive: true, force: true })
  } finally {
    rmSync(skillsDir, { recursive: true, force: true })
    rmSync(root, { recursive: true, force: true })
  }
})

test('planCursorActions does not replace a same-name external link', () => {
  const { root } = makeFakeRepo()
  const skillsDir = mkdtempSync(join(tmpdir(), 'cursor-skills-'))
  try {
    const foreignRoot = mkdtempSync(join(tmpdir(), 'foreign-'))
    const foreignSkill = join(foreignRoot, 'skill-a')
    mkdirSync(foreignSkill)
    symlinkSync(foreignSkill, join(skillsDir, 'skill-a'))

    const { actions, conflicts } = planCursorActions(
      collectSkills(root),
      skillsDir,
      root,
    )

    assert.equal(actions.some((action) => action.name === 'skill-a'), false)
    assert.deepEqual(conflicts.map((conflict) => conflict.name), ['skill-a'])
    rmSync(foreignRoot, { recursive: true, force: true })
  } finally {
    rmSync(skillsDir, { recursive: true, force: true })
    rmSync(root, { recursive: true, force: true })
  }
})

for (const kind of ['file', 'directory']) {
  test(`planCursorActions preserves a same-name regular ${kind}`, () => {
    const { root, skillB } = makeFakeRepo()
    const skillsDir = mkdtempSync(join(tmpdir(), 'client-skills-'))
    try {
      const existing = join(skillsDir, 'skill-a')
      if (kind === 'directory') mkdirSync(existing)
      const contentPath = kind === 'directory' ? join(existing, 'SKILL.md') : existing
      const content = 'Existing user content must be preserved.\n'
      writeFileSync(contentPath, content)

      const { actions, conflicts } = planCursorActions(
        collectSkills(root),
        skillsDir,
        root,
      )

      assert.deepEqual(conflicts.map((conflict) => conflict.name), ['skill-a'])
      assert.deepEqual(actions, [
        {
          kind: 'create',
          name: 'skill-b',
          linkPath: join(skillsDir, 'skill-b'),
          target: skillB,
        },
      ])
      const existingStat = lstatSync(existing)
      assert.equal(existingStat.isSymbolicLink(), false)
      assert.equal(existingStat.isDirectory(), kind === 'directory')
      assert.equal(readFileSync(contentPath, 'utf8'), content)
    } finally {
      rmSync(skillsDir, { recursive: true, force: true })
      rmSync(root, { recursive: true, force: true })
    }
  })
}

test('planCursorActions uses the declared skill name for its destination', () => {
  const { root, skillA } = makeFakeRepo()
  const skillsDir = mkdtempSync(join(tmpdir(), 'cursor-skills-'))
  try {
    const repoSkills = [{ name: 'declared-name', path: skillA }]
    const { actions, conflicts } = planCursorActions(repoSkills, skillsDir, root)
    assert.deepEqual(conflicts, [])
    assert.deepEqual(actions, [
      {
        kind: 'create',
        name: 'declared-name',
        linkPath: join(skillsDir, 'declared-name'),
        target: skillA,
      },
    ])
  } finally {
    rmSync(skillsDir, { recursive: true, force: true })
    rmSync(root, { recursive: true, force: true })
  }
})
