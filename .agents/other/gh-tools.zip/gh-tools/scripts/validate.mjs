#!/usr/bin/env node
/**
 * 校验插件市场清单的一致性。只读，不修改任何文件。
 *
 * 检查项：
 *   1. 权威清单 .claude-plugin/marketplace.json 的必填字段与结构
 *   2. 每个 plugin 的 source 路径存在，且含 .claude-plugin/plugin.json + .codex-plugin/plugin.json
 *   3. plugin.json 的 name / version 与 marketplace 清单一致
 *   4. 全仓库统一版本：所有 plugin 版本与 marketplace metadata.version 相同
 *   5. commands / skills 声明的路径真实存在
 *   6. SKILL.md frontmatter 含 name 与 description，且 name 与目录名一致
 *   7. 每个 skill 含 agents/openai.yaml
 *   8. 生成物与权威源同步：.agents/plugins/marketplace.json、docs/ 两个片段、
 *      README 的 sync 区块、以及清单与各 Codex plugin.json 的 description，
 *      都由 scripts/sync-install-docs.mjs 产出，这里比对磁盘上的是不是最新
 *   9. README「插件清单」表格的插件名与顺序和清单一致（文案仍手写）
 *  10. 每个 skill 带 test-prompts.json（缺语料只警告，不阻断）
 *  11. Skill description 不超过 1024 字符；手动调用策略在 Skill、Codex 和 command 入口一致
 *  12. 插件与 Skill 使用 gh- 完整名称，显示名与显式调用入口保持一致
 *
 * 用法：node scripts/validate.mjs
 * 退出码：0 = 全部通过，1 = 有错误
 */

import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs'
import { join, dirname, resolve, basename } from 'node:path'
import { fileURLToPath } from 'node:url'

import { buildArtifacts } from './sync-install-docs.mjs'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')

const errors = []
const warnings = []

const err = (msg) => errors.push(msg)
const warn = (msg) => warnings.push(msg)

/** 读 JSON，解析失败记为错误并返回 null */
function readJson(path, label) {
  try {
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch (e) {
    err(`${label}: 无法解析 JSON — ${e.message}`)
    return null
  }
}

/** 极简 frontmatter 解析：只取顶层 key: value，够用于校验必填项 */
function parseFrontmatter(content) {
  const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---/)
  if (!match) return null
  const fields = {}
  let currentKey = null
  for (const line of match[1].split(/\r?\n/)) {
    const kv = line.match(/^([A-Za-z][A-Za-z0-9_-]*):\s*(.*)$/)
    if (kv) {
      currentKey = kv[1]
      fields[currentKey] = kv[2].trim()
    } else if (currentKey && /^\s+\S/.test(line)) {
      // 多行值（> 或 | 折叠块）：拼接续行，只为判断非空
      fields[currentKey] = `${fields[currentKey]} ${line.trim()}`.trim()
    }
  }
  return fields
}

/** 去掉 YAML 标量的引号与折叠标记 */
function cleanScalar(value) {
  if (!value) return ''
  let out = value.replace(/^[>|][-+]?\s*/, '').trim()
  // 只剥「首尾是同一种引号」的配对；用贪婪的 ^["'](.*)["']$ 会把值中间的引号一起吃掉。
  if (out.length >= 2) {
    const first = out[0]
    if ((first === '"' || first === "'") && out[out.length - 1] === first) {
      out = out.slice(1, -1)
    }
  }
  return out.trim()
}

/** 只读取 policy 区块的调用开关，不依赖整个 YAML 的其它字段或缩进顺序。 */
function implicitInvocation(content) {
  const lines = content.replace(/\r\n/g, '\n').split('\n').filter((line) => !/^\s*(?:#.*)?$/.test(line)).join('\n')
  const policy = lines.match(/^policy:[ \t]*(?:#.*)?\n((?:[ \t]+[^\n]*(?:\n|$))*)/m)?.[1] ?? ''
  return policy.match(/^[ \t]+allow_implicit_invocation:[ \t]*(true|false)[ \t]*(?:#.*)?$/m)?.[1]
}

/** 调用策略只接受布尔标量；行尾注释不属于值。 */
function invocationBoolean(value) {
  return value?.trim().match(/^(true|false)(?:[ \t]+#.*)?$/)?.[1]
}

/** 仓库的公开能力名使用 gh- 前缀，功能词展开常见旧缩写。 */
function fullCapabilityName(name) {
  return /^gh-[a-z0-9]+(?:-[a-z0-9]+)*$/.test(name) && !/-(?:gen|init|compat)(?:-|$)/.test(name)
}

/** 显示名保留完整调用名，允许在约定分隔符后追加中文说明。 */
function matchesDisplayName(displayName, name) {
  if (displayName === name) return true
  const prefix = `${name} · `
  return typeof displayName === 'string' && displayName.startsWith(prefix) &&
    /\p{Script=Han}/u.test(displayName.slice(prefix.length))
}

/** 精确匹配调用 token，避免把 $gh-review-extra 当成 $gh-review。 */
function hasInvocation(prompt, name) {
  return typeof prompt === 'string' && (prompt.match(/\$[a-zA-Z0-9_-]+/g) ?? []).includes(`$${name}`)
}

/** 读取 interface 内的单行标量；接受空行、注释与 CRLF。 */
function interfaceScalars(content) {
  const lines = content.replace(/\r\n/g, '\n').split('\n')
    .filter((line) => !/^\s*(?:#.*)?$/.test(line)).join('\n')
  const block = lines.match(/^interface:[ \t]*(?:#.*)?\n((?:[ \t]+[^\n]*(?:\n|$))*)/m)?.[1] ?? ''
  const fields = {}
  for (const match of block.matchAll(/^[ \t]+([a-z_]+):[ \t]*([^\n]*)/gm)) {
    const quoted = match[2].match(/^("(?:\\.|[^"\\])*"|'(?:''|[^'])*')[ \t]*(?:#.*)?$/)
    fields[match[1]] = cleanScalar(quoted?.[1] ?? match[2].replace(/[ \t]+#.*$/, ''))
  }
  return fields
}

// ---------- 1. Claude Code marketplace.json ----------

const claudeMarketplacePath = join(ROOT, '.claude-plugin', 'marketplace.json')
if (!existsSync(claudeMarketplacePath)) {
  err('缺少 .claude-plugin/marketplace.json')
  report()
}

const claudeMarketplace = readJson(claudeMarketplacePath, 'Claude marketplace.json')
if (!claudeMarketplace) report()

if (!claudeMarketplace.name) err('Claude marketplace.json: 缺少 name')
if (!claudeMarketplace.owner?.name) err('Claude marketplace.json: 缺少 owner.name')
if (!Array.isArray(claudeMarketplace.plugins)) {
  err('Claude marketplace.json: plugins 必须是数组')
  report()
}

const repoVersion = claudeMarketplace.metadata?.version
if (!repoVersion) {
  err('Claude marketplace.json: 缺少 metadata.version（全仓库统一版本）')
} else if (!/^\d+\.\d+\.\d+$/.test(repoVersion)) {
  err(`Claude marketplace.json: metadata.version "${repoVersion}" 不是 semver`)
}

// ---------- 1b. Codex 清单是生成物 ----------
// .agents/plugins/marketplace.json 由 scripts/sync-install-docs.mjs 从上面的权威清单产出：
// name / interface 取自市场名，每个 plugin 的 source.path 取自清单的 source，category 走生成器
// 里的对照表。所以这里不再单独校验它的结构或插件集合——它是不是最新，1c 段的逐字节比对负责拦。

// ---------- 1c. 生成物与权威源同步 ----------
// 生成物由 scripts/sync-install-docs.mjs 产出，这里只比对「磁盘上的是不是最新」。
// 字段级产物（清单与 Codex plugin.json 的 description）要先读磁盘当前内容才能算出期望值，
// 所以「期望 == 当前」本身就等价于「已同步」。
// 仍然手写的只有 README 的「插件清单」表格：文案靠人，插件名与顺序由校验兜底。

const claudePluginOrder = claudeMarketplace.plugins.map((plugin) => plugin.name)

const { artifacts, problems } = buildArtifacts(ROOT)

for (const artifact of artifacts) {
  const path = join(ROOT, artifact.path)
  if (!existsSync(path)) {
    err(`缺少 ${artifact.path}`)
    continue
  }
  const current = readFileSync(path, 'utf8')
  const expected = artifact.render(current)
  if (expected === null) continue
  if (current === expected) continue

  // 权威清单本身：description 是里面唯一的派生字段，报错要落到「哪个插件、权威在哪」。
  // 笼统报「marketplace.json 与市场清单不同步」是自指的——它自己就是市场清单。
  const drifted = artifact.mismatchedDescriptions?.() ?? []
  if (drifted.length > 0) {
    for (const name of drifted) {
      err(
        `清单里 plugin "${name}" 的 description 与它自己的 .claude-plugin/plugin.json 不一致 — ` +
          '权威在 plugin.json，清单这份是派生的，跑 node scripts/sync-install-docs.mjs --apply 同步',
      )
    }
  } else if (typeof artifact.mismatchedDescriptions === 'function') {
    // 兜底。清单的 render 只改 description，description 全对得上时 render 原样返回、不会 stale，
    // 所以这条现在走不到。留着是为了将来给清单加别的派生字段时不会静默漏掉。
    err(
      `${artifact.path} 是权威清单本身，内容与生成器期望的不一致 — ` +
        '跑 node scripts/sync-install-docs.mjs --apply 修回',
    )
  } else {
    err(
      `${artifact.path} 与市场清单不同步 — 跑 node scripts/sync-install-docs.mjs --apply 重新生成`,
    )
  }
}

for (const problem of problems) err(problem)

const readmePath = join(ROOT, 'README.md')
if (existsSync(readmePath)) {
  const section = readFileSync(readmePath, 'utf8').match(
    /^## 插件清单\r?\n([\s\S]*?)(?=\r?\n## )/m,
  )
  if (!section) {
    err('README.md: 找不到「插件清单」章节')
  } else {
    const tableNames = [...section[1].matchAll(/^\|`([^`]+)`\|/gm)].map((match) => match[1])
    if (tableNames.length === 0) {
      err('README.md: 「插件清单」表格里没解析出插件名')
    } else if (JSON.stringify(tableNames) !== JSON.stringify(claudePluginOrder)) {
      err(
        'README.md: 「插件清单」表格的插件名或顺序与市场清单不一致\n' +
          `  清单: [${claudePluginOrder.join(', ')}]\n` +
          `  表格: [${tableNames.join(', ')}]`,
      )
    }
  }
}

// ---------- 2~5. 逐个 plugin ----------

const seenNames = new Set()

for (const entry of claudeMarketplace.plugins) {
  const label = `plugin "${entry.name ?? '<未命名>'}"`

  if (!entry.name) {
    err('Claude marketplace.json: 有 plugin 缺少 name')
    continue
  }
  if (seenNames.has(entry.name)) err(`${label}: 名称重复`)
  seenNames.add(entry.name)

  if (!fullCapabilityName(entry.name)) {
    err(`${label}: 安装名必须使用 gh- 完整名称，不使用 gen、init、compat 简称`)
  }

  if (!entry.description) err(`${label}: 缺少 description`)
  if (!entry.category) warn(`${label}: 缺少 category，/plugin 列表不会分类展示`)

  if (typeof entry.source !== 'string') {
    err(`${label}: source 必须是相对路径字符串（本仓库约定 plugin 与市场同仓）`)
    continue
  }

  const pluginDir = join(ROOT, entry.source)
  if (!existsSync(pluginDir) || !statSync(pluginDir).isDirectory()) {
    err(`${label}: source 路径不存在 — ${entry.source}`)
    continue
  }

  // Claude Code manifest
  const claudeManifestPath = join(pluginDir, '.claude-plugin', 'plugin.json')
  if (!existsSync(claudeManifestPath)) {
    err(`${label}: 缺少 ${entry.source}/.claude-plugin/plugin.json`)
    continue
  }

  const claudeManifest = readJson(claudeManifestPath, `${label} Claude plugin.json`)
  if (!claudeManifest) continue

  if (claudeManifest.name !== entry.name) {
    err(`${label}: Claude plugin.json 的 name "${claudeManifest.name}" 与清单不一致`)
  }
  // 清单条目缺 version 时不能静默跳过一致性检查：全仓库统一版本要求一个都不能漏。
  if (!entry.version) {
    err(`${label}: 清单条目缺少 version`)
  } else if (claudeManifest.version !== entry.version) {
    err(
      `${label}: Claude plugin.json 版本 "${claudeManifest.version}" 与清单 "${entry.version}" 不一致`,
    )
  }
  if (repoVersion && claudeManifest.version !== repoVersion) {
    err(`${label}: Claude 版本 "${claudeManifest.version}" 未跟随全仓库版本 "${repoVersion}"`)
  }

  // Codex manifest
  const codexManifestPath = join(pluginDir, '.codex-plugin', 'plugin.json')
  if (!existsSync(codexManifestPath)) {
    err(`${label}: 缺少 ${entry.source}/.codex-plugin/plugin.json`)
    continue
  }

  const codexManifest = readJson(codexManifestPath, `${label} Codex plugin.json`)
  if (!codexManifest) continue

  if (codexManifest.name !== entry.name) {
    err(`${label}: Codex plugin.json 的 name "${codexManifest.name}" 与清单不一致`)
  }
  if (codexManifest.version !== claudeManifest.version) {
    err(
      `${label}: Codex 版本 "${codexManifest.version}" 与 Claude 版本 "${claudeManifest.version}" 不一致`,
    )
  }
  if (repoVersion && codexManifest.version !== repoVersion) {
    err(`${label}: Codex 版本 "${codexManifest.version}" 未跟随全仓库版本 "${repoVersion}"`)
  }

  // commands 声明的路径（仅 Claude Code 支持）
  for (const cmd of claudeManifest.commands ?? []) {
    const cmdPath = join(pluginDir, cmd)
    if (!existsSync(cmdPath)) err(`${label}: commands 声明的文件不存在 — ${cmd}`)
  }

  // skills 目录：约定 skills/<name>/SKILL.md + agents/openai.yaml
  const skillsDir = join(pluginDir, 'skills')
  if (existsSync(skillsDir)) {
    const skillNames = readdirSync(skillsDir).filter((n) =>
      statSync(join(skillsDir, n)).isDirectory(),
    )
    if (skillNames.length === 0) warn(`${label}: skills/ 为空目录`)

    for (const skillName of skillNames) {
      if (!fullCapabilityName(skillName)) {
        err(`${label}: skills/${skillName} 必须使用 gh- 完整名称，不使用 gen、init、compat 简称`)
      }
      if (skillNames.length === 1 && entry.name !== skillName) {
        err(`${label}: 安装名与唯一 Skill 调用名 "${skillName}" 不一致`)
      }
      const skillPath = join(skillsDir, skillName, 'SKILL.md')
      if (!existsSync(skillPath)) {
        err(`${label}: skills/${skillName} 缺少 SKILL.md`)
        continue
      }

      const fm = parseFrontmatter(readFileSync(skillPath, 'utf8'))
      if (!fm) {
        err(`${label}: skills/${skillName}/SKILL.md 缺少 frontmatter`)
        continue
      }

      const name = cleanScalar(fm.name)
      const description = cleanScalar(fm.description)

      if (fm.description && !/^["'>|]/.test(fm.description) && /:(?:\s|$)/.test(fm.description)) {
        err(`${label}: skills/${skillName}/SKILL.md 的 description 含冒号时必须加引号或使用多行块，避免 YAML 元数据被忽略`)
      }

      if (!name) {
        err(`${label}: skills/${skillName}/SKILL.md frontmatter 缺少 name`)
      } else if (name !== skillName) {
        err(`${label}: skills/${skillName}/SKILL.md 的 name "${name}" 与目录名不一致`)
      }

      if (!description) {
        err(`${label}: skills/${skillName}/SKILL.md frontmatter 缺少 description`)
      } else if ([...description].length > 1024) {
        err(`${label}: skills/${skillName} 的 description 超过 1024 字符`)
      } else if (description.length < 40) {
        warn(
          `${label}: skills/${skillName} 的 description 偏短（${description.length} 字符），` +
            `agent 可能无法判断何时触发`,
        )
      }

      // Codex openai.yaml
      const openaiYamlPath = join(skillsDir, skillName, 'agents', 'openai.yaml')
      if (!existsSync(openaiYamlPath)) {
        err(`${label}: skills/${skillName} 缺少 agents/openai.yaml`)
      } else {
        const yaml = readFileSync(openaiYamlPath, 'utf8')
        const interfaceFields = interfaceScalars(yaml)
        if (!matchesDisplayName(interfaceFields.display_name, skillName)) {
          err(`${label}: skills/${skillName}/agents/openai.yaml 的 display_name 必须保留完整调用名，可追加 " · 中文说明"`)
        }
        if (!hasInvocation(interfaceFields.default_prompt, skillName)) {
          err(`${label}: skills/${skillName}/agents/openai.yaml 的 default_prompt 必须使用完整入口 $${skillName}`)
        }
        if (skillNames.length === 1) {
          if (codexManifest.interface?.displayName !== interfaceFields.display_name) {
            err(`${label}: Codex plugin.json 的 displayName 与 Skill 显示名不一致`)
          }
          const prompts = codexManifest.interface?.defaultPrompt
          if (prompts !== undefined && (!Array.isArray(prompts) || !prompts.some((prompt) => hasInvocation(prompt, skillName)))) {
            err(`${label}: Codex plugin.json 的 defaultPrompt 必须包含完整入口 $${skillName}`)
          }
        }
        const implicit = implicitInvocation(yaml)
        const claudeManual = invocationBoolean(fm['disable-model-invocation']) === 'true'
        const manualClaim = /Manual invocation only\./i.test(description) || /Manual invocation only\./i.test(claudeManifest.description ?? '')
        const manualOnly = manualClaim || claudeManual || implicit === 'false'
        if (manualOnly && !claudeManual) {
          err(`${label}: skills/${skillName}/SKILL.md 仅手动调用时必须设置 disable-model-invocation: true`)
        }
        if (manualOnly && implicit !== 'false') {
          err(`${label}: skills/${skillName}/agents/openai.yaml 仅手动调用时必须设置 policy.allow_implicit_invocation: false`)
        }
        for (const cmd of claudeManifest.commands ?? []) {
          const cmdPath = join(pluginDir, cmd)
          if (!existsSync(cmdPath)) continue
          const content = readFileSync(cmdPath, 'utf8')
          if (!content.includes(`/skills/${skillName}/SKILL.md`)) continue
          if (basename(cmd, '.md') !== skillName) {
            err(`${label}: ${cmd} 的命令名必须与完整 Skill 调用名 ${skillName} 一致`)
          }
          const commandFields = parseFrontmatter(content)
          if (cleanScalar(commandFields?.description) !== interfaceFields.display_name) {
            err(`${label}: ${cmd} 的 description 与 Skill 显示名不一致`)
          }
          const commandManual = invocationBoolean(commandFields?.['disable-model-invocation']) === 'true'
          if (commandManual !== manualOnly) {
            err(`${label}: ${cmd} 的 disable-model-invocation 必须与 skills/${skillName} 的调用策略一致`)
          }
        }
      }

      // 行为实测语料：缺了只警告——实验性 skill 允许暂时没有，但那样做不了 L2。
      // 这里只查存在性；语料写得对不对，得靠实际跑一遍。
      const testPromptsPath = join(skillsDir, skillName, 'test-prompts.json')
      if (!existsSync(testPromptsPath)) {
        warn(`${label}: skills/${skillName} 缺少 test-prompts.json，无法做 L2 行为实测`)
      }
    }

    for (const cmd of claudeManifest.commands ?? []) {
      const cmdPath = join(pluginDir, cmd)
      if (!existsSync(cmdPath)) continue
      const content = readFileSync(cmdPath, 'utf8')
      if (!skillNames.some((name) => content.includes(`/skills/${name}/SKILL.md`))) {
        err(`${label}: ${cmd} 必须引用当前 Skill 的有效入口`)
      }
    }
  }
}

report()

function report() {
  for (const w of warnings) console.warn(`warn  ${w}`)
  for (const e of errors) console.error(`error ${e}`)

  if (errors.length > 0) {
    console.error(`\n校验失败：${errors.length} 个错误，${warnings.length} 个警告`)
    process.exit(1)
  }
  console.log(
    `校验通过：${seenNames?.size ?? 0} 个插件，${warnings.length} 个警告`,
  )
  process.exit(0)
}
