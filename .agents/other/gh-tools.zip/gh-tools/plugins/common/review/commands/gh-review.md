---
description: gh-review · 代码审查
argument-hint: "[审查范围 / Review + Verify 范围 / Verify 已有 Findings / Reverify 编号]"
disable-model-invocation: true
---

按下列共享 Skill 执行；相对引用以 `${CLAUDE_PLUGIN_ROOT}/skills/gh-review/` 为基准：

@${CLAUDE_PLUGIN_ROOT}/skills/gh-review/SKILL.md

用户任务：

$ARGUMENTS
