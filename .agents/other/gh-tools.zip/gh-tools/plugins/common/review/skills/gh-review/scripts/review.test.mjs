import test from 'node:test'
import assert from 'node:assert/strict'
import {
  mkdtempSync, mkdirSync, writeFileSync, readFileSync, existsSync, rmSync, symlinkSync,
  readdirSync, cpSync,
} from 'node:fs'
import { tmpdir } from 'node:os'
import { join, relative, dirname } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { execFileSync, spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import {
  prepare, verify, importResults, complete, status, validateResults, parseClaude,
  config, resolveClaude, claudeArgs, runProcess,
} from './review.mjs'
import { defaultRoot, canonical, json, atomic, clean, acquire, rootLock, makeRun, loadRun, MiB, validateOrigin } from './review-store.mjs'
import { collectProfiles, savedProfiles } from './review-profiles.mjs'
import { evaluationRuleDirectories, evaluationPrompt, evaluationOptions, evaluationFixture, evaluationOracle, validateAdjudicationArtifact, main as evaluateProfiles } from './eval-profiles.mjs'
import { presentReview } from './review-present.mjs'

test('present 零问题标识后展示具体模块、隔离检查记录并保留实质缺口', () => {
  const data = { scope: { kind: 'worktree' }, scopeLabel: '账户缓存清理与离线读取（lib/cache.dart）', findings: [], checks: ['静态检查 0 error；只读，未修改文件'], gaps: ['账户缓存的磁盘写入失败恢复缺少可读取的契约'] }
  assert.equal(presentReview(data), '✅ **No findings**\n\n已审查：账户缓存清理与离线读取（lib/cache.dart）。\n\n未验证：账户缓存的磁盘写入失败恢复缺少可读取的契约。\n')
  assert.equal(presentReview({ ...data, gaps: [] }), '✅ **No findings**\n\n已审查：账户缓存清理与离线读取（lib/cache.dart）。\n')
  assert.throws(() => presentReview({ ...data, scopeLabel: 'x'.repeat(241) }), /scopeLabel/)
})

test('present CLI 从 stdin 只读交付；全部 Refuted 隐藏正文，过期拒绝', (t) => {
  const f = fixture(t)
  const before = readdirSync(f.repo).sort()
  const text = execFileSync(process.execPath, [SCRIPT, 'present', '--input', '-'], {
    cwd: f.repo, input: JSON.stringify({ ...input, scopeLabel: '当前改动', checks: ['不应展示'], gaps: [] }), encoding: 'utf8',
  })
  assert.match(text, /CR-001 \[P1\]/)
  assert.doesNotMatch(text, /不应展示/)
  assert.deepEqual(readdirSync(f.repo).sort(), before)
  const prepared = f.prepare()
  importResults(prepared.run, { results: [{ id: 'CR-001', status: 'Refuted', evidence: '只用于测试的反证' }] }, { apply: true })
  complete(prepared.run, { results: [{ id: 'CR-001', status: 'Refuted', evidence: '只用于测试的反证' }] }, { apply: true })
  const shown = execFileSync(process.execPath, [SCRIPT, 'present', '--run', prepared.run], { encoding: 'utf8' })
  assert.ok(shown.startsWith('✅ **确认 0 项问题**\n\n'))
  assert.match(shown, /确认 0 项，排除 1 项/)
  assert.doesNotMatch(shown, /只用于测试的反证|CR-001/)
  writeFileSync(join(f.repo, 'counter.mjs'), 'changed')
  assert.throws(() => execFileSync(process.execPath, [SCRIPT, 'present', '--run', prepared.run], { stdio: 'pipe' }), /Command failed/)
})

test('present 保留所有独立问题、排序、待确认缺口与普通文本边界', () => {
  const data = { scope: { kind: 'worktree' }, scopeLabel: '当前改动', findings: [
    { id: 'CR-001', priority: 'P2', title: '乱序\n## 标题', claim: '旧结果覆盖新结果', location: { path: 'page.dart', line: 13 } },
    { id: 'CR-002', priority: 'P1', title: '对象销毁', claim: '退出后仍写入', location: { path: 'page.dart', line: 13 } },
  ] }
  const text = presentReview(data)
  assert.ok(text.indexOf('CR-002') < text.indexOf('CR-001'))
  assert.equal(text.split('\n').filter(l => l.startsWith('- ')).length, 2)
  assert.doesNotMatch(text, /\n##/)
  const final = { status: 'partial', resultSource: 'final', results: data.findings.map(f => ({ id: f.id, finding: f, status: 'Uncertain', evidence: '缺少运行条件' })) }
  assert.match(presentReview(data, final), /复核或裁决未完成/)
  assert.doesNotMatch(presentReview(data, final), /✅/)
  assert.doesNotMatch(presentReview(data, { ...final, status: 'completed' }), /✅/)
  assert.doesNotMatch(presentReview({ ...data, findings: [] }, { ...final, results: [] }), /✅/)
  assert.equal((presentReview(data, final).match(/缺少运行条件/g) || []).length, 2)
})

const SCRIPT = fileURLToPath(new URL('./review.mjs', import.meta.url))
const input = {
  scope: { kind: 'worktree' },
  findings: [{ id: 'CR-001', priority: 'P1', title: '恢复递增', location: { path: 'counter.mjs', line: 2 },
    claim: 'increment(0) 返回 -1，应为 1；新改动把加法换成减法。' }],
  checks: ['源码核对，未运行账户/外部服务测试'], gaps: ['未验证 Windows 实机'],
}

test('L2 三臂只注入各自规则目录，baseline 不取得规则位置', () => {
  const review = canonical(fileURLToPath(new URL('../', import.meta.url)))
  assert.deepEqual(evaluationRuleDirectories('baseline'), [])
  assert.deepEqual(evaluationRuleDirectories('with_skill'), [review])
  assert.deepEqual(evaluationRuleDirectories('reference', '/tmp/original/SKILL.md'), ['/tmp/original'])
  assert.throws(() => evaluationRuleDirectories('reference'), /reference-skill/)
})

test('普通复核和 L2 默认沿用 CLI 模型配置，不传模型覆盖参数', () => {
  assert.equal(config().model, undefined)
  assert.ok(!claudeArgs(config()).includes('--model'))
  assert.ok(claudeArgs(config()).includes('--safe-mode'))
  const preview = JSON.parse(execFileSync(process.execPath, [
    fileURLToPath(new URL('./eval-profiles.mjs', import.meta.url)), '--case', 'review-and-verify-zero',
  ], { encoding: 'utf8' }))
  assert.equal(preview.dryRun, true)
  assert.equal(preview.model, null)
})

test('L2 baseline 是普通任务，各臂任务与环境相同且只附加自己的规则', () => {
  const prompts = JSON.parse(readFileSync(new URL('../test-prompts.json', import.meta.url), 'utf8'))
  for (const test of prompts) {
    const baseline = evaluationPrompt(test, '/fixture', 'baseline')
    const loaded = evaluationPrompt(test, '/fixture', 'with_skill')
    const reference = evaluationPrompt(test, '/fixture', 'reference', '/reference/SKILL.md')
    assert.ok(baseline.startsWith(test.prompt.replaceAll('{{FIXTURE_ROOT}}', '/fixture')))
    assert.ok(loaded.startsWith(baseline))
    assert.ok(reference.startsWith(baseline))
    assert.doesNotMatch(baseline, /gh-review|附加规则|交付约束|2–4|无需点评|聊天初审保留/)
    assert.ok(loaded.includes(fileURLToPath(new URL('../SKILL.md', import.meta.url))))
    assert.doesNotMatch(loaded, /\/reference\//)
    assert.match(reference, /\/reference\/SKILL.md/)
    assert.doesNotMatch(reference, /gh-review/)
  }
})

test('L2 预览不写盘，支持代表 case、多 case、三臂、重复及固定预算参数', (t) => {
  const f = fixture(t)
  const reference = join(f.temp, 'original.md')
  writeFileSync(reference, 'original review rules\n')
  const out = join(f.temp, 'evaluation-output')
  const defaults = evaluationOptions([])
  assert.deepEqual(defaults.cases, ['flutter-auto-profile', 'review-custom-omission', 'flutter-protected-dart', 'review-performance-boundary'])
  const options = evaluationOptions(['--case', 'review-default,review-custom-omission', '--case', 'review-default',
    '--reference-skill', reference, '--repeat', '2', '--model', 'fixture-model', '--effort', 'xhigh',
    '--timeout-ms', '10000', '--max-budget-usd', '1.5', '--output-dir', out])
  assert.deepEqual(options.cases, ['review-default', 'review-custom-omission'])
  assert.deepEqual(options.arms, ['baseline', 'reference', 'with_skill'])
  assert.equal(options.repeat, 2)
  assert.equal(options.settings.model, 'fixture-model')
  assert.equal(options.settings.timeoutMs, 10000)
  assert.equal(options.maxBudgetUsd, 1.5)
  const preview = JSON.parse(execFileSync(process.execPath, [fileURLToPath(new URL('./eval-profiles.mjs', import.meta.url)),
    '--reference-skill', reference, '--repeat', '2', '--output-dir', out], { encoding: 'utf8' }))
  assert.equal(preview.dryRun, true)
  assert.equal(preview.calls, 24)
  assert.deepEqual(preview.arms, ['baseline', 'reference', 'with_skill'])
  assert.equal(existsSync(out), false)
  for (const args of [['--repeat', '0'], ['--case'], ['--unknown'], ['--max-budget-usd', 'NaN'], ['--model', 'x', '--model', 'y']]) {
    assert.throws(() => evaluationOptions(args))
  }
})

test('L2 实际编排三臂两次，参数相同且保留模型、oracle、源码哈希产物', async (t) => {
  const f = fixture(t)
  const reference = join(f.temp, 'original.md')
  writeFileSync(reference, 'original review rules\n')
  const output = join(f.temp, 'evaluation-output')
  const calls = []
  await evaluateProfiles(['--case', 'review-custom-omission', '--reference-skill', reference, '--repeat', '2',
    '--model', 'fixture-model', '--effort', 'high', '--timeout-ms', '10000', '--max-budget-usd', '1.5',
    '--apply', '--output-dir', output], { resolveCli: () => '/mock/claude',
    run: async (cli, args, options) => {
      calls.push({ args, ...options })
      t.after(() => rmSync(options.cwd, { recursive: true, force: true }))
      return { code: 0, stderr: '', stdout: JSON.stringify({ result: 'one supported finding', modelUsage: { 'fixture-model': {} } }) }
    } })
  assert.equal(calls.length, 6)
  assert.equal(new Set(calls.map(call => call.cwd)).size, 6)
  const manifest = json(join(output, 'manifest.json'))
  assert.equal(manifest.calls, 6)
  assert.equal(manifest.sources.reference.path, reference)
  for (const [index, call] of calls.entries()) {
    assert.equal(call.timeoutMs, 10000)
    for (const [flag, value] of [['--model', 'fixture-model'], ['--effort', 'high'], ['--max-budget-usd', '1.5']]) {
      assert.equal(call.args[call.args.indexOf(flag) + 1], value)
    }
    assert.ok(call.args.includes('--safe-mode'))
    const arm = manifest.arms[index % 3], repetition = Math.floor(index / 3) + 1
    const artifact = join(output, `review-custom-omission-${arm}-${repetition}`)
    const state = json(join(artifact, 'state.json'))
    assert.deepEqual(state.reportedModels, ['fixture-model'])
    assert.equal(state.sourceUnchanged, true)
    assert.deepEqual(state.before, state.after)
    assert.equal(state.parameters.model, 'fixture-model')
    assert.deepEqual(json(join(artifact, 'oracle.json')).expectedPreview, ['B', 'C', 'A'])
    const input = readFileSync(join(call.cwd, 'review-input.md'), 'utf8')
    assert.doesNotMatch(input, /兜底|展示脚本|聊天模板|gh-review/)
    if (arm === 'baseline') {
      assert.doesNotMatch(call.input, /gh-review|附加规则/)
      assert.ok(!call.args.includes(dirname(reference)))
      assert.ok(!call.args.includes(manifest.sources.with_skill.path))
    }
  }
})

test('L2 定制夹具确实保留乱序任务，并遗漏要求的预览结果', async (t) => {
  const temp = mkdtempSync(join(tmpdir(), 'review-custom-fixtures-'))
  t.after(() => rmSync(temp, { recursive: true, force: true }))
  const allowedRoot = join(temp, 'allowed'), omissionRoot = join(temp, 'omission')
  const allowedBefore = evaluationFixture(allowedRoot, 'review-custom-allowed')
  const allowed = await evaluationOracle(allowedRoot, 'review-custom-allowed')
  assert.deepEqual(allowed.records.map(row => row.name), allowed.expectedNames)
  assert.deepEqual(allowed.records.map(row => row.result), ['B-file', 'A-file'])
  assert.match(readFileSync(join(allowedRoot, 'docs/spec.md'), 'utf8'), /所有提交的结果均须保留/)
  assert.deepEqual(evaluationFixtureHashes(allowedRoot), allowedBefore)
  const omissionBefore = evaluationFixture(omissionRoot, 'review-custom-omission')
  const omission = await evaluationOracle(omissionRoot, 'review-custom-omission')
  assert.deepEqual(omission.live, ['C', 'A'])
  assert.deepEqual(omission.preview, ['C', 'A'])
  assert.deepEqual(omission.expectedPreview, ['B', 'C', 'A'])
  assert.notDeepEqual(omission.preview, omission.expectedPreview)
  assert.match(readFileSync(join(omissionRoot, 'docs/spec.md'), 'utf8'), /preview 必须显示全部条目/)
  assert.match(readFileSync(join(omissionRoot, 'review-input.md'), 'utf8'), /\?\? preview.mjs/)
  assert.deepEqual(evaluationFixtureHashes(omissionRoot), omissionBefore)
})

test('L2 Flutter 与正常反例的 oracle 明示源码依据及未执行运行时，且不改夹具', async (t) => {
  const temp = mkdtempSync(join(tmpdir(), 'review-known-oracles-'))
  t.after(() => rmSync(temp, { recursive: true, force: true }))
  for (const id of ['flutter-auto-profile', 'flutter-protected-dart', 'review-performance-boundary']) {
    const root = join(temp, id), before = evaluationFixture(root, id)
    const oracle = await evaluationOracle(root, id)
    assert.equal(oracle.kind, 'source-established')
    assert.equal(oracle.runtimeExecuted, false)
    assert.equal(oracle.knownFindings.length, id === 'flutter-auto-profile' ? 2 : 0)
    for (const finding of oracle.knownFindings) {
      assert.match(readFileSync(join(root, finding.path), 'utf8').split('\n')[finding.line - 1], /setState/)
    }
    assert.deepEqual(evaluationFixtureHashes(root), before)
  }
})

test('L2 初审与复核分支夹具保持真实回归，零问题夹具仅删除注释', async (t) => {
  const temp = mkdtempSync(join(tmpdir(), 'review-default-fixtures-'))
  t.after(() => rmSync(temp, { recursive: true, force: true }))
  for (const id of ['review-default', 'review-default-existing-findings', 'review-default-zero',
    'review-only-findings', 'review-and-verify-findings', 'review-prior-authorization', 'review-and-verify-zero']) {
    const root = join(temp, id)
    const before = evaluationFixture(root, id)
    const oracle = await evaluationOracle(root, id)
    const zero = ['review-default-zero', 'review-and-verify-zero'].includes(id)
    assert.equal(oracle.zero, zero ? 1 : -1)
    assert.equal(oracle.caller, oracle.zero)
    assert.deepEqual(evaluationFixtureHashes(root), before)
    const diff = execFileSync('git', ['diff', 'HEAD'], { cwd: root, encoding: 'utf8' })
    assert.match(diff, /-  return n \+ 1 \/\/ baseline/)
    assert.match(diff, zero ? /\+  return n \+ 1/ : /\+  return n - 1/)
  }
})

test('L2 已删除的入口与建议 case 在创建产物或调用模型前拒绝', async (t) => {
  const temp = mkdtempSync(join(tmpdir(), 'review-eval-removed-'))
  t.after(() => rmSync(temp, { recursive: true, force: true }))
  const output = join(temp, 'output')
  for (const id of ['compat-entry-installed', 'compat-entry-missing', 'compat-entry-pure-dart', 'advice-repeated-sort']) {
    await assert.rejects(evaluateProfiles(['--case', id, '--apply', '--output-dir', output]), /未知评测 case/)
    assert.equal(existsSync(output), false)
  }
})

test('L2 来源夹具具有真实版本差异，五类复核产物可进入真实裁决和展示', async (t) => {
  const temp = mkdtempSync(join(tmpdir(), 'review-origin-eval-'))
  t.after(() => rmSync(temp, { recursive: true, force: true }))
  for (const id of ['review-feature-existing', 'review-feature-incremental', 'verify-origin-new',
    'verify-origin-existing', 'verify-origin-contract', 'verify-origin-unknown', 'verify-origin-correction']) {
    assert.deepEqual(evaluationOptions(['--case', id]).cases, [id])
    const repo = join(temp, id), output = join(temp, id + '-output')
    mkdirSync(output)
    const before = evaluationFixture(repo, id)
    const oracle = await evaluationOracle(repo, id)
    assert.equal(oracle.actual, -1)
    assert.equal(oracle.expected, id === 'verify-origin-contract' ? -1 : 1)
    if (['review-feature-existing', 'verify-origin-existing', 'verify-origin-contract', 'verify-origin-unknown'].includes(id)) {
      assert.equal(execFileSync('git', ['status', '--porcelain'], { cwd: repo, encoding: 'utf8' }), '')
      assert.equal(oracle.workingDiff, '')
    }
    if (id === 'verify-origin-unknown') assert.equal(oracle.history.split('\n').length, 1)
    if (id === 'review-feature-incremental') {
      assert.equal(oracle.expectedInitialFindings, 0)
      assert.match(oracle.workingDiff, /retained behavior/)
    }
    if (id.startsWith('verify-origin-')) {
      const answer = { results: [{ id: 'CR-001', status: oracle.expectedStatus,
        evidence: 'counter.mjs:2 返回 -1；caller.mjs 读取该值，依据 docs/spec.md 判断。',
        origin: { kind: oracle.expectedOrigin, basis: '版本材料与当前源码对照。' },
        ...(id === 'verify-origin-correction' ? { finding: {
          title: '现有递增返回错误结果', claim: 'increment(0) 返回 -1，应为 1。',
        } } : {}),
      }] }
      const final = validateAdjudicationArtifact(repo, output, JSON.stringify(answer), id)
      assert.equal(final.status, 'completed')
      assert.equal(final.results[0].status, oracle.expectedStatus)
      assert.equal(final.results[0].origin.kind, oracle.expectedOrigin)
      assert.ok(existsSync(join(output, 'presented.md')))
      if (id === 'verify-origin-correction') {
        assert.doesNotMatch(readFileSync(join(output, 'presented.md'), 'utf8'), /本次修改/)
        const payload = json(join(final.run, 'internal', 'findings.json'))
        assert.equal(payload.findings[0].origin.kind, 'introduced')
      }
    }
    assert.deepEqual(evaluationFixtureHashes(repo), before)
  }
})

function evaluationFixtureHashes(repo) {
  const files = execFileSync('git', ['ls-files', '-co', '--exclude-standard', '-z'], { cwd: repo, encoding: 'utf8' })
    .split('\0').filter(Boolean)
  return Object.fromEntries(files.map(file => [file,
    createHash('sha256').update(readFileSync(join(repo, file))).digest('hex')]))
}

function fixture(t) {
  const temp = canonical(mkdtempSync(join(tmpdir(), 'gh-review-')))
  const repo = join(temp, '中文 repo with spaces'), root = join(temp, 'cache 中文')
  mkdirSync(repo)
  const git = (...args) => execFileSync('git', args, { cwd: repo, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
  git('init', '-q')
  git('config', 'user.name', 'Review Test')
  git('config', 'user.email', 'review@example.invalid')
  writeFileSync(join(repo, 'counter.mjs'), 'export function increment(n) {\n  return n + 1\n}\n')
  git('add', '.')
  git('commit', '-qm', 'baseline')
  writeFileSync(join(repo, 'counter.mjs'), 'export function increment(n) {\n  return n - 1\n}\n')
  t.after(() => rmSync(temp, { recursive: true, force: true }))
  return { temp, repo, root, git, prepare: (value = input) => prepare(value, { repo, outputDir: root, apply: true }) }
}

function observation(status = 'Confirmed', id = 'CR-001') {
  return { id, status, evidence: status === 'Refuted' ? 'counter.mjs:2 调用方已限制该场景。' : 'counter.mjs:2，increment(0) 的结果为 -1，与基线不符。' }
}
const envelope = (results) => JSON.stringify({ type: 'result', is_error: false,
  structured_output: { results }, modelUsage: { 'resolved-model': {} } })
const mock = (results, before) => async (_command, args, context) => {
  assert.equal(context.env.CLAUDE_CODE_EFFORT_LEVEL, 'high')
  assert.ok(args.includes('--safe-mode'))
  assert.ok(args.includes('--json-schema'))
  assert.ok(context.input.includes('CR-001'))
  before?.(context)
  return { stdout: envelope(results), stderr: '', code: 0 }
}

test('三平台默认路径、Linux XDG fallback、Windows 时间目录', () => {
  assert.equal(defaultRoot('win32', { LOCALAPPDATA: 'C:\\Users\\中文 User\\AppData\\Local' }, 'C:\\Users\\中文 User'),
    'C:\\Users\\中文 User\\AppData\\Local\\gh-tools\\reviews')
  assert.equal(defaultRoot('win32', {}, 'D:\\Home'), 'D:\\Home\\AppData\\Local\\gh-tools\\reviews')
  assert.equal(defaultRoot('darwin', {}, '/Users/u'), '/Users/u/Library/Caches/gh-tools/reviews')
  assert.equal(defaultRoot('linux', { XDG_CACHE_HOME: '/mnt/cache' }, '/home/u'), '/mnt/cache/gh-tools/reviews')
  assert.equal(defaultRoot('linux', { XDG_CACHE_HOME: 'relative' }, '/home/u'), '/home/u/.cache/gh-tools/reviews')
  assert.match(makeRun('/cache', '/repo', new Date('2026-10-09T07:30:42Z')), /20261009T073042Z-[a-f0-9]{6}$/)
})

test('prepare 预览不写盘；实际交接精简、初审唯一源、仓库无新增', (t) => {
  const f = fixture(t)
  const before = f.git('status', '--porcelain')
  const preview = prepare(input, { repo: f.repo, outputDir: f.root })
  assert.equal(preview.dryRun, true)
  assert.equal(existsSync(f.root), false)
  const first = f.prepare(), second = f.prepare()
  assert.notEqual(first.run, second.run)
  const text = readFileSync(first.handoff, 'utf8')
  assert.ok(text.length < 1600)
  assert.match(text, /CR-001/)
  assert.doesNotMatch(text, /export function|# 共同审查规则/)
  assert.doesNotMatch(text, /未验证 Windows 实机|未运行账户/)
  assert.match(text, /internal\/materials.json/)
  assert.equal(json(join(first.run, 'internal', 'findings.json')).findings[0].claim, input.findings[0].claim)
  assert.equal(f.git('status', '--porcelain'), before)
  assert.equal(status(relative(process.cwd(), first.run)).handoff, first.handoff)
})

test('长篇检查记录留内部，handoff 不随检查日志膨胀或丢掉问题', (t) => {
  const f = fixture(t)
  const prepared = f.prepare({ ...input, checks: ['检查日志：'.repeat(10000)], gaps: ['诊断详情：'.repeat(10000)] })
  const text = readFileSync(prepared.handoff, 'utf8')
  assert.ok(Buffer.byteLength(text) < 2000)
  assert.match(text, /CR-001/)
  assert.equal(json(join(prepared.run, 'internal', 'findings.json')).checks[0].length, 50000)
})

test('scope 覆盖 staged / unstaged / untracked，改变任一种使旧结果过期', async (t) => {
  const f = fixture(t)
  f.git('add', 'counter.mjs')
  writeFileSync(join(f.repo, 'counter.mjs'), 'export function increment(n) {\n  return n - 2\n}\n')
  writeFileSync(join(f.repo, 'new.mjs'), 'export const added = true\n')
  const run = f.prepare().run
  const snap = json(join(run, 'internal', 'snapshot.json'))
  assert.deepEqual(snap.files, ['counter.mjs', 'new.mjs'])
  assert.equal(snap.newFiles[0].path, 'new.mjs')
  writeFileSync(join(f.repo, 'new.mjs'), 'export const added = false\n')
  const result = await verify(run, { apply: true })
  assert.equal(result.status, 'stale')
  assert.equal(existsSync(join(run, 'review-handoff.md')), true)
})

test('snapshot 可复核无 diff 的现有缺陷，范围外调用方可定位且变化使结果过期', async (t) => {
  const f = fixture(t)
  f.git('add', '.'); f.git('commit', '-qm', 'existing defect')
  writeFileSync(join(f.repo, 'caller.mjs'), 'import { increment } from "./counter.mjs"\nexport const value = increment(0)\n')
  f.git('add', '.'); f.git('commit', '-qm', 'caller')
  const { value } = await import(pathToFileURL(join(f.repo, 'caller.mjs')))
  assert.equal(value, -1)
  const data = { scope: { kind: 'snapshot', paths: ['caller.mjs'] }, findings: [{
    ...input.findings[0], claim: '现有 increment(0) 返回 -1，应为 1。',
  }] }
  const prepared = f.prepare(data)
  assert.equal(readFileSync(join(prepared.run, 'internal', 'review.diff'), 'utf8'), '')
  assert.equal(json(join(prepared.run, 'internal', 'snapshot.json')).scope.base, undefined)
  assert.deepEqual(json(join(prepared.run, 'internal', 'snapshot.json')).files, ['caller.mjs'])
  const origin = { kind: 'unknown', basis: '本次未确定比较基线，不影响现有错误判断。' }
  await verify(prepared.run, { apply: true, cli: process.execPath,
    runner: mock([{ ...observation(), origin }], ({ input: prompt }) => {
      assert.match(prompt, /代码来源：snapshot/)
      assert.doesNotMatch(prompt, /归因比较基线|提交比较范围|增量初审要求问题/)
      assert.match(prompt, /不在 diff.*均不是 Refuted 的依据/)
    }) })
  complete(prepared.run, { results: [observation()] }, { apply: true })
  assert.equal(status(prepared.run).results[0].status, 'Confirmed')
  assert.deepEqual(status(prepared.run).results[0].origin, origin)
  const fixed = f.prepare({ ...data, scope: { ...data.scope, target: 'HEAD' } })
  assert.equal(status(fixed.run).status, 'ready')
  writeFileSync(join(f.repo, 'counter.mjs'), 'export const increment = n => n - 2\n')
  assert.equal(status(prepared.run).status, 'stale')
  assert.throws(() => f.prepare({ ...data, scope: { kind: 'snapshot', target: 'HEAD' } }), /干净 checkout/)
  assert.throws(() => f.prepare({ ...data, scope: { kind: 'snapshot', base: 'HEAD' } }), /不使用比较基线/)
  assert.throws(() => f.prepare({ ...data, scope: { kind: 'snapshot', target: 'HEAD~1' } }), /HEAD 与 target 不同/)
  // 非固定提交快照允许工作区变化，但仍要求问题位置实际存在。
  const dirty = f.prepare(data)
  assert.equal(status(dirty.run).status, 'ready')
  const working = f.prepare({ ...input, scope: { kind: 'worktree', target: 'HEAD' } })
  await verify(working.run, { apply: true, cli: process.execPath,
    runner: mock([observation()], ({ input: prompt }) => {
      assert.doesNotMatch(prompt, /已验证 checkout 干净/)
    }) })
  rmSync(join(f.repo, 'counter.mjs'))
  assert.throws(() => f.prepare(data), /不是可定位/)
})

test('来源校验向后兼容；无效来源在写入前拒绝，不把缺失来源等同缺陷待确认', (t) => {
  const f = fixture(t)
  assert.equal(validateOrigin(undefined), undefined)
  for (const origin of [null, [], { kind: 'old', basis: 'x' }, { kind: 'unknown', basis: ' ' },
    { kind: 'unknown', basis: 'x'.repeat(1201) }, { kind: 'introduced', basis: 'x', commit: 'oops' },
    { kind: 'pre-existing', basis: 'x', date: '2026-02-30' }, { kind: 'unknown', basis: 'x', extra: true }]) {
    assert.throws(() => f.prepare({ ...input, findings: [{ ...input.findings[0], origin }] }), /origin/)
    assert.equal(existsSync(f.root), false)
    const result = validateResults({ results: [{ ...observation(), origin }] }, ['CR-001'])
    assert.equal(result.complete, false)
    assert.ok(result.errors.some(error => error.includes('origin')))
  }
  const legacy = validateResults({ results: [observation()] }, ['CR-001'])
  assert.equal(legacy.complete, true)
  assert.equal(legacy.results[0].status, 'Confirmed')
  assert.equal(Object.hasOwn(legacy.results[0], 'origin'), false)
  assert.match(presentReview({ ...input, scopeLabel: '递增功能' }), /来源：引入未确定/)
})

test('归因修正不排除真实缺陷，来源贯穿复核、裁决、报告和展示且保留原记录', async (t) => {
  const f = fixture(t)
  f.git('add', '.'); f.git('commit', '-qm', 'pre-existing bug')
  const commit = f.git('rev-parse', 'HEAD').trim()
  writeFileSync(join(f.repo, 'counter.mjs'), 'export function increment(n) {\n  return n - 1 // comment only\n}\n')
  const initial = { kind: 'introduced', basis: '初审认为本次改动导致递增错误。' }
  const corrected = { kind: 'pre-existing', basis: '至少在比较基线中已返回 n - 1；本次只改注释。准确引入时间未确定。',
    commit, date: f.git('show', '-s', '--format=%cs', commit).trim() }
  const data = { ...input, scopeLabel: '递增功能', findings: [{ ...input.findings[0], origin: initial }] }
  const prepared = f.prepare(data)
  assert.match(readFileSync(prepared.handoff, 'utf8'), /来源：本次引入/)
  await verify(prepared.run, { apply: true, cli: process.execPath,
    runner: mock([{ ...observation(), origin: corrected }]) })
  const verdict = { ...observation(), finding: { title: '现有递增返回错误结果', claim: 'increment(0) 返回 -1，调用方要求 1。' } }
  complete(prepared.run, { results: [verdict] }, { apply: true })
  const final = status(prepared.run)
  assert.equal(final.results[0].status, 'Confirmed')
  assert.deepEqual(final.results[0].origin, corrected)
  assert.deepEqual(final.observations[0].origin, corrected)
  assert.deepEqual(json(join(prepared.run, 'internal', 'findings.json')).findings[0].origin, initial)
  assert.match(readFileSync(join(prepared.run, 'review-report.md'), 'utf8'), /来源：历史已存在/)
  assert.match(presentReview(data, final), /来源：历史已存在/)
  assert.doesNotMatch(presentReview(data, final), /新改动把加法换成减法/)
  const uncertainOrigin = { kind: 'unknown', basis: '补充核查后尚不能确定来源。' }
  complete(prepared.run, { results: [{ ...verdict, origin: uncertainOrigin }] }, { apply: true })
  assert.deepEqual(status(prepared.run).results[0].origin, uncertainOrigin)
  assert.deepEqual(status(prepared.run).observations[0].origin, corrected)
})

test('分支比较用共同祖先；显式 range 不转共同祖先', (t) => {
  const f = fixture(t)
  const base = f.git('rev-parse', 'HEAD').trim()
  f.git('add', '.')
  f.git('commit', '-qm', 'change')
  const branch = f.prepare({ ...input, scope: { kind: 'branch', base } })
  assert.equal(json(join(branch.run, 'internal', 'state.json')).scope.base, base)
  const range = f.prepare({ ...input, scope: { kind: 'range', base, target: 'HEAD' } })
  assert.equal(json(join(range.run, 'internal', 'state.json')).scope.base, base)
  writeFileSync(join(f.repo, 'outside.txt'), 'change outside scope')
  assert.throws(() => f.prepare({ ...input, scope: { kind: 'branch', base } }), /干净 checkout/)
})

test('非法范围、重复 ID、仓库内缓存、不存在的位置提前拒绝', (t) => {
  const f = fixture(t)
  assert.throws(() => f.prepare({ ...input, findings: [...input.findings, input.findings[0]] }), /编号/)
  assert.throws(() => f.prepare({ ...input, scope: { kind: 'worktree', paths: ['../bad'] } }), /相对路径/)
  assert.throws(() => prepare(input, { repo: f.repo, outputDir: join(f.repo, 'out'), apply: true }), /仓库外/)
  assert.throws(() => f.prepare({ ...input, findings: [{ ...input.findings[0], location: { path: 'absent.mjs', line: 1 } }] }), /仓库文件/)
})

test('本次改动触发的旧功能回归可定位在未修改文件，保留其规则并完成复核', async (t) => {
  const f = fixture(t)
  mkdirSync(join(f.repo, 'legacy'))
  const legacy = 'import { increment } from "../counter.mjs"\nexport const nextPage = (page) => increment(page)\n'
  writeFileSync(join(f.repo, 'legacy', 'pager.mjs'), legacy)
  writeFileSync(join(f.repo, 'legacy', 'AGENTS.md'), '翻页必须前进到下一页。')
  f.git('add', 'legacy')
  f.git('commit', '-qm', 'existing pager')
  const before = f.git('status', '--porcelain')
  const finding = { ...input.findings[0], location: { path: 'legacy/pager.mjs', line: 2 },
    claim: 'counter.mjs:2 本次由 n + 1 改成 n - 1；未修改的 nextPage(1) 从 2 变为 0，旧翻页功能回退。' }
  const prepared = f.prepare({ ...input, scope: { kind: 'worktree', paths: ['counter.mjs'] }, findings: [finding] })
  assert.deepEqual(json(join(prepared.run, 'internal', 'snapshot.json')).files, ['counter.mjs'])
  assert.equal(json(join(prepared.run, 'internal', 'findings.json')).findings[0].location.path, 'legacy/pager.mjs')
  assert.ok(json(join(prepared.run, 'internal', 'project-rules.json')).some((r) => r.text.includes('翻页必须')))
  const result = { id: 'CR-001', status: 'Confirmed', evidence: finding.claim }
  assert.equal((await verify(prepared.run, { apply: true, cli: process.execPath, runner: mock([result]) })).status, 'verified')
  const done = complete(prepared.run, { results: [result] }, { apply: true })
  assert.equal(done.status, 'completed')
  assert.match(readFileSync(done.report, 'utf8'), /legacy\/pager.mjs:2/)
  assert.equal(readFileSync(join(f.repo, 'legacy', 'pager.mjs'), 'utf8'), legacy)
  assert.equal(f.git('status', '--porcelain'), before)
  writeFileSync(join(f.repo, 'legacy', 'AGENTS.md'), '翻页规则已变化。')
  assert.equal(status(prepared.run).status, 'stale')
})

test('提交模式允许未修改文件中的回归位置，同时保留删除文件定位', (t) => {
  const f = fixture(t)
  writeFileSync(join(f.repo, 'existing.mjs'), 'export const contract = "increment"\n')
  f.git('add', 'existing.mjs')
  f.git('commit', '-qm', 'existing feature')
  const base = f.git('rev-parse', 'HEAD').trim()
  f.git('add', 'counter.mjs')
  f.git('commit', '-qm', 'change counter')
  for (const kind of ['branch', 'range']) {
    const prepared = f.prepare({ ...input, scope: { kind, base },
      findings: [{ ...input.findings[0], location: { path: 'existing.mjs', line: 1 } }] })
    assert.equal(prepared.status, 'ready')
  }
  f.git('rm', '-q', 'existing.mjs')
  const deleted = f.prepare({ ...input, findings: [{ ...input.findings[0], location: { path: 'existing.mjs', line: 1 } }] })
  assert.equal(deleted.status, 'ready')
})

test('目录范围 ./ 和尾部斜杠正确包含未跟踪文件', (t) => {
  const f = fixture(t)
  mkdirSync(join(f.repo, 'src'))
  writeFileSync(join(f.repo, 'src', 'new.mjs'), 'export const added = 1')
  const findings = [{ ...input.findings[0], location: { path: 'src/new.mjs', line: 1 } }]
  const scoped = f.prepare({ ...input, scope: { kind: 'worktree', paths: ['./src/'] }, findings })
  assert.deepEqual(json(join(scoped.run, 'internal', 'snapshot.json')).files, ['src/new.mjs'])
  const whole = f.prepare({ ...input, scope: { kind: 'worktree', paths: ['.'] } })
  assert.ok(json(join(whole.run, 'internal', 'snapshot.json')).files.includes('src/new.mjs'))
})

test('自动成功、参数限制、裁决报告且初审不被覆盖', async (t) => {
  const f = fixture(t)
  const prepared = f.prepare(), original = readFileSync(prepared.handoff, 'utf8')
  const result = await verify(prepared.run, { apply: true, cli: process.execPath, runner: mock([observation()]) })
  assert.equal(result.status, 'verified')
  const done = complete(prepared.run, { results: [observation()] }, { apply: true })
  assert.equal(done.status, 'completed')
  assert.deepEqual(done.counts, { Confirmed: 1, Refuted: 0, Uncertain: 0 })
  assert.equal(readFileSync(prepared.handoff, 'utf8'), original)
  const attempt = readdirSync(join(prepared.run, 'internal', 'attempts'))[0]
  const record = json(join(prepared.run, 'internal', 'attempts', attempt, 'attempt.json'))
  assert.deepEqual(record.reportedModels, ['resolved-model'])
  assert.equal(record.actualEffort, null)
  assert.match(readFileSync(done.report, 'utf8'), /CR-001/)
})

test('CLI 缺失保留材料与明确失败；未复核不能确认/排除', async (t) => {
  const f = fixture(t), prepared = f.prepare()
  const result = await verify(prepared.run, { apply: true, cli: join(f.temp, 'missing-claude') })
  assert.equal(result.status, 'failed')
  assert.equal(result.handoff, prepared.handoff)
  assert.equal(existsSync(result.handoff), true)
  assert.equal(existsSync(join(prepared.run, '.lock')), false)
  assert.throws(() => complete(prepared.run, { results: [observation()] }, { apply: true }), /尚无复核记录/)
  const done = complete(prepared.run, { results: [] }, { apply: true })
  assert.equal(done.status, 'failed')
  assert.equal(done.counts.Uncertain, 1)
  assert.match(readFileSync(done.report, 'utf8'), /复核或裁决未完成/)
})

test('零 Findings 保存交接、不解析或调用不存在的 CLI', async (t) => {
  const f = fixture(t), prepared = f.prepare({ ...input, findings: [] })
  const result = await verify(prepared.run, { apply: true, cli: join(f.temp, 'missing') })
  assert.equal(result.status, 'no-findings')
  assert.equal(readdirSync(join(prepared.run, 'internal', 'attempts')).length, 0)
  const done = complete(prepared.run, { results: [] }, { apply: true })
  assert.equal(done.status, 'completed')
  assert.match(done.summary, /未调用 Claude/)
})

test('无效 JSON / envelope 错误 / 退出失败保留交接且不能通过', async (t) => {
  const f = fixture(t)
  for (const output of [
    { stdout: 'truncated {', stderr: '', code: 0 },
    { stdout: JSON.stringify({ is_error: true, structured_output: { results: [observation()] } }), stderr: '', code: 0 },
    { stdout: envelope([observation()]), stderr: 'authentication failed', code: 1 },
  ]) {
    const prepared = f.prepare()
    const result = await verify(prepared.run, { apply: true, cli: process.execPath, runner: async () => output })
    assert.equal(result.status, 'failed')
    assert.equal(result.results.length, 0)
    assert.equal(existsSync(prepared.handoff), true)
  }
})

test('重复/未知/遗漏编号、无证据结论不能静默通过', () => {
  const ids = ['CR-001', 'CR-002']
  const parsed = validateResults({ results: [observation(), observation('Refuted'), observation('Confirmed', 'CR-999')] }, ids)
  assert.equal(parsed.complete, false)
  assert.equal(parsed.results.length, 0)
  assert.deepEqual(parsed.missing, ids)
  assert.equal(validateResults({ results: [{ ...observation(), evidence: '' }] }, ['CR-001']).complete, false)
  assert.equal(parseClaude(envelope([observation()]), ['CR-001']).complete, true)
})

test('部分结果按编号保存，手动导入后补齐，再裁决；重试不会覆盖历史', async (t) => {
  const f = fixture(t)
  const second = { ...input.findings[0], id: 'CR-002', title: '检查另一独立行为' }
  const prepared = f.prepare({ ...input, findings: [...input.findings, second] })
  const partial = await verify(prepared.run, { apply: true, cli: process.execPath, runner: mock([observation()]) })
  assert.equal(partial.status, 'partial')
  assert.deepEqual(partial.missing, ['CR-002'])
  const imported = importResults(prepared.run, { results: [observation('Uncertain', 'CR-002')] }, { apply: true, ids: ['CR-002'] })
  assert.equal(imported.status, 'verified')
  const final = complete(prepared.run, { results: [observation(), observation('Uncertain', 'CR-002')] }, { apply: true })
  assert.equal(final.status, 'completed')
  const retry = await verify(prepared.run, { apply: true, ids: ['CR-001'], cli: process.execPath, runner: mock([observation('Refuted')]) })
  assert.equal(retry.status, 'verified')
  assert.equal(readdirSync(join(prepared.run, 'internal', 'attempts')).length, 3)
})

test('复核过程中工作区变化，旧结果不成为 observations', async (t) => {
  const f = fixture(t), prepared = f.prepare()
  const result = await verify(prepared.run, { apply: true, cli: process.execPath,
    runner: mock([observation()], () => writeFileSync(join(f.repo, 'counter.mjs'), 'changed during review')) })
  assert.equal(result.status, 'stale')
  assert.deepEqual(json(join(prepared.run, 'internal', 'state.json')).observations, {})
  assert.equal(complete(prepared.run, { results: [] }, { apply: true }).status, 'stale')
})

test('超时和 AbortSignal 真正终止子进程；stdout+stderr 上限不当作成功', async (t) => {
  const f = fixture(t)
  const wait = ['-e', 'setInterval(() => {}, 1000)']
  const timeout = await runProcess(process.execPath, wait, { cwd: f.repo, input: '', timeoutMs: 100 })
  assert.equal(timeout.failure, 'timeout')
  const controller = new AbortController()
  setTimeout(() => controller.abort(), 100)
  const aborted = await runProcess(process.execPath, wait, { cwd: f.repo, input: '', timeoutMs: 3000, signal: controller.signal })
  assert.equal(aborted.failure, 'interrupted')
  const huge = await runProcess(process.execPath, ['-e', 'process.stdout.write("a".repeat(10000))'],
    { cwd: f.repo, input: '', timeoutMs: 3000, limit: 100 })
  assert.equal(huge.failure, 'output-limit')
  assert.equal(huge.stdout.length + huge.stderr.length, 100)
})

test('status 恢复失效运行，活跃锁拒绝二次调用且不删除原锁', async (t) => {
  const f = fixture(t), prepared = f.prepare()
  const loaded = loadRun(prepared.run)
  loaded.state.status = 'verifying'
  atomic(join(prepared.run, 'internal', 'state.json'), loaded.state)
  assert.equal(status(prepared.run).status, 'interrupted')
  const release = acquire(join(prepared.run, '.lock'))
  try {
    await assert.rejects(() => verify(prepared.run, { apply: true }), /另一个运行/)
    assert.equal(existsSync(join(prepared.run, '.lock')), true)
  } finally { release() }
})

test('规则显式传递：嵌套 AGENTS 与需求，交接不复制完整规则', async (t) => {
  const f = fixture(t)
  writeFileSync(join(f.repo, 'AGENTS.md'), '规则：保持账户隔离。')
  mkdirSync(join(f.repo, 'docs'))
  writeFileSync(join(f.repo, 'docs', 'spec.md'), '需求：必须递增。')
  const prepared = f.prepare({ ...input, ruleFiles: ['docs/spec.md'] })
  const rules = json(join(prepared.run, 'internal', 'project-rules.json'))
  assert.ok(rules.some((r) => r.text.includes('必须递增')))
  assert.ok(rules.some((r) => r.text.includes('账户隔离')))
  assert.doesNotMatch(readFileSync(prepared.handoff, 'utf8'), /保持账户隔离/)
})

test('交接的相对规则链接可独立读取，自动复核使用同一份保存的规则', async (t) => {
  const f = fixture(t)
  writeFileSync(join(f.repo, 'AGENTS.md'), '规则：保持账户隔离。')
  const prepared = f.prepare()
  const handoff = readFileSync(prepared.handoff, 'utf8')
  const links = [...handoff.matchAll(/\]\((internal\/[^)]+)\)/g)].map((m) => m[1])
  assert.ok(links.includes('internal/review-rules.md'))
  assert.ok(links.includes('internal/materials.json'))
  for (const path of links) assert.ok(existsSync(join(prepared.run, path)))
  const shared = readFileSync(join(prepared.run, 'internal', 'review-rules.md'), 'utf8')
  const entryText = readFileSync(new URL('../SKILL.md', import.meta.url), 'utf8')
  const core = entryText.split('\n## 缺陷标准\n')[1].split('\n## ')[0]
  assert.equal(shared, '# 共同缺陷标准\n' + core + '\n' +
    readFileSync(new URL('../references/review-rules.md', import.meta.url), 'utf8') + '\n' +
    readFileSync(new URL('../references/origin.md', import.meta.url), 'utf8'))
  assert.doesNotMatch(shared, /增量初审要求问题由指定变化引入|默认检查暂存|## 初审|## 结果/)
  assert.match(shared, /归因错误但错误行为真实存在时确认缺陷/)
  assert.doesNotMatch(shared, /\]\(references\/|\]\(profiles\//)
  assert.doesNotMatch(handoff, /# 复核补充标准|保持账户隔离/)
  // 在隔离副本中使安装来源失效，确认旧运行仍读取它自己的规则。
  const copy = join(f.temp, 'skill-copy')
  cpSync(fileURLToPath(new URL('..', import.meta.url)), copy, { recursive: true })
  const isolated = await import(pathToFileURL(join(copy, 'scripts', 'review.mjs')).href)
  // Windows checkout 使用 CRLF 仍应冻结相同核心，不携带安装目录的按需链接。
  const entry = join(copy, 'SKILL.md')
  writeFileSync(entry, readFileSync(entry, 'utf8').replace(/\n/g, '\r\n'))
  const crlf = isolated.prepare(input, { repo: f.repo, outputDir: join(f.temp, 'crlf-reviews'), apply: true })
  assert.equal(readFileSync(join(crlf.run, 'internal', 'review-rules.md'), 'utf8'), shared)
  rmSync(join(copy, 'references', 'review-rules.md'))
  rmSync(entry)
  const result = await isolated.verify(prepared.run, { apply: true, cli: process.execPath,
    runner: mock([observation()], ({ input: prompt }) => {
      assert.ok(prompt.includes(shared))
      assert.match(prompt, /无需点评做得好的地方/)
      assert.match(prompt, /保留全部输入编号及 Refuted 所需反证/)
      assert.ok(prompt.includes(join(prepared.run, 'internal', 'materials.json')))
      assert.ok(prompt.includes(join(f.repo, 'AGENTS.md')))
      assert.ok(json(join(prepared.run, 'internal', 'project-rules.json')).some((r) => r.text.includes('保持账户隔离')))
    }) })
  assert.equal(result.status, 'verified')
  assert.equal(readFileSync(join(prepared.run, 'internal', 'review-rules.md'), 'utf8'), shared)
  // 旧运行已有完整共享规则；入口精简后仍以其原快照核查，不补当前核心。
  const legacy = '旧运行的完整审查标准：只复核输入编号，必须有实际回归证据。\n'
  writeFileSync(join(crlf.run, 'internal', 'review-rules.md'), legacy)
  await isolated.verify(crlf.run, { apply: true, cli: process.execPath,
    runner: mock([observation()], ({ input: prompt }) => {
      assert.ok(prompt.includes(legacy))
      assert.ok(!prompt.includes(core))
    }) })
  assert.equal(readFileSync(join(crlf.run, 'internal', 'review-rules.md'), 'utf8'), legacy)
})

test('局部复核不内联其他编号、完整规则和日志，保留跨目录规则及原始证据入口', async (t) => {
  const f = fixture(t)
  mkdirSync(join(f.repo, 'legacy')); mkdirSync(join(f.repo, 'docs'))
  writeFileSync(join(f.repo, 'legacy', 'reader.mjs'), 'export const read = () => 1\n')
  writeFileSync(join(f.repo, 'legacy', 'AGENTS.md'), '旧调用方规则。')
  writeFileSync(join(f.repo, 'AGENTS.md'), '根目录规则。')
  writeFileSync(join(f.repo, 'docs', 'spec.md'), '显式需求。')
  const payload = { ...input, ruleFiles: ['docs/spec.md'], findings: [
    { ...input.findings[0], basis: '关键依据与本项已知缺口：无法验证设备行为。' },
    { ...input.findings[0], id: 'CR-002', title: '另一项问题', location: { path: 'legacy/reader.mjs', line: 1 } },
  ] }
  const capture = async (prepared) => {
    let prompt
    await verify(prepared.run, { apply: true, cli: process.execPath, ids: ['CR-001'],
      runner: mock([observation()], (context) => { prompt = context.input }) })
    return prompt
  }
  const small = await capture(f.prepare(payload))
  const longRule = '完整项目规则正文。'.repeat(10000)
  writeFileSync(join(f.repo, 'legacy', 'AGENTS.md'), longRule)
  const largePayload = { ...payload, checks: ['检查日志。'.repeat(10000)], gaps: ['环境诊断。'.repeat(10000)] }
  const prepared = f.prepare(largePayload), large = await capture(prepared)
  assert.ok(Math.abs(Buffer.byteLength(large) - Buffer.byteLength(small)) < 200)
  assert.match(large, /CR-001|关键依据与本项已知缺口/)
  assert.ok(large.includes(payload.findings[0].basis))
  assert.doesNotMatch(large, /CR-002|另一项问题|完整项目规则正文|检查日志。|环境诊断。/)
  for (const path of ['AGENTS.md', 'legacy/AGENTS.md', 'docs/spec.md']) assert.ok(large.includes(join(f.repo, path)))
  const savedRules = json(join(prepared.run, 'internal', 'project-rules.json'))
  const materials = json(join(prepared.run, 'internal', 'materials.json'))
  const index = JSON.parse(large.split('\n').find((line) => line.startsWith('[{"path":')))
  for (const entry of index) {
    const material = materials.rules[entry.entry]
    assert.equal(material.path, entry.path)
    const text = material.parts.map((part) => readFileSync(join(materials.baseDir, part), 'utf8')).join('')
    assert.equal(text, savedRules.find((r) => r.path === entry.path).text)
  }
  assert.ok(large.includes(join(prepared.run, 'internal', 'materials.json')))
  assert.ok(large.includes(join(prepared.run, 'internal', 'snapshot.json')))
  assert.equal(json(join(prepared.run, 'internal', 'findings.json')).checks[0], largePayload.checks[0])
  assert.ok(json(join(prepared.run, 'internal', 'project-rules.json')).some((r) => r.text === longRule))
  const result = status(prepared.run)
  assert.equal(result.status, 'partial')
  assert.deepEqual(result.results.map((r) => r.id), ['CR-001'])
})

test('旧运行缺少共享规则快照时保留交接，不能静默使用当前安装规则', async (t) => {
  const f = fixture(t), prepared = f.prepare()
  rmSync(join(prepared.run, 'internal', 'review-rules.md'))
  let called = false
  const result = await verify(prepared.run, { apply: true, cli: process.execPath,
    runner: async () => { called = true; return { stdout: envelope([observation()]), stderr: '', code: 0 } } })
  assert.equal(result.status, 'failed')
  assert.match(result.diagnostic, /共享审查规则缺失.*重新 prepare/)
  assert.equal(called, false)
  assert.equal(existsSync(prepared.handoff), true)
  assert.deepEqual(status(prepared.run).results, [])
})

function age(run, days, completed = false) {
  const path = join(run, 'internal', 'state.json'), state = json(path)
  state.lastActivity = new Date(Date.now() - days * 86400000).toISOString()
  state.status = completed ? 'completed' : 'failed'
  atomic(path, state)
}

test('清理默认预览；7/30 天、当前保护，未知目录不删除', (t) => {
  const f = fixture(t)
  const oldDone = f.prepare().run, pending = f.prepare().run, expired = f.prepare().run
  age(oldDone, 8, true); age(pending, 8); age(expired, 31)
  const unknown = join(f.root, 'unknown')
  mkdirSync(unknown); writeFileSync(join(unknown, 'keep'), 'keep')
  const preview = clean(f.root)
  assert.deepEqual(new Set(preview.removed), new Set([oldDone, expired]))
  assert.equal(existsSync(oldDone), true)
  clean(f.root, { apply: true, protect: [expired] })
  assert.equal(existsSync(oldDone), false)
  assert.equal(existsSync(expired), true)
  assert.equal(existsSync(pending), true)
  assert.equal(existsSync(unknown), true)
})

test('容量清理优先已完成，再未完成；活跃目录容量不足停止新增', (t) => {
  const f = fixture(t)
  const done = f.prepare().run, pending = f.prepare().run
  age(done, 1, true); age(pending, 2)
  writeFileSync(join(done, 'large'), Buffer.alloc(MiB))
  writeFileSync(join(pending, 'large'), Buffer.alloc(MiB))
  const result = clean(f.root, { maxBytes: MiB + 100000 })
  assert.deepEqual(result.removed, [done])
  const release = acquire(join(pending, '.lock'), MiB)
  try { assert.throws(() => clean(f.root, { maxBytes: 100 }), /占满容量/) }
  finally { release() }
})

test('清理不跟随 symlink/junction，含链接的受管目录不删除', (t) => {
  const f = fixture(t), run = f.prepare().run
  const outside = join(f.temp, 'outside')
  mkdirSync(outside); writeFileSync(join(outside, 'keep'), 'keep')
  symlinkSync(outside, join(run, 'linked'), process.platform === 'win32' ? 'junction' : 'dir')
  age(run, 40)
  const result = clean(f.root, { apply: true })
  assert.deepEqual(result.removed, [])
  assert.equal(readFileSync(join(outside, 'keep'), 'utf8'), 'keep')
  assert.throws(() => loadRun(run), /链接/)
})

test('配置覆盖且参数为独立 argv；Windows cmd 不自动回退执行', (t) => {
  const f = fixture(t), cfg = join(f.temp, 'config.json')
  writeFileSync(cfg, JSON.stringify({ model: 'pinned-model', effort: 'medium', timeoutMs: 4000 }))
  const settings = config({ config: cfg, effort: 'high' })
  assert.equal(settings.model, 'pinned-model')
  assert.equal(settings.effort, 'high')
  assert.equal(claudeArgs(settings)[2], '--model')
  assert.equal(claudeArgs(settings)[3], 'pinned-model')
  for (const model of ['opus', 'provider/custom-model']) {
    const override = config({ config: cfg, model })
    assert.equal(claudeArgs(override)[3], model)
  }
  for (const model of ['', ' ', null, '--unexpected']) assert.throws(() => config({ model }), /无效模型名称/)
  const cmd = join(f.temp, 'claude.cmd'); writeFileSync(cmd, '@echo off')
  assert.throws(() => resolveClaude(cmd, { platform: 'win32' }), /原生 .exe/)
})

test('CLI prepare 的 stdin、dry-run、失败退出码和交接入口', (t) => {
  const f = fixture(t)
  const execute = (args, body) => {
    try { return { code: 0, stdout: execFileSync(process.execPath, [SCRIPT, ...args], { input: body, encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] }) } }
    catch (error) { return { code: error.status, stdout: error.stdout, stderr: error.stderr } }
  }
  const preview = execute(['prepare', '--repo', f.repo, '--output-dir', f.root, '--input', '-'], JSON.stringify(input))
  assert.equal(jsonFrom(preview.stdout).dryRun, true)
  assert.equal(existsSync(f.root), false)
  const created = execute(['prepare', '--repo', f.repo, '--output-dir', f.root, '--input', '-', '--apply'], JSON.stringify(input))
  const run = jsonFrom(created.stdout).run
  const failed = execute(['verify', '--run', run, '--cli', join(f.temp, 'missing'), '--apply'])
  assert.equal(failed.code, 1)
  assert.equal(jsonFrom(failed.stdout).handoff, join(run, 'review-handoff.md'))
  assert.equal(execute(['verify']).code, 2)
  assert.equal(execute(['prepare']).code, 2)
})

test('已完成报告不会作为代码变化后或重试中的当前报告展示', async (t) => {
  const f = fixture(t), prepared = f.prepare()
  importResults(prepared.run, { results: [observation()] }, { apply: true })
  complete(prepared.run, { results: [observation()] }, { apply: true })
  assert.ok(status(prepared.run).report)
  await verify(prepared.run, { apply: true, cli: join(f.temp, 'missing') })
  assert.equal(status(prepared.run).report, undefined)
  writeFileSync(join(f.repo, 'counter.mjs'), 'new version')
  assert.equal(status(prepared.run).status, 'stale')
  assert.equal(existsSync(prepared.handoff), true)
})

test('仓库外祖先规则变化也使旧上下文过期', async (t) => {
  const f = fixture(t)
  writeFileSync(join(f.temp, 'AGENTS.md'), '规则 v1')
  const prepared = f.prepare()
  writeFileSync(join(f.temp, 'AGENTS.md'), '规则 v2')
  assert.equal((await verify(prepared.run, { apply: true })).status, 'stale')
})

test('容量不足的 verify 不遗留锁；未知目录计容量但不删除', async (t) => {
  const f = fixture(t), prepared = f.prepare()
  const unknown = join(f.root, 'keep-unknown')
  mkdirSync(unknown)
  // sparse 文件，不实际分配 500 MiB。
  const { truncateSync } = await import('node:fs')
  writeFileSync(join(unknown, 'large'), '')
  truncateSync(join(unknown, 'large'), 500 * MiB)
  await assert.rejects(() => verify(prepared.run, { apply: true }), /占满容量/)
  assert.equal(existsSync(join(prepared.run, '.lock')), false)
  assert.equal(existsSync(prepared.handoff), true)
  assert.equal(existsSync(unknown), true)
})

test('中断 prepare 的标识可恢复，不留下永远无法清理的半成品', (t) => {
  const f = fixture(t), prepared = f.prepare()
  const path = join(prepared.run, 'internal', 'state.json'), state = json(path)
  state.status = 'preparing'
  atomic(path, state)
  assert.equal(status(prepared.run).status, 'interrupted')
  age(prepared.run, 31)
  clean(f.root, { apply: true })
  assert.equal(existsSync(prepared.run), false)
})

test('status 是只读操作，过期和中断只返回推导状态，不改磁盘', (t) => {
  const f = fixture(t), prepared = f.prepare()
  const path = join(prepared.run, 'internal', 'state.json'), state = json(path)
  state.status = 'verifying'
  atomic(path, state)
  const before = readFileSync(path, 'utf8')
  assert.equal(status(prepared.run).status, 'interrupted')
  assert.equal(readFileSync(path, 'utf8'), before)
  writeFileSync(join(f.repo, 'new.mjs'), 'changed')
  assert.equal(status(prepared.run).status, 'stale')
  assert.equal(readFileSync(path, 'utf8'), before)
})

test('只裁决部分编号时报告状态也明确 partial，而非 verified', (t) => {
  const f = fixture(t), prepared = f.prepare()
  importResults(prepared.run, { results: [observation()] }, { apply: true })
  const result = complete(prepared.run, { results: [] }, { apply: true })
  assert.equal(result.status, 'partial')
  assert.equal(result.counts.Uncertain, 1)
})

test('Reverify 失败后不能把该编号的上一次结论冒充新结果', async (t) => {
  const f = fixture(t), prepared = f.prepare()
  importResults(prepared.run, { results: [observation()] }, { apply: true })
  await verify(prepared.run, { apply: true, cli: join(f.temp, 'missing') })
  assert.equal(status(prepared.run).results.length, 0)
  assert.throws(() => complete(prepared.run, { results: [observation()] }, { apply: true }), /尚无复核记录/)
})

test('status 以有效最终裁决为准，同时保留被推翻的复核意见；重试与过期不沿用 final', async (t) => {
  const f = fixture(t), prepared = f.prepare()
  importResults(prepared.run, { results: [observation('Refuted')] }, { apply: true })
  complete(prepared.run, { results: [observation('Confirmed')] }, { apply: true })
  const before = readFileSync(join(prepared.run, 'internal', 'state.json'), 'utf8')
  const result = status(prepared.run)
  assert.equal(result.status, 'completed')
  assert.equal(result.resultSource, 'final')
  assert.equal(result.results[0].status, 'Confirmed')
  assert.equal(result.observations[0].status, 'Refuted')
  assert.equal(readFileSync(join(prepared.run, 'internal', 'state.json'), 'utf8'), before)
  await verify(prepared.run, { apply: true, cli: join(f.temp, 'missing') })
  assert.deepEqual(status(prepared.run).results, [])
  assert.equal(status(prepared.run).resultSource, 'none')
  writeFileSync(join(f.repo, 'counter.mjs'), 'changed')
  assert.deepEqual(status(prepared.run).observations, [])
})

test('裁决修订标题、判级、描述与行号，report/status 一致且初审和复核历史不变', (t) => {
  const f = fixture(t)
  const original = { ...input, findings: [...input.findings, { ...input.findings[0], id: 'CR-002',
    priority: 'P2', title: '另一独立问题' }] }
  const prepared = f.prepare(original)
  importResults(prepared.run, { results: [observation(), observation('Confirmed', 'CR-002')] }, { apply: true })
  const finding = { title: '零输入返回负数', priority: 'P3', claim: '仅零输入路径出现本次回归。',
    location: { path: 'counter.mjs', line: 1 } }
  const data = { results: [{ ...observation(), evidence: '实参为 0 时，表达式 n - 1 为 -1。', finding },
    observation('Confirmed', 'CR-002')] }
  const preview = complete(prepared.run, data)
  assert.equal(existsSync(join(prepared.run, 'review-report.md')), false)
  assert.deepEqual(preview.results[0].finding, finding)
  const done = complete(prepared.run, data, { apply: true })
  const report = readFileSync(done.report, 'utf8')
  assert.match(report, /CR-001 \[P3\] 零输入返回负数 — counter.mjs:1/)
  assert.match(report, /仅零输入路径出现本次回归/)
  assert.ok(report.indexOf('CR-002') < report.indexOf('CR-001'))
  const first = report.slice(report.indexOf('### CR-001'))
  assert.equal(first.includes(input.findings[0].claim), false)
  assert.equal(report.includes(input.findings[0].title), false)
  assert.deepEqual(status(prepared.run).results[0].finding, finding)
  assert.equal(status(prepared.run).observations[0].evidence, observation().evidence)
  assert.deepEqual(json(join(prepared.run, 'internal', 'findings.json')).findings, original.findings)
})

test('L2 裁决产物真实经过 complete，错误 location 格式被拒绝', (t) => {
  const f = fixture(t), output = join(f.temp, 'artifacts')
  mkdirSync(output)
  const data = { results: [{ ...observation(), finding: { title: '负数输入错误', priority: 'P2',
    claim: '负数分支的返回值与契约不符。', location: 'counter.mjs:2' } }] }
  assert.throws(() => validateAdjudicationArtifact(f.repo, output, JSON.stringify(data)), /相对路径/)
  data.results[0].finding.location = { path: 'counter.mjs', line: 2 }
  const final = validateAdjudicationArtifact(f.repo, output, '```json\n' + JSON.stringify(data) + '\n```')
  assert.equal(final.resultSource, 'final')
  assert.equal(final.results[0].finding.priority, 'P2')
  assert.match(readFileSync(final.report, 'utf8'), /\[P2\] 负数输入错误/)
  assert.equal(readFileSync(join(f.repo, 'counter.mjs'), 'utf8'), 'export function increment(n) {\n  return n - 1\n}\n')
})

test('L2 裁决解析跳过源码块，拒绝多个候选 JSON 而不猜测', (t) => {
  const f = fixture(t)
  const output = join(f.temp, 'evaluation-code-before-json')
  mkdirSync(output)
  const data = { results: [{ id: 'CR-001', status: 'Confirmed', evidence: '负数分支返回 n - 1。', finding: { priority: 'P2' } }] }
  const json = '```json\n' + JSON.stringify(data) + '\n```'
  assert.throws(() => validateAdjudicationArtifact(f.repo, output, json + '\n' + json), /多个裁决 JSON/)
  const final = validateAdjudicationArtifact(f.repo, output, '源码：\n```javascript\nreturn n - 1\n```\n裁决：\n' + json)
  assert.equal(final.resultSource, 'final')
  assert.equal(final.results[0].finding.priority, 'P2')
})

test('旧三字段裁决与旧 final 仍可读取，部分修订只覆盖指定字段', (t) => {
  const f = fixture(t), prepared = f.prepare()
  importResults(prepared.run, { results: [observation()] }, { apply: true })
  complete(prepared.run, { results: [{ ...observation(), finding: { priority: 'P2' } }] }, { apply: true })
  assert.equal(status(prepared.run).results[0].finding.priority, 'P2')
  assert.equal(status(prepared.run).results[0].finding.title, input.findings[0].title)
  complete(prepared.run, { results: [observation()] }, { apply: true })
  assert.equal(status(prepared.run).results[0].finding.priority, 'P1')
  atomic(join(prepared.run, 'internal', 'final.json'), { results: [observation()], summary: '旧格式' })
  assert.deepEqual(status(prepared.run).results, [observation()])
})

test('无效修订不落盘，不允许通过 finding 改编号或绕过未复核限制', (t) => {
  const f = fixture(t), prepared = f.prepare()
  const finish = (finding) => complete(prepared.run, { results: [{ ...observation(), finding }] }, { apply: true })
  assert.throws(() => finish({ title: '新标题' }), /尚无复核记录/)
  importResults(prepared.run, { results: [observation()] }, { apply: true })
  for (const finding of [null, [], { id: 'CR-002' }, { priority: 'P9' }, { title: '' }, { claim: ' ' },
    { location: { path: '../outside', line: 1 } }, { location: { path: 'counter.mjs', line: 0 } },
    { location: { path: 'missing.mjs', line: 1 } }]) {
    assert.throws(() => finish(finding))
    assert.equal(existsSync(join(prepared.run, 'review-report.md')), false)
  }
})

test('修订位置可指向已有文件，但不能跳过新位置适用的规则快照', (t) => {
  const f = fixture(t)
  mkdirSync(join(f.repo, 'legacy'))
  writeFileSync(join(f.repo, 'legacy', 'reader.mjs'), 'export const read = () => 0\n')
  writeFileSync(join(f.repo, 'legacy', 'AGENTS.md'), '读取规则\n')
  writeFileSync(join(f.repo, 'spec.md'), '显式需求\n')
  f.git('add', 'spec.md')
  f.git('add', 'legacy'); f.git('commit', '-qm', 'reader')
  const prepared = f.prepare()
  importResults(prepared.run, { results: [observation()] }, { apply: true })
  assert.throws(() => complete(prepared.run, { results: [{ ...observation(), finding: {
    location: { path: 'legacy/reader.mjs', line: 1 },
  } }] }, { apply: true }), /未保存的项目规则/)
  const withRules = f.prepare({ ...input, ruleFiles: ['spec.md', 'legacy/AGENTS.md'] })
  importResults(withRules.run, { results: [observation()] }, { apply: true })
  complete(withRules.run, { results: [{ ...observation(), finding: {
    location: { path: 'legacy/reader.mjs', line: 1 },
  } }] }, { apply: true })
  assert.equal(status(withRules.run).results[0].finding.location.path, 'legacy/reader.mjs')
})

test('长单行和多字节材料均可逐片读取并精确还原；报告只保留结论、摘要与记录入口', (t) => {
  const f = fixture(t)
  const longRule = '规则🌏中"\\\n'.repeat(20000)
  writeFileSync(join(f.repo, 'AGENTS.md'), longRule)
  const checks = ['单行日志🌏'.repeat(20000), ...Array(5000).fill('多条短检查记录。')], gaps = ['待验证：'.repeat(20000)]
  const prepared = f.prepare({ ...input, checks, gaps })
  const materials = json(join(prepared.run, 'internal', 'materials.json'))
  const restore = ({ parts }) => parts.map((part) => {
    const bytes = readFileSync(join(materials.baseDir, part))
    assert.ok(bytes.length <= 16 * 1024)
    assert.equal(Buffer.from(bytes.toString('utf8')).equals(bytes), true)
    return bytes.toString('utf8')
  }).join('')
  assert.equal(restore(materials.rules.find((r) => r.path === join(f.repo, 'AGENTS.md'))), longRule)
  assert.equal(restore(materials.checks), checks.join('\n\n'))
  assert.equal(materials.checks.count, checks.length)
  assert.ok(materials.checks.parts.length < 100)
  assert.ok(readFileSync(join(prepared.run, 'internal', 'materials.json')).length < 20000)
  assert.equal(restore(materials.gaps), gaps[0])
  importResults(prepared.run, { results: [observation()] }, { apply: true })
  const done = complete(prepared.run, { results: [observation()], validationSummary: '源码核对成立；Windows 实机尚未验证。' }, { apply: true })
  const report = readFileSync(done.report, 'utf8')
  assert.ok(Buffer.byteLength(report) < 3000)
  assert.match(report, /源码核对成立；Windows 实机尚未验证/)
  assert.match(report, /internal\/materials.json/)
  assert.equal(report.includes(checks[0]), false)
  assert.equal(report.includes(gaps[0]), false)
  assert.equal(json(join(prepared.run, 'internal', 'findings.json')).checks[0], checks[0])
  assert.equal(json(join(prepared.run, 'internal', 'final.json')).validationSummary, '源码核对成立；Windows 实机尚未验证。')
  assert.throws(() => complete(prepared.run, { results: [], validationSummary: checks[0] }), /至多 4 KiB/)
})

test('显式依据缺失或指向目录时可交接且诊断明确，自动缺席规则不报缺口；补文件使旧快照过期', async (t) => {
  const f = fixture(t)
  mkdirSync(join(f.repo, 'docs'))
  const prepared = f.prepare({ ...input, ruleFiles: ['docs/spec.md', 'docs'] })
  assert.equal(prepared.status, 'ready')
  assert.equal(prepared.ruleGaps.length, 2)
  assert.match(prepared.ruleGaps[0], /docs.*spec.md.*文件不存在/)
  assert.match(prepared.ruleGaps[1], /docs.*不是普通文件/)
  assert.ok(readFileSync(prepared.handoff, 'utf8').includes('docs/spec.md'))
  const materials = json(join(prepared.run, 'internal', 'materials.json'))
  assert.equal(materials.rules.find((r) => r.path === join(f.repo, 'docs', 'spec.md')).missing, '文件不存在')
  assert.equal(materials.rules.some((r) => r.path.endsWith('CLAUDE.md')), false)
  const result = await verify(prepared.run, { apply: true, cli: process.execPath,
    runner: mock([observation('Uncertain')], ({ input: prompt }) => {
      assert.ok(prompt.includes('文件不存在'))
      assert.ok(prompt.includes('其余项继续核查'))
    }) })
  assert.equal(result.status, 'verified')
  const report = complete(prepared.run, { results: [observation('Uncertain')] }, { apply: true })
  assert.ok(readFileSync(report.report, 'utf8').includes('spec.md'))
  writeFileSync(join(f.repo, 'docs', 'spec.md'), '现在提供明确需求。')
  assert.equal(status(prepared.run).status, 'stale')
})

test('已有运行从保存的快照派生可读材料，不改初审且不依赖当前安装规则', async (t) => {
  const f = fixture(t), prepared = f.prepare()
  const original = readFileSync(join(prepared.run, 'internal', 'findings.json'))
  rmSync(join(prepared.run, 'internal', 'materials.json'))
  rmSync(join(prepared.run, 'internal', 'materials'), { recursive: true })
  const result = await verify(prepared.run, { apply: true, cli: process.execPath,
    runner: mock([observation()], ({ input: prompt }) => {
      assert.ok(prompt.includes('materials.json'))
      const materials = json(join(prepared.run, 'internal', 'materials.json'))
      assert.equal(materials.checks.parts.map((part) => readFileSync(join(materials.baseDir, part), 'utf8')).join(''), input.checks[0])
    }) })
  assert.equal(result.status, 'verified')
  assert.equal(readFileSync(join(prepared.run, 'internal', 'findings.json')).equals(original), true)
})

const flutterSelection = { id: 'flutter', root: '.', basis: 'pubspec.yaml 有 Flutter SDK 依赖；版本约束 >=3.10.0。' }

test('无专项保持原接口；显式专项预览不写盘，快照和分片内容一致', (t) => {
  const f = fixture(t)
  const before = f.git('status', '--porcelain')
  const profiles = [flutterSelection]
  const preview = prepare({ ...input, profiles }, { repo: f.repo, outputDir: f.root })
  assert.equal(preview.profiles[0].id, 'flutter')
  assert.equal(existsSync(f.root), false)
  const prepared = f.prepare({ ...input, profiles })
  const state = json(join(prepared.run, 'internal', 'state.json'))
  const saved = savedProfiles(prepared.run, state)
  assert.equal(saved[0].root, '.')
  assert.equal(saved[0].basis, flutterSelection.basis)
  assert.equal(saved[0].text, readFileSync(new URL('../profiles/flutter.md', import.meta.url), 'utf8'))
  const materials = json(join(prepared.run, 'internal', 'materials.json'))
  const entry = materials.profiles[0]
  assert.equal(entry.sha256, saved[0].sha256)
  assert.equal(entry.parts.map((part) => readFileSync(join(materials.baseDir, part), 'utf8')).join(''), saved[0].text)
  assert.equal(f.git('status', '--porcelain'), before)
  const plain = f.prepare({ ...input, profiles: [] })
  assert.deepEqual(json(join(plain.run, 'internal', 'materials.json')).profiles, [])
  assert.equal(json(join(plain.run, 'internal', 'state.json')).profilesFingerprint, undefined)
})

test('混合仓库保留各 package 范围；索引新增专项可直接组合且无需改主流程', (t) => {
  const f = fixture(t)
  for (const dir of ['apps/mobile', 'packages/widgets', 'packages/dart']) mkdirSync(join(f.repo, dir), { recursive: true })
  const skill = join(f.temp, 'independent-skill')
  cpSync(fileURLToPath(new URL('..', import.meta.url)), skill, { recursive: true })
  const index = json(join(skill, 'profiles', 'index.json'))
  atomic(join(skill, 'profiles', 'index.json'), [...index, { id: 'example-language', file: 'example.md', appliesTo: 'Fixture only' }])
  writeFileSync(join(skill, 'profiles', 'example.md'), '夹具语言规则：按实际对象判断。')
  const selected = [
    { ...flutterSelection, root: 'apps/mobile' },
    { ...flutterSelection, root: 'packages/widgets' },
    { id: 'example-language', root: 'apps/mobile', basis: '夹具用于组合测试' },
  ]
  const profiles = collectProfiles(skill, f.repo, selected)
  assert.deepEqual(profiles.map((p) => [p.id, p.root]), selected.map((p) => [p.id, p.root]))
  assert.ok(profiles.every((p) => p.root !== 'packages/dart'))
  assert.ok(profiles[2].text.includes('夹具语言规则'))
})

test('非法专项、目录、空依据及重复组合在写盘前拒绝', (t) => {
  const f = fixture(t)
  for (const profiles of [null, ['flutter'], [{ ...flutterSelection, id: '../flutter' }],
    [{ ...flutterSelection, basis: ' ' }], [{ ...flutterSelection, root: '../outside' }],
    [{ ...flutterSelection, root: 'counter.mjs' }], [{ ...flutterSelection, root: 'missing' }],
    [{ ...flutterSelection, id: 'react' }], [flutterSelection, { ...flutterSelection, root: './' }]]) {
    assert.throws(() => prepare({ ...input, profiles }, { repo: f.repo, outputDir: f.root, apply: true }))
    assert.equal(existsSync(f.root), false)
  }
  const outside = join(f.temp, 'outside')
  mkdirSync(outside)
  symlinkSync(outside, join(f.repo, 'linked'), process.platform === 'win32' ? 'junction' : 'dir')
  assert.throws(() => collectProfiles(fileURLToPath(new URL('..', import.meta.url)), f.repo,
    [{ ...flutterSelection, root: 'linked' }]), /适用目录无效/)
})

test('自动及手动交接用同一份专项；安装来源删除后局部复核和裁决仍可继续', async (t) => {
  const f = fixture(t)
  const prepared = f.prepare({ ...input, profiles: [flutterSelection] })
  const original = json(join(prepared.run, 'internal', 'profiles.json'))
  const handoff = readFileSync(prepared.handoff, 'utf8')
  assert.match(handoff, /专项 profiles/)
  assert.doesNotMatch(handoff, /# Flutter 专项/)
  const skill = join(f.temp, 'skill-without-current-profiles')
  cpSync(fileURLToPath(new URL('..', import.meta.url)), skill, { recursive: true })
  const isolated = await import(pathToFileURL(join(skill, 'scripts', 'review.mjs')).href)
  rmSync(join(skill, 'profiles'), { recursive: true })
  rmSync(join(prepared.run, 'internal', 'materials.json'))
  const result = await isolated.verify(prepared.run, { apply: true, ids: ['CR-001'], cli: process.execPath,
    runner: mock([observation()], ({ input: prompt }) => {
      assert.match(prompt, /已选专项/)
      assert.match(prompt, /仅复核输入编号/)
      const index = json(join(prepared.run, 'internal', 'materials.json'))
      assert.equal(index.profiles[0].root, '.')
      assert.equal(index.profiles[0].parts.map((part) => readFileSync(join(index.baseDir, part), 'utf8')).join(''), original[0].text)
    }) })
  assert.equal(result.status, 'verified')
  assert.equal(isolated.complete(prepared.run, { results: [observation()] }, { apply: true }).status, 'completed')
  assert.deepEqual(json(join(prepared.run, 'internal', 'profiles.json')), original)
})

test('专项快照缺失或篡改时保留交接、不启动复核、不沿用最终裁决', async (t) => {
  const f = fixture(t)
  const prepared = f.prepare({ ...input, profiles: [flutterSelection] })
  importResults(prepared.run, { results: [observation()] }, { apply: true })
  complete(prepared.run, { results: [observation()] }, { apply: true })
  const path = join(prepared.run, 'internal', 'profiles.json')
  const profiles = json(path)
  atomic(path, [{ ...profiles[0], root: 'wrong' }])
  const before = readFileSync(join(prepared.run, 'internal', 'state.json'), 'utf8')
  const invalid = status(prepared.run)
  assert.equal(invalid.status, 'failed')
  assert.equal(invalid.resultSource, 'none')
  assert.match(invalid.diagnostic, /专项规则快照缺失或损坏/)
  assert.equal(readFileSync(join(prepared.run, 'internal', 'state.json'), 'utf8'), before)
  rmSync(path)
  await assert.rejects(verify(prepared.run, { apply: true, cli: process.execPath,
    runner: () => assert.fail('不应调用模型') }), /请重新 prepare/)
  assert.throws(() => importResults(prepared.run, { results: [observation()] }, { apply: true }), /请重新 prepare/)
  assert.throws(() => complete(prepared.run, { results: [observation()] }, { apply: true }), /请重新 prepare/)
  assert.equal(existsSync(prepared.handoff), true)
})

test('复核期间专项快照变化不能接受模型结果', async (t) => {
  const f = fixture(t)
  const prepared = f.prepare({ ...input, profiles: [flutterSelection] })
  const result = await verify(prepared.run, { apply: true, cli: process.execPath,
    runner: mock([observation()], () => rmSync(join(prepared.run, 'internal', 'profiles.json'))) })
  assert.equal(result.status, 'failed')
  assert.match(result.diagnostic, /专项规则快照/)
  assert.deepEqual(result.results, [])
  assert.deepEqual(json(join(prepared.run, 'internal', 'state.json')).observations, {})
})

test('旧运行未记录专项时不依赖专项文件或安装来源', async (t) => {
  const f = fixture(t)
  const prepared = f.prepare()
  rmSync(join(prepared.run, 'internal', 'profiles.json'))
  const index = json(join(prepared.run, 'internal', 'materials.json'))
  delete index.profiles
  atomic(join(prepared.run, 'internal', 'materials.json'), index)
  assert.equal(status(prepared.run).status, 'ready')
  const result = await verify(prepared.run, { apply: true, cli: process.execPath,
    runner: mock([observation()], ({ input: prompt }) => assert.doesNotMatch(prompt, /已选专项/)) })
  assert.equal(result.status, 'verified')
})

function jsonFrom(text) { return JSON.parse(text.trim()) }
