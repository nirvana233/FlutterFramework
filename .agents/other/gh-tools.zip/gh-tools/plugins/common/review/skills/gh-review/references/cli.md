# 调用与数据接口

脚本是本 Skill 的 `scripts/review.mjs`，用 Node.js 22+ 执行；prepare 需要 Git，verify 另需已认证的原生 Claude CLI。路径一律用绝对路径或进程参数数组传递。以下命令中的 `SCRIPT`、`RUN`、`ROOT`、`REPO` 是占位符，不是必须设置的环境变量。

## 初审输入

输入字段与展示步骤见 [初审数据接口](output.md)。prepare 使用相同 findings、scope 及可选上下文字段，不要求 scopeLabel。

`worktree` 覆盖暂存、未暂存和未跟踪；`branch` 要提供 `base`，按共同祖先审查；`range` 使用显式 `base` 和 `target`，不转成共同祖先。提交比较模式 `target` 默认 HEAD，必须在干净且匹配目标的 checkout 中复核；不自动 checkout 或 reset。

`snapshot` 保存目标功能的现有代码清单，无需 diff 或 `base`。例如 `{"scope":{"kind":"snapshot","paths":["lib/login"]},"findings":[...]}`。默认读取当前 checkout，允许工作区改动；显式提供 `target` 时要求 HEAD 对应且 checkout 干净。指定历史提交应在对应 checkout 中操作。所有类型仅定位代码、核对版本和提供归因参考，不限制复核缺陷是否成立。

可选 `scope.paths` 为仓库相对路径/目录数组（正斜杠、无 glob）。未指定则整个改动或整个现有代码快照。Finding 可定位于相关的未修改或清单外仓库文件；复核可沿该问题的调用链取证。脚本校验位置可定位（增量中的删除文件可定位基线）；版本指纹覆盖 HEAD、范围和全工作区变化。手动核对时比较 HEAD、workingFiles 的 SHA-256/删除标记和本地 Git diff；固定提交目标必须干净且 HEAD 对应 target。snapshot 的 review.diff 为空，仅表示没有采用比较差异。

`ruleFiles` 是额外的仓库内需求或规则文件；默认收集改动文件及 Finding 位置适用的 AGENTS.md、CLAUDE.md、CODING_STANDARDS.md、CONTRIBUTING.md，不自动执行其指令。显式文件不存在或不是普通文件时，仍保存交接，在返回的 ruleGaps、交接和材料索引中列出路径与原因；依赖该依据且无法由其他证据判定的项归 Uncertain，继续检查其他项。自动发现的可选规则不存在时不报缺口。补齐文件后规则指纹变化，需要重新 prepare。对于更深的调用方规则或远端需求，初审 agent 阅读后在输入中补必要依据。

自动复核只内联当次 Findings、共享标准与材料入口；internal/materials.json 索引列出规则原路径以及 checks / gaps 的文本片段。文本绝对路径由索引的 baseDir 加 parts 文件名组成，按顺序拼接可还原原文；每片至多 16 KiB，保持 UTF-8 字符完整，即使原文是长单行也能逐片读取。按适用范围读取规则，根目录/祖先规则与显式需求不能遗漏；按问题需要读取检查/缺口。原始 JSON 留作完整结构化来源，自动和手动复核优先从索引进入，不全文展开长 JSON。完整 diff、文件清单按需读取。影响单项判定的关键依据和已知缺口放在该项 claim / basis 中；无需新增必填字段。

## 复核流程的调用顺序

`profiles` 为可选数组，省略或 `[]` 表示只用通用规则；脚本不自动检测框架。agent 按 [专项选择](profiles.md) 传入：`id` 必须存在于内置索引，`root` 为现存仓库相对 package 目录（根目录 `.`），`basis` 为非空的选择来源及版本边界。同一 ID/root 不重复，多个 ID 可组合。尚未提供或不适用的专项写入 gaps，不传未知 ID；错误输入或规则文件会在写盘前拒绝。

需要交接或复核时，可将必要源码核查事实写入 `checks`；无需逐维度编写清单或复制正常检查流水。已有 Findings 的 Verify/只交接没有这些记录时仍可准备，不回头重开初审；`checks` 在脚本协议中仍可省略。记录不是新的独立复核或测试通过证明。

prepare 将完整文本及元数据保存为 `internal/profiles.json`，state 保存集合指纹，每个文本保存 SHA-256；materials.json 的 profiles 提供目录、依据、文本指纹及分片入口。verify/import/complete/status 核对快照，安装包更新不替换旧运行规则。已记录而快照缺失或损坏时需重新 prepare，status 不返回旧裁决；未记录专项的旧运行不要求此文件。材料索引缺失时从快照重建，不从安装包补专项。

以下用于需要复核的流程；普通初审直接聊天交付，不调用 prepare 或 verify。只交接或用户要求初审留档时执行 prepare 后结束。

```text
node SCRIPT prepare --input - --repo REPO --apply
node SCRIPT verify --run RUN --apply
node SCRIPT complete --run RUN --input - --apply
```

prepare / import / complete 的 stdin 是 JSON；避免在业务仓库创建中间输入文件。prepare 返回精简 JSON 中的 `handoff` 后，**立即显示绝对路径链接**；需要复核且有 Findings 时再 verify。不指定 `--apply` 时只预览，不联网调用或写产物。

每项返回 `{"id":"CR-001","status":"Confirmed|Refuted|Uncertain","evidence":"关键证据或缺口","origin":{"kind":"unknown","basis":"尚无可确认的引入记录"}}`，包在 `{"results":[...]}` 内。origin 是向后兼容的可选字段，结构见 [来源接口](origin.md)。Claude JSON 输出 envelope 的 `structured_output` 由脚本提取；失败和无效输出不能算通过。complete 输入同一结构，是 agent 核对后的最终裁决；未完成项保留 Uncertain。complete 可额外传 validationSummary（至多 4 KiB 的审查检查总结及整体未覆盖边界，不是修复验证计划）。

初审 findings、复核 results、最终 results 都可保存 origin。complete 优先采用本次裁决的 origin，未传时沿用该编号最新复核记录，再沿用原初审；均未记录则展示“引入未确定”。重试和裁决保留各自历史，不覆盖原始判断。归因错误不意味着缺陷不成立；必要时同时修订 finding.claim/title。对判定有影响的缺口写进 evidence。

complete 的每项可另传 `finding` 对象，仅包含需修订的 `title` / `priority` / `claim` / `location`；省略字段表示沿用初审，location 若提供须含 path 与 line。标题描述错误行为，claim 写触发条件和影响，evidence 写关键证据，避免重复。每次 complete 均以原初审为基底，重复裁决需重传要保留的修订。示例：

```json
{"results":[{"id":"CR-001","status":"Confirmed","evidence":"仅离线读取分支复用了上一账户的缓存；在线分支已按账户隔离。","finding":{"title":"离线切换账户后显示旧数据","priority":"P2","claim":"离线状态切换账户后，读取缓存仍返回上一账户的数据。"}}]}
```

脚本按最终判级排序，报告及 status 的 final results 使用完整的 finding；原初审和 observations 不被覆盖。新位置须可定位，若涉及未保存的项目规则需重新 prepare。旧三字段输入仍可用；旧 final 无 finding 时仍按旧格式读取。断言修订仅由 agent 核实后传给 complete。

`verify --ids CR-001,CR-002` 显式重试/局部复核，保留历史。不自动无限重试。手动复核返回 JSON 后使用 `import --run RUN --input - --apply`；普通文字由 agent 核实并转换后导入，不能自行补造证据。

`status --run RUN` 查看状态、有效结果与诊断，识别已退出的运行。results 优先返回有效的最终裁决（resultSource 为 final），observations 单独保留原复核意见；未裁决时 results 返回复核记录（resultSource 为 observations），不能称为最终结论。重试使旧报告失效，过期时不返回旧结论。只把必要结果呈现给用户，不原样展示所有内部元数据。退出码 0 成功/预览，1 失败/部分/过期，2 参数错误，130 中断。

## 配置与权限

verify 可覆盖 `--model`、`--effort`、`--timeout-ms`、`--cli`，或 `--config` 指定 JSON 文件（字段 `model` / `effort` / `timeoutMs` / `cli`）。模型按本次参数 > 显式配置选择；两者都未指定时不传 `--model`，由本机 CLI 沿用用户配置和环境变量。其他默认值为 high/900000ms。不创建或改动全局用户配置。

使用 CLI safe-mode、仅 Read/Glob/Grep、dontAsk、禁用 slash commands、空 MCP 和无 session 持久化。safe-mode 需本地 CLI 支持；不支持时保持交接入口，不撤掉限制以勉强运行。模型别名由本机 provider 解析；思考等级可能被模型或组织限制，记录中不能虚构生效等级。

调用记录的 `reportedModels` 只保存 CLI 返回的 `modelUsage` 名称；它不是 HTTP 请求抓取，也不能证明网关实际执行了哪个模型。

Windows 使用 `claude.exe`，macOS/Linux 使用可执行 `claude`；可指定完整路径。Windows 的 cmd/bat 包装器不自动执行。程序不将 prompt 拼成 shell 命令，使用 stdin 传递。进程受超时控制，Ctrl-C 终止子进程树并保留材料；强制杀死父进程后下次检查标中断。

CLI 工具约束不是 OS 沙箱；父环境的网络/缓存写入审批仍适用。审批拒绝时说明实际原因并保留手动交接；不能改权限位或用其他路径绕过。

## 产物与清理

默认根目录：Windows LOCALAPPDATA（无则用户目录 AppData/Local）、macOS Library/Caches、Linux XDG_CACHE_HOME（无则 .cache）下的 `gh-tools/reviews`。prepare/cleanup 可用 `--output-dir ROOT`，必须在仓库外。每次使用仓库名+路径短哈希、UTC 时间+随机 ID，支持空格中文路径。

复核流程默认只展示 `review-handoff.md`、`review-report.md`；只初审默认无文件产物；只交接或用户要求初审留档时仅保留 handoff。内部目录保存初审、版本清单、diff、规则、调用和状态，用户无需管理。

prepare 将本次使用的共同缺陷标准、复核补充标准和来源核查冻结为 `internal/review-rules.md`，组成与边界见 [复核标准](review-rules.md)。初审的范围选择与增量筛选不进入复核快照。自动 Claude 和手动复核使用同一份已保存标准，确保判断依据可核对；安装包更新不替换旧运行的规则，采用新标准需要重新 prepare。

项目依据保存为 `internal/project-rules.json`，并从原始快照派生 `internal/materials.json` 与只读文本片段；handoff 提供相对链接。已有运行缺少材料索引时，下一次 verify / complete 从其保存的原始数据派生，不覆盖初审；缺少共享规则快照仍需重新 prepare。手动在原仓库让 Claude 读取 handoff，先核对版本并读取所链接的材料；手动读取链接材料要提供目录访问权限。

完整复核并裁决后保留 7 天，其余保留 30 天；每根目录 500 MiB 上限、每 attempt 日志 10 MiB。调用前后按过期→旧完成→旧未完成顺序清理；活跃锁/本次操作受保护。期限不是最低保留保证。单次产物写不下则停新增，不删当前交接。

```text
node SCRIPT cleanup --output-dir ROOT
node SCRIPT cleanup --output-dir ROOT --apply
```

第一条预览，第二条执行；仅清理有效管理目录，不跟随链接/junction。不安装后台任务，长期不用不会按日历删除。长期留档的报告导出到管理根目录之外。
