# Flutter 专项

用于有 Flutter SDK 依赖的 app/package。先读目标项目 `pubspec.yaml`、可取得的 SDK/依赖版本和架构约定，再选择与当前改动或输入 Finding 相关的条目。项目自带的规范与统一工具（`AGENTS.md`、项目级规则、分析配置、通用组件）优先于本文的推荐写法；本文只补项目规范通常没写到的框架级坑。任何偏离都以可观察后果定级，不因偏离风格本身成立。以下官方约束适用于提供对应 API 的目标 SDK；旧版 API 与第三方库实现须另行核对。结论仍满足共同审查规则，严重程度由实际后果决定。

## F1 生命周期与所有权

**框架约束**：State.setState 在 dispose 后失效，回调应同步执行。使用 BuildContext 时须保证该 context 有效；异步后的保护须对应实际使用的 context，不只是另一个 State。普通 controller/service/repository 不适用 Widget 的 mounted 约束。

**核查**：请求、timer、监听能否晚于销毁；项目取消机制或 mounted/closed/generation 保护是否覆盖回调。资源按实际所有权核对释放；上游管理的资源不要求每个使用者 dispose。订阅对象替换时核实旧监听移除、新监听绑定和最终清理。

保护必须属于当前写入所使用的对象；另一个页面的 mounted/generation 不构成反证。生命周期与请求身份的触发和后果分别核实。

**缺陷例**：本次新增页面请求，用户可返回，完成后直接 setState；或 notifier 更换后仍监听旧对象，展示旧账号数据。

**正常反例**：相关 State 回调检查自身 mounted；传入 context 使用前检查该 context.mounted；上游确保取消后不再回调；普通 controller 更新 app 生命周期内状态并由 UI 自行订阅。mounted 可排除非法 UI 更新，不自动排除请求乱序或资源泄漏。

依据：[setState](https://api.flutter.dev/flutter/widgets/State/setState.html)、[BuildContext.mounted](https://api.flutter.dev/flutter/widgets/BuildContext/mounted.html)、[订阅对象替换](https://api.flutter.dev/flutter/widgets/State/didUpdateWidget.html)、[context 检查范围](https://dart.dev/tools/linter-rules/use_build_context_synchronously)。有效 mounted 保护下缺少取消本身不是崩溃证据。

## F2 异步竞态与状态更新

**框架约束**：FutureBuilder 的 future 在 build 中重新创建时，父级重建可重新启动任务。核对实际 snapshot 契约和项目状态管理；不同库的通知、相等性、销毁方式需查对应版本。

**项目行为核查**：沿入口、请求、状态写入、UI 消费者追踪快速变更查询/账号/参数时的顺序。业务要求以当前选择为准时，检查旧响应是否覆盖新结果，identity/generation、取消或串行机制是否有效。

**缺陷例**：搜索先发 A 后发 B，B 先完成，A 后完成且无条件覆盖当前 B 的列表；或本次将有写副作用的请求搬进 build，已知重建路径会重复提交。

**正常反例**：最新请求 token 排除旧响应；业务允许并发任务分别落盘；future 已缓存，build 只读取它。async 不必然需要取消，mutable model 不必然导致 UI 不刷新；须沿通知与消费链路证明错误。

顺序和通知缺陷按共同规则核实具体输入、完成顺序、实际结果和消费者契约。位于 Flutter 目录不证明一个普通对象由 UI 订阅；技术约束不能代替错误后果证据。

依据：[FutureBuilder 管理与 snapshot 契约](https://api.flutter.dev/flutter/widgets/FutureBuilder-class.html)、[Dart 异步执行](https://dart.dev/libraries/async/async-await)。请求顺序依据业务契约，不是“所有请求必须 latest-wins”的框架规定。

## F3 导航、返回结果与数据一致性

**框架约束**：Navigator.push 的 Future 随 route 的 pop 结果完成，结果可空，类型需与 route 契约一致。第三方 router、守卫、深链按项目实际 API 核查。

**核查**：普通返回、取消、保存、登录后返回的结果是否被各调用方正确消费；异步 context 使用按 F1 判断。参数沿真实解析/保护路径核实。

**缺陷例**：保存结果从 true 改为对象，旧列表仍以 result == true 刷新，导致保存后持续展示旧数据；新增 result!，普通返回时为空并抛错；新增必填参数没有传，解析处静默退化成空对象，页面照常发起一次无效请求或显示为空。

**正常反例**：列表订阅共享状态或恢复时回源，无需额外刷新；统一守卫已验证参数；取消返回 null 被正常忽略。

依据：[Navigator.push](https://api.flutter.dev/flutter/widgets/Navigator/push.html)、[页面返回数据](https://docs.flutter.dev/cookbook/navigation/returning-data)。历史客户端接收新路由/payload 的版本轴归 gh-version-compatibility-review，不因普通导航改动自动启动跨版本审查。

## F4 失败、空态与恢复

**框架约束**：FutureBuilder 的 snapshot 可处于等待、无数据或 error，`hasError` 只在 future 以错误完成时为真；失败分支返回 `null` 或吞掉异常，页面会停在 `hasData` 的空数据或 loading 分支，而不是进入错误态。网络、token 刷新、异常归一及缓存策略依据实际项目契约，不要求每层 catch 或统一增加重试。

**核查**：超时、取消、错误、空集合/空值的终态；loading、提交锁及乐观状态的恢复。读上游转换和下游容错后再判断，特别检查搬迁丢失的 finally/default/error 分支。

**缺陷例**：删除 finally 后失败让 loading 永久为 true，重试按钮不可用；空列表改为 null，消费者仍按成功数据解引用；HTTP 非 2xx 时 `return null` 而不抛错，`hasError` 始终为假，页面停在 loading 或空列表。

**正常反例**：repository 转换失败为 Result，页面显示终态；全局恢复确实覆盖当前失败；按需求保留上次结果并提示错误。缺少局部 catch、错误 widget、离线缓存或测试本身不是缺陷。

依据：[FutureBuilder](https://api.flutter.dev/flutter/widgets/FutureBuilder-class.html)、[Dart async 错误处理](https://dart.dev/libraries/async/async-await)。loading 恢复是项目行为，不能把每个 loading 变量推断为框架问题。

## F5 平台能力与外部边界

**框架约束**：MethodChannel.invokeMethod 可返回 null，或因类型不匹配、PlatformException、MissingPluginException 失败。支持平台、权限和插件能力需核对目标配置及对应版本实现。

**核查**：入口在目标平台是否可达；wrapper、条件导入、权限拒绝及上游 catch 是否给正确终态。release 开关、Web、RTL 只检查本项目支持且本次触及的行为。

**缺陷例**：仅 Android 实现的 channel 入口本次无条件显示在项目支持的 Web 端，等待成功且无异常恢复，操作无法完成。

**正常反例**：平台 gate 排除不支持的平台；wrapper 转换 missing plugin 为业务降级；产品只支持 Android，不能虚构 iOS/Web 需求。

依据：[MethodChannel.invokeMethod](https://api.flutter.dev/flutter/services/MethodChannel/invokeMethod.html)。静态可达性只能证明已读路径；设备、权限、原生实现及账号未实测时明确边界。

## F6 状态真相源与局部状态

**框架约束**：`setState` 只重建本组件，不约束其他副本；`ValueKey` 决定元素复用身份，缺省按位置匹配；同一数据存在两个可写副本时框架不会同步。第三方状态库的相等性、通知与销毁语义按其版本文档核对。

**核查**：同一个值是否存在两处写入点——组件内部状态与外部数据源各写一份；列表项用索引还是稳定 id 作 key 与操作对象；原地修改可变对象后是否真的发出通知；乐观更新失败是否回滚。

**缺陷例**：开关组件内部维护 `_value`，外部设置变化不回传，UI 与服务端长期不一致；列表以索引作 key，删除中间项后错误复用上一行的展开状态；`sort()` 原地排序后未触发通知，界面顺序与数据不符。

**正常反例**：受控组件由单一真相源驱动；展开、悬停、动画进行中这类纯局部状态留在组件内；可变对象由显式 `notifyListeners` / `refresh` 驱动，且消费者确实订阅。

依据：[State](https://api.flutter.dev/flutter/widgets/State-class.html)、[ValueKey](https://api.flutter.dev/flutter/foundation/ValueKey-class.html)、[ChangeNotifier](https://api.flutter.dev/flutter/foundation/ChangeNotifier-class.html)。两处状态不同步只有能指出具体操作序列与错误显示时才算缺陷。

## F7 持久化与本地缓存

**框架约束**：先区分实际 API 与版本：`SharedPreferences` 和 `SharedPreferencesWithCache` 使用本地缓存；`SharedPreferencesAsync` 不使用本地缓存，读取直接交给平台。多 isolate、多个 engine 或原生代码写入时，缓存可能需要 `reload`。值限基础类型，对象需自行序列化；写入返回不保证数据已持久化，不能用它存储关键数据。

**核查**：写入结果和失败是否按调用方契约处理；使用缓存的 API 是否有外部写入及对应刷新；key 是否按用户隔离，切账号后会不会读到上一个账号的数据；退出登录的清理范围是否覆盖新增 key；新字段对旧版本已存数据是否兼容；测试与线上域名等环境数据是否共用 key。

**缺陷例**：登录态、收藏标记用固定 key，切换账号后仍展示上一个账号的状态；退出登录只清 token，用户数据仍残留，下个账号读到上一个账号的记录；新增字段直接 `jsonDecode` 后强转，旧版本数据缺字段导致崩溃。

**正常反例**：切号时统一清理；读取处给默认值并容错；环境相关值带前缀；纯展示用的缓存允许读到旧值；实际读取使用 `SharedPreferencesAsync`，或缓存读取前已有覆盖外部写入的 `reload`。

依据：[shared_preferences](https://pub.dev/packages/shared_preferences)。未 `await` 不能单独证明读到旧值，已 `await` 也不证明可靠落盘；按 API、平台实现与实际时序判断。旧数据字段缺失导致的解析失败归 F8，同一问题不重复计入本条。

## F8 序列化与模型契约

**框架约束**：`json_serializable` 生成的 `fromJson` 对非空字段做类型强转，字段缺失或类型变化抛 `TypeError`；`.g.dart` 由 `build_runner` 生成，手改会在下次生成时被覆盖。

**核查**：新增或改名字段是否可空、有无默认值；服务端本期可能省略或置空的字段；解析失败是整页失败还是降级；同一响应结构是否在多处重复定义；生成文件是否被手改。

**缺陷例**：服务端开始返回 `null`，客户端字段声明非空，整页解析失败；在 `.g.dart` 里手加字段，重新生成后丢失。

**正常反例**：字段可空并在使用处兜底；解析失败转空态或错误态；生成文件只由工具产出。

依据：[json_serializable](https://pub.dev/packages/json_serializable)、[Dart 类型系统](https://dart.dev/language/type-system)。契约以服务端实际响应为准，不以注释或文档示例推断。

## F9 构建变体与 release 差异

**框架约束**：`Isolate.run` 的函数、结果及 `compute` 在原生平台上的回调、消息和结果须可跨 isolate 发送；闭包可能额外捕获状态，需核对整个捕获对象图是否含不可发送对象。实例方法或捕获 `this` 本身不证明失败，也不证明只在 release/profile 失败。`compute` 在 Web 上运行于当前事件循环。`assert` 在 release 被剥离；代码混淆使 `runtimeType.toString()`、`T.toString()` 这类依赖类型名的值不稳定。

**核查**：实际平台是否创建 isolate，回调、参数、结果及捕获状态是否可发送；业务 key、路由名、持久化字段、埋点是否用类型名而非常量；依赖 `assert` 的校验是否在 release 失效；升级三方库后是否有 debug 与 release 行为不同的分支。

**缺陷例**：原生平台的 isolate 回调捕获持有开放 `ReceivePort` 的实例，发送对象图包含不可发送资源而启动失败；用 `runtimeType.toString()` 作持久化 key，混淆后读不到旧数据。

**正常反例**：主 isolate 先取出纯数据再传入；实例回调所带状态均可发送；常量 key；已在目标平台和运行模式下验证对应路径。debug 跑通不构成 release 可用证据。

依据：[Isolate.run](https://api.dart.dev/stable/dart-isolate/Isolate/run.html)、[compute](https://api.flutter.dev/flutter/foundation/compute.html)、[混淆](https://docs.flutter.dev/deployment/obfuscate)、[assert](https://dart.dev/language/error-handling)。

## F10 图片、资源与解码

**框架约束**：`ImageProvider` 的缓存键由自身参数决定，同一 url 内容变化不会使缓存失效；除非使用 `ResizeImage`，否则按原始尺寸解码；`precacheImage` 与渲染必须命中同一缓存键。

**核查**：头像、封面这类内容会变的资源是否带版本参数；大图是否按实际显示尺寸降采样；列表项是否在 `build` 内新建 `Image` 或重复解码；占位图与错误图是否覆盖空 url 与加载失败。

**缺陷例**：头像 url 不变、没有版本参数，换图后长期显示旧头像；列表直接解码超大原图，滑动抖动——后者需帧率或内存测量支撑。

**正常反例**：服务端按用途返回裁剪尺寸；以版本号参与缓存键；图片侧已降采样并预热，卡顿根因不在解码。

依据：[Image](https://api.flutter.dev/flutter/widgets/Image-class.html)、[ResizeImage](https://api.flutter.dev/flutter/painting/ResizeImage-class.html)、[precacheImage](https://api.flutter.dev/flutter/widgets/precacheImage.html)。

## F11 布局、安全区与适配

**框架约束**：布局遵循“约束向下、尺寸向上、父级定位置”。滚动区和输入框需沿实际父链核对约束，不能仅凭位于 `Column` / `Row` 判错。`Expanded` / `Flexible` 到所属 `Row` / `Column` / `Flex`、`Positioned` 到所属 `Stack` 的路径可经过普通 `StatelessWidget` / `StatefulWidget`，但不能经过不兼容的 RenderObjectWidget。debug 诊断与 release 后果分别核实，断言被移除不保证后续类型转换或布局能成功。`SafeArea` 使用系统安全区并调整后代的 `MediaQuery.padding`；内层 padding 为 0 可能是上层已处理。固定尺寸的溢出依实际约束、字号和文案判断。

**核查**：新增全屏页、自定义顶栏、Drawer、BottomSheet 的安全区由哪层处理，系统 inset 是否真实失效；新增滚动区、输入框的父链是否提供所需约束，ParentDataWidget 到所属布局之间是否插入不兼容的渲染对象；固定宽高是否配合受控文案与 `textScaler`；小屏、平板、横屏、RTL 下是否可达。

**缺陷例**：有设备或平台证据的 Drawer 顶部遮挡；写死高度的按钮在支持字号下文案被裁；非 shrinkWrap 的垂直 `ListView` 从无界高度父链取得约束；`Padding` 插在 `Expanded` 与 `Row` 之间导致 ParentData 不兼容。

**正常反例**：项目已有统一安全区组件或顶栏组件时按其实现；普通 Widget 包装返回 `Expanded` 且中间无其他渲染对象；固定尺寸配单行省略；滚动区外层已由 `Expanded`、`SizedBox` 或 `CustomScrollView` 约束；溢出只在项目不支持的尺寸出现。

依据：[布局约束](https://docs.flutter.dev/ui/layout/constraints)、[常见布局错误](https://docs.flutter.dev/testing/common-errors)、[Expanded](https://api.flutter.dev/flutter/widgets/Expanded-class.html)、[Positioned](https://api.flutter.dev/flutter/widgets/Positioned-class.html)、[SafeArea](https://api.flutter.dev/flutter/widgets/SafeArea-class.html)、[MediaQueryData.padding](https://api.flutter.dev/flutter/widgets/MediaQueryData/padding.html)、[TextScaler](https://api.flutter.dev/flutter/painting/TextScaler-class.html)。具体机型的 inset 异常需对应版本与实际证据，修复方式按项目已有实现判断。

## 性能调查

长列表、大图、频繁 rebuild、主 isolate 工作是线索。先分诊：帧率满格但位移生硬、匀速、突然启停属于曲线与时长问题，改观感即可；真丢帧、低端机更糟才查逐帧重建与解码。`AnimatedBuilder` 的不变子树放 `child` 槽只构建一次，不得在 `builder` 里每帧新建重子树；动画由 `AnimationController` 驱动，不用 `setState` 逐帧。`setState` 重建整个 State 的 subtree，挂在页面级去驱动列表滚动、拖拽、计时这类高频状态时，核对它连带重建的节点和触发频率。大图切换先排除解码（按显示尺寸降采样、预热与渲染同缓存键），再怀疑动画。

性能 Finding 仍按共同规则证明实质影响，核对测量及实际可达的调用路径，不能凭可省一些工作推断低端机卡顿。仅缺 selector、const、RepaintBoundary、DTO 分层、不可变 model、import 排序或 lint info，不达到缺陷门槛。

依据：[Flutter 性能分析](https://docs.flutter.dev/perf/ui-performance)、[AnimatedBuilder](https://api.flutter.dev/flutter/widgets/AnimatedBuilder-class.html)。缺少设备测量是证据缺口，不能写成已确认低端机卡顿；曲线与时长属设计取舍，需给出具体操作序列与观感描述。
