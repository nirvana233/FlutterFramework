import { readFileSync, existsSync, lstatSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
import { canonical, inside, json, MiB, scopePaths, rulesFingerprint } from './review-store.mjs'

const digest = (text) => createHash('sha256').update(text).digest('hex')

// 专项选择由审查 agent 完成；这里只校验并冻结选择，不猜测项目的框架。
export function collectProfiles(skill, repo, selections = []) {
  if (!selections.length) return []
  const index = json(join(skill, 'profiles', 'index.json'))
  if (!Array.isArray(index) || new Set(index.map((item) => item.id)).size !== index.length) {
    throw new Error('专项索引无效或 ID 重复')
  }
  let bytes = 0
  return selections.map((selection) => {
    const entry = index.find((item) => item.id === selection.id)
    if (!entry) throw new Error(`未提供专项：${selection.id}；请记录缺口或选择已提供的专项`)
    const root = join(repo, selection.root)
    if (!existsSync(root) || !lstatSync(root).isDirectory() || !inside(repo, canonical(root))) {
      throw new Error(`专项适用目录无效：${selection.root}`)
    }
    const [file] = scopePaths({ paths: [entry.file] })
    const source = join(skill, 'profiles', file)
    if (!existsSync(source) || !lstatSync(source).isFile() || !inside(join(skill, 'profiles'), canonical(source))) {
      throw new Error(`专项规则文件不可读：${selection.id}`)
    }
    const text = readFileSync(source, 'utf8')
    bytes += Buffer.byteLength(text)
    if (bytes > MiB) throw new Error('专项规则超过 1 MiB；不静默截断')
    return { ...selection, file, appliesTo: entry.appliesTo, text, sha256: digest(text) }
  })
}

// 已有运行只读自己的快照；安装来源不参与复核，也不用于修补缺失的快照。
export function savedProfiles(run, state) {
  if (state.profilesFingerprint === undefined) return []
  try {
    const profiles = json(join(run, 'internal', 'profiles.json'))
    if (!Array.isArray(profiles) || rulesFingerprint(profiles) !== state.profilesFingerprint ||
        profiles.some((item) => typeof item.text !== 'string' || digest(item.text) !== item.sha256)) {
      throw new Error('invalid')
    }
    return profiles
  } catch {
    throw new Error('已保存的专项规则快照缺失或损坏，请重新 prepare；不沿用安装包中的当前规则')
  }
}
