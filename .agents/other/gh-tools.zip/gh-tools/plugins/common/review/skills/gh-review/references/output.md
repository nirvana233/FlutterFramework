# 可选数据与展示接口

仅在用户要求 JSON、统一展示，或需要为交接、复核、留档整理数据时读取。普通初审直接按 SKILL.md 交付，不要求此接口或展示脚本。

脚本为本 Skill 的 scripts/review.mjs，使用 Node.js 22+。展示不调用 Claude、不写缓存或源码。

## 1. 选择交付分支

| 当前结果 | 执行分支 |
|---|---|
| 只交接或复核完全失败 | 使用 [复核步骤](verify.md) 的结束分支 |
| 用户只要 JSON | 初审返回下方接口；裁决返回 [CLI 接口](cli.md) 的 results |
| 用户要求统一展示初审，脚本可用 | 执行第 2 节 |
| 已有有效最终裁决，脚本可用 | 执行第 3 节 |
| 展示脚本不可用或执行被拒 | 按 SKILL.md 聊天交付，说明实际限制 |

两轮模式零 Findings 时说明“没有待复核问题，未调用 Claude”。第二轮以独立 CLI 调用或用户指定的手动复核记录为依据，不据此承诺独立查漏。

初审零问题首行与聊天交付一致：`✅ **No findings**`；复核与裁决完成、全部排除且没有待确认项时是 `✅ **确认 0 项问题**`。复核未完成或仍有待确认项时保留实际状态。只要 JSON 时保持数据接口，不添加展示文字。

## 2. 初审展示

1. 按下方接口整理 JSON，编号使用 CR-001，保留全部独立问题和每项判级。
2. 用结构化参数将 JSON 传入 `node SCRIPT present --input -` 的 stdin；不把模型文字拼进 shell。
3. 输入错误时按错误修正字段后重试，保留全部问题及证据。
4. 交付输出：零问题保留置顶结论，随后展示实际审查的模块或路径；有问题时保留数量和按判级排序的问题，再按 SKILL.md 决定询问、进入已授权复核或结束。缺口只写影响结论的具体未验证行为，不填只读、未改文件、静态检查通过或泛泛的手测说明。

脚本只校验结构，不证明事实或检查漏报。正常项不放入 findings 或 gaps；checks 不展示。
已有输入文件可用 `--input <路径>`，初审不默认创建中间文件。

## 数据接口

```json
{
  "repo": "/absolute/repo",
  "scopeLabel": "账户缓存清理与离线读取（lib/cache.dart）",
  "scope": {"kind": "worktree"},
  "findings": [{
    "id": "CR-001",
    "priority": "P1",
    "title": "切换账户后显示上一账户的数据",
    "location": {"path": "lib/cache.dart", "line": 86},
    "claim": "退出分支没有清理缓存，读取方未按账户隔离。切换账户后可能显示上一账户的数据。",
    "basis": "源码推导：logout 未清理 accountCache，离线读取直接返回 accountCache.value。"
  }],
  "gaps": [],
  "ruleFiles": ["docs/relevant-contract.md"],
  "profiles": [{"id": "flutter", "root": ".", "basis": "pubspec.yaml 声明 Flutter SDK 依赖，目标 SDK 版本依据见锁文件/项目配置。"}]
}
```

- scopeLabel：展示必填，至多 240 字符；写实际审查的模块或路径，不能只写“当前改动”。prepare 不要求此字段。
- findings：必填数组；title 至多 180 字符，claim 和可选 basis 各至多 1200 字符。
- location：仓库相对路径和真实源文件行号；可位于相关的未修改调用方，不以是否位于 diff 判定缺陷。
- origin：可选，使用 [来源接口](origin.md)；未记录时展示“引入未确定”。来源不决定缺陷状态或判级。
- gaps：可选；每项至多 400 字符，写明哪项实际路径的具体判断受阻及缺少什么证据。未发现待判断行为时为空；不为假设消费者、未知需求、没有测试或未做设备手测补缺口。
- checks、ruleFiles、profiles：可选；只在需要复核、交接或留档时保存必要上下文。
- worktree：暂存、未暂存和未跟踪改动；branch：提供 base，按共同祖先比较；range：显式 base/target；snapshot：现有代码快照，无需 diff 或 base，用于功能审查或直接复核历史问题。
- scope.paths：可选的仓库相对路径或目录数组，不支持 glob。
- 字段过长或无效时明确报错；问题数量不限，文本换行会折叠并转义 Markdown 控制符。

## 3. 复核展示

1. 完成裁决后使用 `present --run RUN`。
2. Confirmed 逐项展示，Uncertain 保留逐项缺口，Refuted 只计数。
3. 部分裁决标未完成并退出 1；过期、未裁决或失效结果拒绝展示，按 status 处理。
4. 直接交付有效输出后结束；正常检查记录和长总结留内部。

present 不接受 --apply。成功退出 0，字段或状态错误退出 1，参数错误退出 2。
