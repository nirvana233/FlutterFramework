#!/usr/bin/env node
// 只比较可核对产物，不运行 judge。默认预览；--apply 才建立隔离夹具并调用模型。
import { mkdirSync, writeFileSync, readFileSync, existsSync, mkdtempSync, readdirSync } from 'node:fs'
import { join, resolve, dirname } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { config, claudeArgs, runProcess, resolveClaude, prepare, importResults, complete, status } from './review.mjs'
import { presentReview } from './review-present.mjs'

const skill = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const prompts = JSON.parse(readFileSync(join(skill, 'test-prompts.json'), 'utf8'))
const counterCases = ['review-default', 'review-default-existing-findings', 'review-default-zero',
  'review-only-findings', 'review-and-verify-findings', 'review-prior-authorization', 'review-and-verify-zero']
const counterZeroCases = new Set(['review-default-zero', 'review-and-verify-zero'])
const originCases = ['verify-origin-new', 'verify-origin-existing', 'verify-origin-contract',
  'verify-origin-unknown', 'verify-origin-correction']
const featureCases = ['review-feature-existing', 'review-feature-incremental']
const ids = ['flutter-auto-profile', 'flutter-protected-dart', 'flutter-explicit-exclusion', 'flutter-verify-scope',
  'flutter-lifetime-only', 'flutter-mounted-race', 'flutter-framework-boundaries', 'flutter-external-cache',
  'review-performance-boundary', 'adjudicate-narrowed-finding', 'review-presentation',
  'review-custom-allowed', 'review-custom-omission', ...counterCases,
  'verify-unchanged-location', 'verify-no-findings', 'manual-after-missing-cli', 'review-boundary', 'handoff-only',
  'manual-handoff-rules', 'scoped-review-materials', 'adjudicate-new-counterevidence', 'partial-and-stale', 'resume-final-adjudication',
  'long-material-manual-handoff', 'missing-explicit-rule-handoff', ...originCases, ...featureCases]
const representative = ['flutter-auto-profile', 'review-custom-omission', 'flutter-protected-dart', 'review-performance-boundary']

// --add-dir 也会暴露位置；每臂只取得它自己的规则目录。
export function evaluationRuleDirectories(arm, referenceSkill) {
  if (arm === 'baseline') return []
  if (arm === 'with_skill') return [skill]
  if (arm === 'reference' && referenceSkill) return [dirname(resolve(referenceSkill))]
  throw new Error('未知评测 arm 或缺少 --reference-skill')
}

export function evaluationPrompt(test, root, arm, referenceSkill) {
  const neutral = test.prompt.replaceAll('{{FIXTURE_ROOT}}', root)
  evaluationRuleDirectories(arm, referenceSkill)
  const rule = arm === 'with_skill' ? join(skill, 'SKILL.md') : arm === 'reference' ? resolve(referenceSkill) : null
  return neutral + '\n测试环境：仅可读取本夹具项目文件及本轮明确提供的规则位置；不开放 shell、写入或其他模型调用。不要访问其他评测目录或个人配置。\n' +
    (rule ? `本轮附加规则：先读取 ${rule}，按本次任务应用其中适用的规则。\n` : '')
}

// 把模型给出的裁决接入真实脚本，格式不合法不能仅凭文字正确计为有效产物。
export function validateAdjudicationArtifact(repo, output, answer, caseId = 'adjudicate-narrowed-finding') {
  const blocks = [...answer.matchAll(/^```([^\n]*)\n([\s\S]*?)^```[ \t]*$/gm)]
  const jsonBlocks = blocks.filter((block) => block[1].trim().toLowerCase() === 'json')
  const bareBlocks = blocks.filter((block) => !block[1].trim())
  const candidates = jsonBlocks.length ? jsonBlocks : bareBlocks
  if (candidates.length > 1) throw new Error('多个裁决 JSON 块，无法确定应导入的产物')
  const data = JSON.parse(candidates.length ? candidates[0][2] : answer)
  const originCase = originCases.includes(caseId)
  const input = originCase ? originEvaluationInput(caseId) : { scope: { kind: 'worktree' }, ruleFiles: ['docs/spec.md'], findings: [{
    id: 'CR-001', priority: 'P1', title: '所有输入均返回错误结果', location: { path: 'counter.mjs', line: 2 },
    claim: 'increment 对任何整数都返回 n - 1，主流程普遍失败。',
  }] }
  const prepared = prepare(input, { repo, outputDir: join(output, 'reviews'), apply: true })
  importResults(prepared.run, originCase ? data : { results: [{ id: 'CR-001', status: 'Confirmed',
    evidence: '负数分支返回 n - 1；非负数分支返回 n + 1。' }] }, { apply: true })
  complete(prepared.run, data, { apply: true })
  const final = status(prepared.run)
  writeFileSync(join(output, 'final-status.json'), JSON.stringify(final, null, 2))
  if (originCase) writeFileSync(join(output, 'presented.md'), presentReview(input, final))
  return final
}

function originEvaluationInput(id) {
  const correction = id === 'verify-origin-correction'
  return { scopeLabel: '递增功能与调用方',
    scope: { kind: ['verify-origin-new', 'verify-origin-correction'].includes(id) ? 'worktree' : 'snapshot' },
    ruleFiles: ['docs/spec.md'], findings: [{
      id: 'CR-001', priority: 'P2', title: correction ? '本次修改导致递增出错' : '递增返回错误结果',
      location: { path: 'counter.mjs', line: 2 },
      claim: 'increment(0) 返回 -1，应为 1，caller.mjs 读取错误结果。' + (correction ? '本次修改把加法变成了减法。' : ''),
      ...(correction ? { origin: { kind: 'introduced', basis: '初审认为本次修改引入减法。' } } : {}),
    }] }
}

const pubspec = 'name: mobile\nenvironment:\n  sdk: ">=3.0.0 <4.0.0"\n  flutter: ">=3.10.0"\ndependencies:\n  flutter:\n    sdk: flutter\n'
const safe = `import 'package:flutter/material.dart';
class SafePage extends StatefulWidget {
  const SafePage({super.key});
  @override State<SafePage> createState() => _SafePageState();
}
class _SafePageState extends State<SafePage> {
  int generation = 0;
  String result = '';
  Future<void> refresh() async {
    final ticket = ++generation;
    final value = await Future<String>.delayed(const Duration(milliseconds: 20), () => 'ready');
    if (!mounted || ticket != generation) return;
    setState(() { result = value; });
  }
  @override Widget build(BuildContext context) => TextButton(onPressed: refresh, child: Text(result));
}
`
const bad = `import 'package:flutter/material.dart';
class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override State<SearchPage> createState() => _SearchPageState();
}
class _SearchPageState extends State<SearchPage> {
  String query = '';
  List<String> results = [];
  Future<void> choose(String next) async {
    query = next;
    final data = await Future<List<String>>.delayed(
      Duration(milliseconds: next == 'A' ? 100 : 10), () => [next]);
    setState(() { results = data; });
  }
  @override Widget build(BuildContext context) => Column(children: [
    TextField(onChanged: choose), Text('当前查询: $query'), Text(results.join(',')),
  ]);
}
`
const controller = `class AppStore {
  String value = '';
  Future<void> refresh() async {
    value = await Future<String>.value('ready');
  }
}
`
const detail = `import 'package:flutter/material.dart';
class DetailPage extends StatefulWidget {
  const DetailPage({super.key});
  @override State<DetailPage> createState() => _DetailPageState();
}
class _DetailPageState extends State<DetailPage> {
  bool busy = false;
  String detail = '';
  Future<void> loadDetails() async {
    if (busy) return;
    setState(() { busy = true; });
    await Future<void>.delayed(const Duration(milliseconds: 250));
    setState(() { detail = 'loaded'; busy = false; });
  }
  @override Widget build(BuildContext context) => ElevatedButton(
    onPressed: busy ? null : loadDetails, child: Text(detail));
}
`
const preview = `import 'package:flutter/material.dart';
class PreviewPage extends StatefulWidget {
  const PreviewPage({super.key});
  @override State<PreviewPage> createState() => _PreviewPageState();
}
class _PreviewPageState extends State<PreviewPage> {
  int selected = 0;
  String preview = '';
  Future<void> select(int index) async {
    selected = index;
    final value = await Future<String>.delayed(
      Duration(milliseconds: index == 1 ? 120 : 10), () => 'value-$index');
    if (!mounted) return;
    setState(() { preview = value; });
  }
  @override Widget build(BuildContext context) => Column(children: [
    ElevatedButton(onPressed: () => select(1), child: const Text('1')),
    ElevatedButton(onPressed: () => select(2), child: const Text('2')),
    Text('选择 $selected: $preview'),
  ]);
}
`
const catalog = `class Catalog {
  final List<String> _items;
  Catalog(Iterable<String> items) : _items = List.unmodifiable(items);
  List<String> find(String prefix) {
    final sorted = _items.toList()..sort();
    return sorted.where((value) => value.startsWith(prefix)).toList(growable: false);
  }
}
`

function treeHash(root) {
  const out = {}
  function walk(dir, prefix = '') {
    for (const item of readdirSync(dir, { withFileTypes: true })) {
      if (item.name === '.git') continue
      const path = join(dir, item.name), name = prefix + item.name
      if (item.isDirectory()) walk(path, name + '/')
      else if (item.isFile()) out[name] = createHash('sha256').update(readFileSync(path)).digest('hex')
    }
  }
  walk(root)
  return out
}

export function evaluationFixture(root, id) {
  mkdirSync(root, { recursive: true })
  const put = (path, text) => { mkdirSync(dirname(join(root, path)), { recursive: true }); writeFileSync(join(root, path), text) }
  const git = (...args) => execFileSync('git', args, { cwd: root, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
  git('init', '-q')
  git('config', 'user.name', 'Review Fixture')
  git('config', 'user.email', 'fixture@example.invalid')
  if (['flutter-framework-boundaries', 'flutter-external-cache'].includes(id)) {
    put('AGENTS.md', '源码只读。普通功能输出错误且无数据损失为 P2。按实际支持平台和适用契约审查。\n')
    put('pubspec.yaml', pubspec + '  shared_preferences: 2.5.6\n')
    put('docs/spec.md', id === 'flutter-framework-boundaries'
      ? '本包支持 Android。parseNumber 的 raw 只支持数值为 0..100（含端点）的十进制整数字符串，宿主在调用前完成范围校验，结果须为输入数值加一；OffsetParser 仅由该入口以 offset=1 使用。读取计数时，宿主在同一应用中以默认配置的 SharedPreferencesAsync 实例完成 setInt("counter", value) 后才调用 readPlatformCounter；读写指向同一默认 Android DataStore Preferences 后端及存储文件。UI 使用 Stretch 包装填满 Row 剩余宽度。异常交由宿主处理。\n'
      : '本包支持 Android。CounterReader 在后台原生计数完成后返回最新计数。SharedPreferences 实例由宿主先取得，初始缓存 counter 为 0；原生插件更新同一个 FlutterSharedPreferences 存储后才完成调用。\n')
    git('add', '.')
    git('commit', '-qm', 'baseline contracts')
    if (id === 'flutter-framework-boundaries') {
      put('lib/counter.dart', `import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
class OffsetParser {
  const OffsetParser(this.offset);
  final int offset;
  int parse(String raw) => int.parse(raw) + offset;
}
Future<int> parseNumber(String raw) {
  const parser = OffsetParser(1);
  return compute(parser.parse, raw);
}
Future<int?> readPlatformCounter() => SharedPreferencesAsync().getInt('counter');
`)
      put('lib/stretch.dart', `import 'package:flutter/material.dart';
class Stretch extends StatelessWidget {
  const Stretch({super.key});
  @override Widget build(BuildContext context) => const Expanded(child: Text('count'));
}
class CounterRow extends StatelessWidget {
  const CounterRow({super.key});
  @override Widget build(BuildContext context) => const Row(children: [Stretch()]);
}
`)
    } else {
      put('lib/counter_reader.dart', `import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
class CounterReader {
  CounterReader(this.preferences);
  final SharedPreferences preferences;
  Future<int?> incrementAndRead() async {
    await const MethodChannel('counter').invokeMethod<void>('increment');
    return preferences.getInt('counter');
  }
}
`)
      put('android/app/src/main/kotlin/fixture/MainActivity.kt', `package fixture
import android.content.Context
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
class MainActivity : FlutterActivity() {
  override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)
    MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "counter").setMethodCallHandler { call, result ->
      if (call.method == "increment") {
        val prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
        val next = prefs.getLong("flutter.counter", 0L) + 1L
        if (prefs.edit().putLong("flutter.counter", next).commit()) result.success(null)
        else result.error("write", "write failed", null)
      } else result.notImplemented()
    }
  }
}
`)
    }
    put('review-input.md', '# 当前审查范围\n\n初审新增 lib/ 和 android/（如存在）；契约见 docs/spec.md，依赖见 pubspec.yaml。基线只含契约与依赖，所有新增源码均在本次范围。\n')
    return treeHash(root)
  }
  if (originCases.includes(id) || featureCases.includes(id)) {
    const unknown = id === 'verify-origin-unknown'
    const introduced = id === 'verify-origin-new'
    const contract = id === 'verify-origin-contract'
    put('AGENTS.md', '源码只读。普通输出错误且无数据损失为 P2。依据适用契约审查。\n')
    put('docs/spec.md', contract
      ? '兼容旧接口：increment 名称保持不变，实际表示倒计时下一值，必须返回 n - 1。caller.mjs 的合法输入 0 应得到 -1；这是当前适用需求。\n'
      : 'increment 对任意整数 n 必须返回 n + 1。caller.mjs 的合法输入 0 应得到 1。\n')
    put('counter.mjs', `export function increment(n) {\n  return n ${introduced ? '+' : '-'} 1\n}\n`)
    put('caller.mjs', 'import { increment } from "./counter.mjs"\nexport const value = increment(0)\n')
    const initial = originCases.includes(id) ? '\n待复核初审：\n' + JSON.stringify(originEvaluationInput(id).findings[0]) + '\n' : ''
    const task = '# 代码版本与审查材料\n\n读取 AGENTS.md、docs/spec.md、counter.mjs 及实际调用方 caller.mjs。\n' + initial
    if (unknown) put('review-input.md', task + '\n提供的是当前唯一根提交的快照，无父版本和比较基线，也没有更早来源材料。\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    if (unknown) return treeHash(root)
    const base = git('rev-parse', 'HEAD').trim()
    const history = `\n以下历史材料由控制器从本仓库 Git 读取：\n基线提交：${base}\n提交日期：${git('show', '-s', '--format=%cs', base).trim()}\n` +
      '\n基线 counter.mjs：\n```js\n' + git('show', `${base}:counter.mjs`) + '```\n' +
      '\n基线 caller.mjs：\n```js\n' + git('show', `${base}:caller.mjs`) + '```\n'
    if (introduced) put('counter.mjs', 'export function increment(n) {\n  return n - 1\n}\n')
    else if (['verify-origin-correction', 'review-feature-incremental'].includes(id)) {
      put('counter.mjs', 'export function increment(n) {\n  return n - 1 // retained behavior\n}\n')
    }
    put('review-input.md', task + history + '\n当前 counter.mjs 相对基线的真实 diff：\n```diff\n' +
      git('diff', base, '--', 'counter.mjs') + '```\n')
    if (['review-feature-existing', 'verify-origin-existing', 'verify-origin-contract'].includes(id)) {
      // 只有材料被添加到新提交，现有功能没有变化；交付给模型的是干净 checkout。
      git('add', '.'); git('commit', '-qm', 'record version materials')
    }
    return treeHash(root)
  }
  if (counterCases.includes(id)) {
    put('AGENTS.md', '源码只读。普通输入输出回归且无数据损失为 P2。\n')
    put('docs/spec.md', 'increment 对任意整数 n 返回 n + 1；caller.mjs 直接读取 increment(0)，应为 1。\n')
    put('counter.mjs', 'export function increment(n) {\n  return n + 1 // baseline\n}\n')
    put('caller.mjs', 'import { increment } from "./counter.mjs"\nexport const value = increment(0)\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('counter.mjs', counterZeroCases.has(id)
      ? 'export function increment(n) {\n  return n + 1\n}\n'
      : 'export function increment(n) {\n  return n - 1\n}\n')
    put('review-input.md', '# 当前审查范围\n\n读取 AGENTS.md、docs/spec.md、实现及调用方。\n' +
      '以下为真实 Git 范围与基线 diff；未跟踪文件列于状态中。\n\n' +
      git('status', '--short') + '\n```diff\n' + git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  if (id === 'adjudicate-narrowed-finding') {
    put('AGENTS.md', '源码只读。P1 表示主流程普遍失败；只影响负数输入且无数据损失的普通回归为 P2。\n')
    put('docs/spec.md', 'increment 对任意整数 n 返回 n + 1，负数也是支持的输入。\n')
    put('counter.mjs', 'export function increment(n) {\n  return n + 1\n}\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('counter.mjs', 'export function increment(n) {\n  return n >= 0 ? n + 1 : n - 1\n}\n')
    put('review-input.md', '# 已有审查材料\n\n范围：counter.mjs 当前未提交改动。读取 AGENTS.md、docs/spec.md 和源码。\n\n' +
      '初审 CR-001 [P1] counter.mjs:2，标题：所有输入均返回错误结果。claim：increment 对任何整数都返回 n - 1，主流程普遍失败。\n' +
      '已有复核：Confirmed，但证据仅支持负数分支错误；非负数分支返回 n + 1。请自行核对这一收窄结论。\n\n```diff\n' +
      git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  if (id === 'review-custom-allowed' || id === 'review-custom-omission') {
    put('AGENTS.md', '源码只读。根据本次明确需求和实际调用方审查；普通业务契约遗漏为 P2。\n')
    if (id === 'review-custom-allowed') {
      put('docs/spec.md', 'ExportQueue 是进程级导出队列。每次 submit 都是独立任务，结果按实际完成顺序累计到 records，所有提交的结果均须保留。A、B 是合法名称，允许并行任务乱序完成，不采用最近提交覆盖旧任务的语义。runBatch 在所有任务完成后读取 records。\n')
      put('export-queue.mjs', 'export class ExportQueue {\n  records = []\n  async submit(name) {\n    const result = name + "-file"\n    this.records.push({ name, result })\n    return result\n  }\n}\n')
      put('batch.mjs', 'import { ExportQueue } from "./export-queue.mjs"\nexport async function runBatch() {\n  const queue = new ExportQueue()\n  await Promise.all([queue.submit("A"), queue.submit("B")])\n  return queue.records\n}\n')
      git('add', '.'); git('commit', '-qm', 'fixture baseline')
      put('export-queue.mjs', 'export class ExportQueue {\n  records = []\n  async submit(name) {\n    await new Promise(resolve => setTimeout(resolve, name === "A" ? 40 : 5))\n    const result = name + "-file"\n    this.records.push({ name, result })\n    return result\n  }\n}\n')
    } else {
      put('docs/spec.md', 'selectItems 提供 live 模式：只显示 enabled 为 true 的条目，按 priority 数字从高到低排列；不按字母序排序。\n')
      put('selection.mjs', 'export function selectItems(rows) {\n  return rows.filter(row => row.enabled).sort((a, b) => b.priority - a.priority)\n}\n')
      put('items.mjs', 'export const items = [\n  { id: "A", enabled: true, priority: 1 },\n  { id: "B", enabled: false, priority: 9 },\n  { id: "C", enabled: true, priority: 4 },\n]\n')
      git('add', '.'); git('commit', '-qm', 'fixture baseline')
      put('docs/spec.md', '本次新增 preview 模式，保留既有 live 模式。live 只显示 enabled 为 true 的条目；preview 必须显示全部条目，包括 enabled 为 false 的条目。两种模式均按 priority 数字从高到低排列，不按字母序。preview.mjs 是本次预览入口，应展示 B、C、A。\n')
      put('selection.mjs', 'export function selectItems(rows, mode = "live") {\n  return rows.filter(row => row.enabled).sort((a, b) => b.priority - a.priority)\n}\n')
      put('preview.mjs', 'import { selectItems } from "./selection.mjs"\nimport { items } from "./items.mjs"\nexport const previewItems = selectItems(items, "preview")\n')
    }
    put('review-input.md', '# 当前审查范围\n\n项目规则和需求位于 AGENTS.md、docs/spec.md。以下为真实 Git 范围与基线 diff；未跟踪文件列于状态中。\n\n' +
      git('status', '--short') + '\n```diff\n' + git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  if (id === 'verify-unchanged-location') {
    put('AGENTS.md', '源码只读。空集合用 []，不用 null；消费者按数组契约调用。\n')
    put('docs/spec.md', 'producer 产出条目数组；loadVisible 接收数组并过滤 visible。\n')
    put('legacy/reader.mjs', 'export function loadVisible(items) {\n  return items.filter(item => item.visible)\n}\n')
    put('producer.mjs', 'export function produce() {\n  return []\n}\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('producer.mjs', 'export function produce() {\n  return null\n}\n')
    put('review-input.md', '# 审查范围\n\n只审 producer.mjs 本次未提交改动。范围限定 producer.mjs。\n\n' +
      git('status', '--short') + '\n```diff\n' + git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  if (id === 'verify-no-findings') {
    put('AGENTS.md', '源码只读。普通输入输出回归且无数据损失为 P2。\n')
    put('docs/spec.md', 'increment 对任意整数 n 返回 n + 1。\n')
    put('counter.mjs', 'export function increment(n) {\n  return n + 1 // baseline\n}\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('counter.mjs', 'export function increment(n) {\n  return n + 1\n}\n')
    put('review-input.md', '# 审查范围\n\n本次只删除注释，无行为变化。范围 counter.mjs。\n\n' +
      git('status', '--short') + '\n```diff\n' + git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  if (['manual-after-missing-cli', 'handoff-only', 'missing-explicit-rule-handoff'].includes(id)) {
    put('AGENTS.md', '源码只读。普通输入输出回归且无数据损失为 P2。\n')
    put('docs/spec.md', 'increment 对任意整数 n 返回 n + 1；caller.mjs 直接读取 increment(0)，应为 1。\n')
    put('counter.mjs', 'export function increment(n) {\n  return n + 1 // baseline\n}\n')
    put('caller.mjs', 'import { increment } from "./counter.mjs"\nexport const value = increment(0)\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('counter.mjs', 'export function increment(n) {\n  return n - 1\n}\n')
    const extra = id === 'manual-after-missing-cli'
      ? '\n初审结论 CR-001 [P1] counter.mjs:2：increment(0) 从 1 变为 -1。请逐条复核。Claude 路径指定 {{FIXTURE_ROOT}}/missing-claude。\n'
      : id === 'handoff-only'
        ? '\n只交接已有结论 CR-001 [P1] counter.mjs:2：increment(0) 从 1 变为 -1。不重新初审。\n'
        : '\n只交接已有结论 CR-001 [P1] counter.mjs:2。显式需求文件为 docs/missing-spec.md（不存在）。不重新初审。\n'
    put('review-input.md', '# 审查范围\n\n范围 counter.mjs 未提交改动。' + extra + '\n```diff\n' + git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  if (id === 'review-boundary') {
    put('docs/spec.md', '')
    put('lib/counter.mjs', 'export function increment(n) {\n  return n + 1\n}\n')
    put('lib/guarded.mjs', 'export function isReady(flag) {\n  if (!flag) return false\n  return true\n}\n')
    put('lib/names.mjs', 'export const items = []\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('lib/counter.mjs', 'export function increment(n) {\n  return n - 1\n}\n')
    put('lib/guarded.mjs', 'export function isReady(flag) {\n  if (!flag) return false\n  return true\n}\n')
    put('lib/names.mjs', 'export const items = [] // renamed from list\n')
    put('review-input.md', '# 审查范围\n\n当前未提交改动；需求未提供。\n\n' +
      git('status', '--short') + '\n```diff\n' + git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  if (id === 'manual-handoff-rules') {
    put('AGENTS.md', '源码只读。倒计时功能允许 decrement。\n')
    put('docs/spec.md', 'countdown 从 n 递减到 0；允许 decrement 操作。\n')
    put('counter.mjs', 'export function countdown(n) {\n  return n\n}\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('counter.mjs', 'export function countdown(n) {\n  return n - 1\n}\n')
    const prepared = prepare({
      scope: { kind: 'worktree' }, ruleFiles: ['docs/spec.md'],
      findings: [{ id: 'CR-001', priority: 'P1', title: 'countdown 返回值错误',
        location: { path: 'counter.mjs', line: 2 },
        claim: 'countdown 返回 n-1 而非 n，违反契约。' }],
    }, { repo: root, outputDir: join(root + '-reviews'), apply: true })
    importResults(prepared.run, { results: [{ id: 'CR-001', status: 'Confirmed',
      evidence: 'counter.mjs:2 返回 n-1。' }] }, { apply: true })
    put('review-input.md', '# 审查范围\n\n只手动复核已有交接。\n\n```diff\n' + git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  if (id === 'scoped-review-materials') {
    put('AGENTS.md', '源码只读。生产者产出数组；消费者用 filter。\n')
    put('docs/spec.md', 'producer 返回数组；loadVisible 用 filter 过滤。\n')
    put('legacy/AGENTS.md', 'legacy 代码只读；调用方约束见此。\n')
    put('legacy/reader.mjs', 'export function loadVisible(items, role) {\n  if (role === "admin") {\n    return (items || []).filter(item => item.visible)\n  }\n  return items.filter(item => item.visible)\n}\n')
    put('producer.mjs', 'export function produce() {\n  return []\n}\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('producer.mjs', 'export function produce() {\n  return null\n}\n')
    const prepared = prepare({
      scope: { kind: 'worktree' }, ruleFiles: ['docs/spec.md', 'legacy/AGENTS.md'],
      findings: [{ id: 'CR-001', priority: 'P1', title: 'producer 返回 null 导致 loadVisible 抛错',
        location: { path: 'legacy/reader.mjs', line: 5 },
        claim: 'producer 本次返回 null，public 路径调用 items.filter 抛 TypeError。' },
        { id: 'CR-002', priority: 'P2', title: '次要问题占位',
          location: { path: 'producer.mjs', line: 2 },
          claim: '次要问题，不应在 scoped 复核中处理。' }],
    }, { repo: root, outputDir: join(root + '-reviews'), apply: true })
    writeFileSync(root + '-request.txt',
      `复核请求：只复核 CR-001。运行目录：${prepared.run}\n` +
      `材料索引：${join(prepared.run, 'internal', 'materials.json')}\n` +
      `共享规则：${join(prepared.run, 'internal', 'review-rules.md')}\n` +
      `项目规则：${join(prepared.run, 'internal', 'project-rules.json')}\n`)
    return treeHash(root)
  }
  if (id === 'adjudicate-new-counterevidence') {
    put('AGENTS.md', '源码只读。生产者产出数组；消费者用 filter。\n')
    put('docs/spec.md', 'producer 返回数组；loadVisible 用 filter 过滤。\n')
    put('legacy/reader.mjs', 'export function loadVisible(items, role) {\n  if (role === "admin") {\n    return (items || []).filter(item => item.visible)\n  }\n  return items.filter(item => item.visible)\n}\n')
    put('producer.mjs', 'export function produce() {\n  return []\n}\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('producer.mjs', 'export function produce() {\n  return null\n}\n')
    const prepared = prepare({
      scope: { kind: 'worktree' }, ruleFiles: ['docs/spec.md'],
      findings: [{ id: 'CR-001', priority: 'P1', title: 'producer 返回 null 导致 loadVisible 抛错',
        location: { path: 'legacy/reader.mjs', line: 5 },
        claim: 'producer 本次返回 null，public 路径调用 items.filter 抛 TypeError。' }],
    }, { repo: root, outputDir: join(root + '-reviews'), apply: true })
    importResults(prepared.run, { results: [{ id: 'CR-001', status: 'Refuted',
      evidence: 'reader 有空值保护，问题不存在。' }] }, { apply: true })
    put('review-input.md', '# 审查范围\n\n请只裁决已有运行。初审认为 producer 返回 null 导致 public 路径抛错；Claude 返回 Refuted，声称 reader 的空值保护已排除问题。\n\n```diff\n' + git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  if (id === 'partial-and-stale') {
    put('AGENTS.md', '源码只读。普通输入输出回归且无数据损失为 P2。\n')
    put('docs/spec.md', 'increment 对任意整数 n 返回 n + 1。\n')
    put('counter.mjs', 'export function increment(n) {\n  return n + 1\n}\n')
    put('caller.mjs', 'import { increment } from "./counter.mjs"\nexport const value = increment(0)\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('counter.mjs', 'export function increment(n) {\n  return n - 1\n}\n')
    put('caller.mjs', 'import { increment } from "./counter.mjs"\nexport const value = increment(0)\n')
    const prepared = prepare({
      scope: { kind: 'worktree' }, ruleFiles: ['docs/spec.md'],
      findings: [
        { id: 'CR-001', priority: 'P1', title: 'increment 返回 n-1',
          location: { path: 'counter.mjs', line: 2 },
          claim: 'increment(0) 返回 -1，应为 1。' },
        { id: 'CR-002', priority: 'P2', title: 'caller 未处理异常',
          location: { path: 'caller.mjs', line: 2 },
          claim: 'caller 未捕获 increment 异常。' }],
    }, { repo: root, outputDir: join(root + '-reviews'), apply: true })
    importResults(prepared.run, { results: [{ id: 'CR-001', status: 'Confirmed',
      evidence: 'counter.mjs:2 返回 -1。' }] }, { apply: true })
    put('counter.mjs', 'export function increment(n) {\n  return n - 2\n}\n')
    put('review-input.md', '# 审查范围\n\n请检查已有运行状态。所有编号需有去向；如果代码已变化，保留材料并说明不能沿用旧裁决。\n\n```diff\n' + git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  if (id === 'resume-final-adjudication') {
    put('AGENTS.md', '源码只读。普通输入输出回归且无数据损失为 P2。\n')
    put('docs/spec.md', 'increment 对任意整数 n 返回 n + 1。\n')
    put('counter.mjs', 'export function increment(n) {\n  return n + 1\n}\n')
    put('caller.mjs', 'import { increment } from "./counter.mjs"\nexport const value = increment(0)\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('counter.mjs', 'export function increment(n) {\n  return n - 1\n}\n')
    const prepared = prepare({
      scope: { kind: 'worktree' }, ruleFiles: ['docs/spec.md'],
      findings: [{ id: 'CR-001', priority: 'P1', title: 'increment 返回 n-1',
        location: { path: 'counter.mjs', line: 2 },
        claim: 'increment(0) 返回 -1，应为 1。' }],
    }, { repo: root, outputDir: join(root + '-reviews'), apply: true })
    importResults(prepared.run, { results: [{ id: 'CR-001', status: 'Refuted',
      evidence: 'counter.mjs:2 返回 -1，但不影响主流程。' }] }, { apply: true })
    complete(prepared.run, { results: [{ id: 'CR-001', status: 'Confirmed',
      evidence: 'counter.mjs:2 返回 -1，caller.mjs 实际读取此值，契约明确应为 1。' }] }, { apply: true })
    put('review-input.md', '# 审查范围\n\n请读取已有运行的当前 status，并据其已有结果给简洁结论。不要重新裁决、调用其他模型或写文件。\n\n```diff\n' + git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  if (id === 'long-material-manual-handoff') {
    put('AGENTS.md', '源码只读。倒计时功能允许 decrement。\n')
    put('docs/spec.md', 'countdown 从 n 递减到 0；允许 decrement 操作。负数调用仍须递增到 0。\n')
    put('counter.mjs', 'export function countdown(n) {\n  return n\n}\n')
    git('add', '.'); git('commit', '-qm', 'fixture baseline')
    put('counter.mjs', 'export function countdown(n) {\n  return n - 1\n}\n')
    const prepared = prepare({
      scope: { kind: 'worktree' }, ruleFiles: ['docs/spec.md'],
      findings: [{ id: 'CR-001', priority: 'P1', title: 'countdown 返回值错误',
        location: { path: 'counter.mjs', line: 2 },
        claim: 'countdown 返回 n-1 而非 n。' }],
      checks: ['检查日志：'.repeat(10000)],
      gaps: ['诊断详情：'.repeat(10000)],
    }, { repo: root, outputDir: join(root + '-reviews'), apply: true })
    put('review-input.md', '# 审查范围\n\n只手动复核已有交接。材料较长，请按索引读取。\n\n```diff\n' + git('diff', 'HEAD') + '\n```\n')
    return treeHash(root)
  }
  put('AGENTS.md', '源码只读。按本次变化和真实调用链审查，不要求特定状态管理。AppStore 与 Worker 生命周期等于 app/进程，不属于 Widget State。\n')
  const onlyCatalog = id === 'review-performance-boundary'
  const extraSpec = id === 'flutter-lifetime-only'
    ? 'DetailPage 只接受一个任务，busy 时按钮禁用；任务不会失败且结果固定为 loaded。用户可随时返回，不得更新已销毁的 UI。\n'
    : id === 'flutter-mounted-race'
      ? 'PreviewPage 支持连续切换 1/2，必须展示当前 selected 对应的 preview；不同选择可能乱序完成。页面退出后底层任务可继续，但不得更新已销毁的 UI。\n' : ''
  put('docs/spec.md', onlyCatalog
    ? 'Catalog 构造时冻结传入词库，此后该实例没有任何数据更新；每次 find 按字典序返回前缀匹配。sample_queries.dart 的同一实例进行 4 次查询，本次增加排序满足结果顺序要求。没有运行时耗时/内存数据。\n'
    : 'SearchPage 必须显示当前查询的结果，用户可随时离开页面；A/B 可能乱序完成。SafePage 在页面离开后允许底层 Future 继续，但不得更新销毁后的 UI。AppStore/Worker 是 app/进程级后台状态，无页面生命周期限制。没有 selector、const 或不可变模型要求。\n' + extraSpec)
  put('packages/worker/pubspec.yaml', 'name: worker\nenvironment:\n  sdk: ">=3.0.0 <4.0.0"\n')
  put('packages/worker/lib/worker.dart', 'class Worker { String value = ""; }\n')
  if (onlyCatalog) {
    put('packages/catalog/pubspec.yaml', 'name: catalog\nenvironment:\n  sdk: ">=3.0.0 <4.0.0"\n')
    put('packages/catalog/lib/catalog.dart', catalog.replace('final sorted = _items.toList()..sort();', 'final sorted = _items;'))
    put('packages/catalog/lib/sample_queries.dart', "import 'catalog.dart';\nvoid main() {\n  final catalog = Catalog(List.generate(3000, (index) => (3000 - index).toString().padLeft(4, '0')));\n  for (final prefix in ['0', '00', '000', '0001']) {\n    catalog.find(prefix);\n  }\n}\n")
  } else {
    put('apps/mobile/pubspec.yaml', pubspec)
    put('apps/mobile/lib/safe_page.dart', safe.replace('final ticket = ++generation;', 'final ticket = ++generation; // baseline'))
    put('apps/mobile/lib/search_page.dart', bad.replace(/final data = await Future<List<String>>\.delayed\([\s\S]*?\(\) => \[next\]\);/, 'final data = [next];'))
    if (id === 'flutter-lifetime-only') put('apps/mobile/lib/detail_page.dart', detail.replace('    await Future<void>.delayed(const Duration(milliseconds: 250));\n', ''))
    if (id === 'flutter-mounted-race') put('apps/mobile/lib/preview_page.dart', preview.replace(/final value = await Future<String>\.delayed\([\s\S]*?\(\) => 'value-\$index'\);/, "final value = 'value-$index';"))
  }
  git('add', '.')
  git('commit', '-qm', 'fixture baseline')
  if (onlyCatalog) put('packages/catalog/lib/catalog.dart', catalog)
  else {
    put('apps/mobile/lib/safe_page.dart', safe)
    git('add', 'apps/mobile/lib/safe_page.dart')
    put('apps/mobile/lib/app_store.dart', controller)
    if (id === 'flutter-lifetime-only') put('apps/mobile/lib/detail_page.dart', detail)
    else if (id === 'flutter-mounted-race') put('apps/mobile/lib/preview_page.dart', preview)
    else if (!['flutter-protected-dart', 'review-presentation'].includes(id)) put('apps/mobile/lib/search_page.dart', bad)
  }
  put('packages/worker/lib/worker.dart', controller.replace('AppStore', 'Worker'))
  const changed = git('status', '--short')
  const diff = git('diff', 'HEAD')
  const extra = id === 'flutter-verify-scope'
    ? '\n待复核：CR-001 [P1] apps/mobile/lib/safe_page.dart:13，原初审认为新 refresh 在页面退出后会 setState，缺少生命周期保护。只核查此编号；不要新增其它问题。\n' : ''
  put('review-input.md', '# 当前审查范围\n\n项目规则和需求位于 AGENTS.md、docs/spec.md。以下为真实 Git 范围与基线 diff；未跟踪文件列于状态中。\n\n' + changed + '\n```diff\n' + diff + '\n```\n' + extra)
  return treeHash(root)
}

// 控制器执行自建虚拟代码，记录预先已知的契约结果；不把结果提示给审查模型。
export async function evaluationOracle(root, id) {
  if (['flutter-framework-boundaries', 'flutter-external-cache'].includes(id)) {
    return { kind: 'source-established', runtimeExecuted: false,
      knownFindings: id === 'flutter-external-cache' ? [{ path: 'lib/counter_reader.dart', line: 8,
        trigger: '缓存初值 0；原生将同一 key 更新为 1；未 reload 的 legacy getter 仍返回 0。' }] : [],
      boundary: 'Flutter、Android 与插件未实际执行；按实际 API 和源码核对，不能声称实机通过。' }
  }
  if (originCases.includes(id) || featureCases.includes(id)) {
    const { increment } = await import(pathToFileURL(join(root, 'counter.mjs')))
    const git = (...args) => execFileSync('git', args, { cwd: root, encoding: 'utf8' }).trim()
    return { actual: increment(0), expected: id === 'verify-origin-contract' ? -1 : 1,
      expectedStatus: id === 'verify-origin-contract' ? 'Refuted' : 'Confirmed',
      expectedOrigin: id === 'verify-origin-new' ? 'introduced' : id === 'verify-origin-unknown' ? 'unknown' : 'pre-existing',
      expectedInitialFindings: id === 'review-feature-incremental' ? 0 : 1,
      head: git('rev-parse', 'HEAD'), history: git('log', '--format=%H %cs %s'),
      workingDiff: git('diff', 'HEAD'), runtimeExecuted: true }
  }
  if (counterCases.includes(id)) {
    const { increment } = await import(pathToFileURL(join(root, 'counter.mjs')))
    const { value } = await import(pathToFileURL(join(root, 'caller.mjs')))
    return { zero: increment(0), negative: increment(-2), caller: value, expectedZero: 1, expectedNegative: -1 }
  }
  if (id === 'review-custom-allowed') {
    const { runBatch } = await import(pathToFileURL(join(root, 'batch.mjs')))
    return { records: await runBatch(), expectedNames: ['B', 'A'] }
  }
  if (id === 'review-custom-omission') {
    const { selectItems } = await import(pathToFileURL(join(root, 'selection.mjs')))
    const { items } = await import(pathToFileURL(join(root, 'items.mjs')))
    return { live: selectItems(items, 'live').map(item => item.id),
      preview: selectItems(items, 'preview').map(item => item.id), expectedPreview: ['B', 'C', 'A'] }
  }
  if (['flutter-auto-profile', 'flutter-protected-dart', 'review-performance-boundary'].includes(id)) {
    const path = 'apps/mobile/lib/search_page.dart'
    const line = id === 'flutter-auto-profile'
      ? readFileSync(join(root, path), 'utf8').split('\n').findIndex(text => text.includes('setState(()')) + 1 : null
    return { kind: 'source-established', runtimeExecuted: false,
      knownFindings: id === 'flutter-auto-profile' ? [
        { path, line, trigger: '请求完成前离开页面，已销毁 State 仍被 setState。' },
        { path, line, trigger: '先输入 A 后输入 B；B 先完成，A 后完成并覆盖当前 B 结果。' },
      ] : [],
      boundary: 'Flutter/Dart 未实际执行；已知契约与源码提供人工核查依据，不自动评分。' }
  }
}

export function evaluationOptions(argv) {
  const values = {}, cases = []
  const allowed = ['--case', '--output-dir', '--reference-skill', '--repeat', '--model', '--effort', '--timeout-ms', '--max-budget-usd', '--cli']
  for (let i = 0; i < argv.length; i++) {
    const flag = argv[i]
    if (flag === '--apply') { values.apply = true; continue }
    if (!allowed.includes(flag)) throw new Error(`未知参数：${flag}`)
    const value = argv[++i]
    if (!value || value.startsWith('--')) throw new Error(`${flag} 缺少值`)
    if (flag === '--case') cases.push(...value.split(','))
    else {
      if (values[flag] !== undefined) throw new Error(`重复参数：${flag}`)
      values[flag] = value
    }
  }
  const selected = cases.length ? [...new Set(cases.flatMap(id => id === 'all' ? ids : [id]))] : representative
  if (selected.some(id => !ids.includes(id))) throw new Error('未知评测 case')
  const repeat = Number(values['--repeat'] ?? 1)
  if (!Number.isInteger(repeat) || repeat < 1 || repeat > 100) throw new Error('--repeat 需为 1–100 的整数')
  const settings = config({ model: values['--model'], effort: values['--effort'],
    timeoutMs: Number(values['--timeout-ms'] ?? 240000), cli: values['--cli'] })
  const maxBudgetUsd = values['--max-budget-usd'] === undefined ? null : Number(values['--max-budget-usd'])
  if (maxBudgetUsd !== null && (!Number.isFinite(maxBudgetUsd) || maxBudgetUsd <= 0)) throw new Error('--max-budget-usd 需为正数')
  const referenceSkill = values['--reference-skill'] ? resolve(values['--reference-skill']) : null
  if (referenceSkill) readFileSync(referenceSkill, 'utf8') // 预览同样核实指定来源可读；不复制入正式 skills。
  return { apply: values.apply === true, cases: selected, repeat, settings, maxBudgetUsd, referenceSkill,
    arms: referenceSkill ? ['baseline', 'reference', 'with_skill'] : ['baseline', 'with_skill'],
    output: values['--output-dir'] ? resolve(values['--output-dir']) : null }
}

export async function main(argv, dependencies = {}) {
  const options = evaluationOptions(argv)
  const { apply, cases: selected, arms, repeat, settings, maxBudgetUsd, referenceSkill } = options
  const parameters = { model: settings.model ?? null, effort: settings.effort, timeoutMs: settings.timeoutMs, maxBudgetUsd,
    tools: ['Read', 'Glob', 'Grep'], safeMode: true }
  const sources = { baseline: null, with_skill: { path: skill, files: treeHash(skill) },
    ...(referenceSkill ? { reference: { path: referenceSkill, sha256: createHash('sha256').update(readFileSync(referenceSkill)).digest('hex') } } : {}) }
  const plan = { cases: selected, arms, repeat, calls: selected.length * arms.length * repeat, ...parameters, sources }
  if (!apply) { console.log(JSON.stringify({ dryRun: true, ...plan })); return }
  const output = options.output || mkdtempSync(join(tmpdir(), 'review-profile-results-'))
  if (existsSync(output) && readdirSync(output).length) throw new Error('评测产物目录必须为空，避免覆盖已有结果')
  mkdirSync(output, { recursive: true })
  const cli = (dependencies.resolveCli || resolveClaude)(settings.cli)
  writeFileSync(join(output, 'manifest.json'), JSON.stringify({ ...plan, cli,
    boundary: 'CLI safe-mode 隔离个人规则；各臂只读且无 shell。工具权限不是 OS 沙箱；无 LLM judge，产物与 oracle 由人核对。' }, null, 2))
  console.log(JSON.stringify({ output, cases: selected }))
  for (let repetition = 1; repetition <= repeat; repetition++) for (const id of selected) {
    const test = prompts.find((test) => test.id === id)
    for (const arm of arms) {
      // 调用目录与产物目录分离；随机夹具路径不向模型泄露臂身份或其他规则来源。
      const root = mkdtempSync(join(tmpdir(), 'review-fixture-'))
      const before = evaluationFixture(root, id)
      const oracle = await evaluationOracle(root, id)
      const neutral = test.prompt.replaceAll('{{FIXTURE_ROOT}}', root)
      const prompt = evaluationPrompt(test, root, arm, referenceSkill)
      const args = claudeArgs(settings)
      if (id === 'review-presentation') {
        args[args.indexOf('--json-schema') + 1] = JSON.stringify({
          type: 'object', additionalProperties: false, required: ['scopeLabel', 'scope', 'findings', 'gaps'],
          properties: {
            scopeLabel: { type: 'string' }, scope: { type: 'object', properties: { kind: { const: 'worktree' } }, required: ['kind'], additionalProperties: false },
            findings: { type: 'array', items: { type: 'object', additionalProperties: false,
              required: ['id', 'priority', 'title', 'claim', 'location'], properties: {
                id: { type: 'string', pattern: '^CR-[0-9]{3,}$' }, priority: { enum: ['P0', 'P1', 'P2', 'P3'] },
                title: { type: 'string' }, claim: { type: 'string' }, basis: { type: 'string' },
                location: { type: 'object', additionalProperties: false, required: ['path', 'line'], properties: { path: { type: 'string' }, line: { type: 'integer', minimum: 1 } } },
              } } },
            gaps: { type: 'array', items: { type: 'string' } }, checks: { type: 'array', items: { type: 'string' } },
          },
        })
      } else args.splice(args.indexOf('--json-schema'), 2)
      if (maxBudgetUsd !== null) args.push('--max-budget-usd', String(maxBudgetUsd))
      args.push('--add-dir', root)
      for (const dir of evaluationRuleDirectories(arm, referenceSkill)) args.push('--add-dir', dir)
      const result = await (dependencies.run || runProcess)(cli, args, { input: prompt, cwd: root, timeoutMs: settings.timeoutMs })
      const path = join(output, `${id}-${arm}-${repetition}`)
      mkdirSync(path)
      if (oracle) writeFileSync(join(path, 'oracle.json'), JSON.stringify(oracle, null, 2))
      writeFileSync(join(path, 'stdout.json'), result.stdout)
      writeFileSync(join(path, 'stderr.txt'), result.stderr)
      let answer = '', parseError, structured, reportedModels = []
      try {
        const raw = JSON.parse(result.stdout)
        const envelope = Array.isArray(raw) ? raw.findLast((item) => item.type === 'result') : raw
        answer = envelope.result || ''
        structured = envelope.structured_output
        reportedModels = Object.keys(envelope.modelUsage || {})
        if (envelope.is_error) parseError = '模型返回 is_error'
      } catch (error) { parseError = error.message }
      writeFileSync(join(path, 'answer.md'), answer)
      if (id === 'review-presentation' && result.code === 0 && !result.failure && !parseError) {
        try {
          if (!structured) throw new Error('缺少 CLI structured_output')
          const data = structured
          writeFileSync(join(path, 'presentation-input.json'), JSON.stringify(data, null, 2))
          writeFileSync(join(path, 'presented.md'), presentReview(data))
        } catch (error) { parseError = `展示产物无效：${error.message}` }
      }
      if ((id === 'adjudicate-narrowed-finding' || originCases.includes(id)) && result.code === 0 && !result.failure && !parseError) {
        try { validateAdjudicationArtifact(root, path, answer, id) }
        catch (error) { parseError = `裁决产物无法导入：${error.message}` }
      }
      const after = treeHash(root)
      const state = { case: id, arm, repetition, fixture: root, prompt: neutral, requestPrompt: prompt, expected: test.expected,
        parameters, args, reportedModels,
        code: result.code, failure: result.failure || parseError || null, sourceUnchanged: JSON.stringify(before) === JSON.stringify(after), before, after }
      writeFileSync(join(path, 'state.json'), JSON.stringify(state, null, 2))
      console.log(JSON.stringify({ case: id, arm, repetition, reportedModels, code: state.code, failure: state.failure, sourceUnchanged: state.sourceUnchanged, artifact: path }))
      if (state.code !== 0 || state.failure || !state.sourceUnchanged) process.exitCode = 1
    }
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main(process.argv.slice(2)).catch((error) => { console.error(error.message); process.exitCode = 1 })
}
