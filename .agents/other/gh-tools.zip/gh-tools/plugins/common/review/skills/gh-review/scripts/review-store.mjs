import {
  existsSync, lstatSync, mkdirSync, openSync, closeSync, writeFileSync,
  readFileSync, readdirSync, renameSync, rmSync, realpathSync, readSync, readlinkSync,
} from 'node:fs'
import { homedir, hostname } from 'node:os'
import { basename, dirname, join, resolve, relative, isAbsolute, posix, win32 } from 'node:path'
import { createHash, randomBytes } from 'node:crypto'
import { execFileSync } from 'node:child_process'

export const TOOL = 'gh-review'
export const MiB = 1024 * 1024
export const MAX_BYTES = 500 * MiB
export const LOG_BYTES = 10 * MiB
export const originSchema = {
  type: 'object', additionalProperties: false, required: ['kind', 'basis'],
  properties: { kind: { enum: ['introduced', 'pre-existing', 'unknown'] }, basis: { type: 'string', minLength: 1, maxLength: 1200 },
    commit: { type: 'string', pattern: '^[0-9a-fA-F]{7,64}$' }, date: { type: 'string', pattern: '^\\d{4}-\\d{2}-\\d{2}$' } },
}

export function validateOrigin(origin) {
  if (origin === undefined) return undefined
  if (!origin || typeof origin !== 'object' || Array.isArray(origin) ||
      Object.keys(origin).some(key => !Object.keys(originSchema.properties).includes(key)) ||
      !originSchema.properties.kind.enum.includes(origin.kind) || typeof origin.basis !== 'string' ||
      !origin.basis.trim() || origin.basis.length > 1200 ||
      (origin.commit !== undefined && (typeof origin.commit !== 'string' || !/^[0-9a-fA-F]{7,64}$/.test(origin.commit))) ||
      (origin.date !== undefined && (typeof origin.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(origin.date) ||
        !Number.isFinite(Date.parse(origin.date)) || new Date(origin.date).toISOString().slice(0, 10) !== origin.date))) {
    throw new Error('origin 需要 kind、非空 basis（至多 1200 字符），可选有效 commit 和 YYYY-MM-DD date')
  }
  return { ...origin }
}

export function originText(origin) {
  validateOrigin(origin)
  if (!origin) return '来源：引入未确定。'
  const label = { introduced: '本次引入', 'pre-existing': '历史已存在', unknown: '引入未确定' }[origin.kind]
  return `来源：${label}；${origin.basis}` + (origin.commit ? `；提交 ${origin.commit}` : '') +
    (origin.date ? `；日期 ${origin.date}` : '')
}
const DAY = 86400000
const RUN_NAME = /^\d{8}T\d{6}Z-[a-f0-9]{6}$/
const REPO_NAME = /^[\w.-]+-[a-f0-9]{10}$/

export function defaultRoot(platform = process.platform, env = process.env, home = homedir()) {
  const p = platform === 'win32' ? win32 : posix
  const base = platform === 'win32' ? (env.LOCALAPPDATA || p.join(home, 'AppData', 'Local'))
    : platform === 'darwin' ? p.join(home, 'Library', 'Caches')
      : (env.XDG_CACHE_HOME && p.isAbsolute(env.XDG_CACHE_HOME) ? env.XDG_CACHE_HOME : p.join(home, '.cache'))
  return p.join(base, 'gh-tools', 'reviews')
}

export function canonical(path) {
  let parent = resolve(path)
  const suffix = []
  while (!existsSync(parent)) {
    suffix.unshift(basename(parent))
    const next = dirname(parent)
    if (next === parent) throw new Error(`路径无法解析：${path}`)
    parent = next
  }
  return join(realpathSync(parent), ...suffix)
}

export function inside(root, path) {
  const rel = relative(root, path)
  return rel === '' || (!isAbsolute(rel) && rel !== '..' && !rel.startsWith(`..${process.platform === 'win32' ? '\\' : '/'}`))
}

export function plainTree(path) {
  const stat = lstatSync(path)
  if (stat.isSymbolicLink()) throw new Error(`管理目录含链接，拒绝操作：${path}`)
  if (stat.isDirectory()) return readdirSync(path).reduce((n, file) => n + plainTree(join(path, file)), 0)
  if (!stat.isFile()) throw new Error(`管理目录含特殊文件：${path}`)
  return stat.size
}

function bytesWithoutFollowingLinks(path) {
  const stat = lstatSync(path)
  return stat.isDirectory() && !stat.isSymbolicLink()
    ? readdirSync(path).reduce((n, name) => n + bytesWithoutFollowingLinks(join(path, name)), 0)
    : stat.size
}

export function json(path) { return JSON.parse(readFileSync(path, 'utf8')) }

export function atomic(path, data) {
  const temp = `${path}.${randomBytes(6).toString('hex')}.tmp`
  try {
    writeFileSync(temp, typeof data === 'string' ? data : `${JSON.stringify(data, null, 2)}\n`, { mode: 0o600, flag: 'wx' })
    renameSync(temp, path)
  } finally {
    if (existsSync(temp)) rmSync(temp)
  }
}

function alive(lock, now) {
  if (!lock || !Number.isInteger(lock.pid) || typeof lock.until !== 'number') return true
  if (lock.host !== hostname()) return lock.until > now
  try { process.kill(lock.pid, 0); return true } catch (error) { return error.code !== 'ESRCH' }
}

export function locked(path, now = Date.now()) {
  if (!existsSync(path)) return false
  try { return alive(json(path), now) } catch { return true }
}

export function acquire(path, reserve = 0, ttl = 60000) {
  if (existsSync(path)) {
    if (locked(path)) throw new Error('另一个运行正在使用该目录，请稍后重试')
    if (lstatSync(path).isSymbolicLink()) throw new Error('锁文件不能是链接')
    rmSync(path)
  }
  const token = randomBytes(12).toString('hex')
  const fd = openSync(path, 'wx', 0o600)
  try { writeFileSync(fd, JSON.stringify({ pid: process.pid, host: hostname(), token, until: Date.now() + ttl, reserve })) }
  finally { closeSync(fd) }
  return () => {
    if (existsSync(path) && json(path).token === token) rmSync(path)
  }
}

export function rootLock(root) {
  mkdirSync(root, { recursive: true, mode: 0o700 })
  return acquire(join(root, '.cleanup-lock'))
}

export function loadRun(run) {
  // 不先 realpath(run)：否则传入的 junction 会失去可检测的边界。
  run = resolve(run)
  if (!RUN_NAME.test(basename(run)) || !REPO_NAME.test(basename(dirname(run)))) throw new Error('不是有效运行目录')
  const root = canonical(dirname(dirname(run)))
  if (join(root, basename(dirname(run)), basename(run)) !== run) throw new Error('运行目录路径不匹配')
  if (lstatSync(dirname(run)).isSymbolicLink()) throw new Error('仓库管理目录不能是链接')
  plainTree(run)
  const state = json(join(run, 'internal', 'state.json'))
  if (state.tool !== TOOL || state.schema !== 1 || state.root !== root || state.run !== run ||
      !Number.isFinite(Date.parse(state.createdAt)) || !Number.isFinite(Date.parse(state.lastActivity))) {
    throw new Error('运行元数据无效，拒绝修改或删除')
  }
  return { run, root, state }
}

export function saveState(run, state) {
  state.lastActivity = new Date().toISOString()
  atomic(join(run, 'internal', 'state.json'), state)
}

export function recover(run, state, persist = true) {
  if (['preparing', 'verifying'].includes(state.status) && !locked(join(run, '.lock'))) {
    state.status = 'interrupted'
    state.diagnostic = '上次进程已退出，复核中断；可手动接手或显式重试'
    if (persist) saveState(run, state)
  }
}

export function clean(root, { apply = false, protect = [], reserve = 0, maxBytes = MAX_BYTES, now = Date.now() } = {}) {
  root = canonical(root)
  if (!existsSync(root)) return { removed: [], bytes: 0 }
  const records = []
  for (const repo of readdirSync(root)) {
    const repoPath = join(root, repo)
    if (!REPO_NAME.test(repo) || !lstatSync(repoPath).isDirectory() || lstatSync(repoPath).isSymbolicLink()) continue
    for (const name of readdirSync(repoPath)) {
      if (!RUN_NAME.test(name)) continue
      const run = join(repoPath, name)
      try {
        const { state } = loadRun(run)
        const active = locked(join(run, '.lock'), now)
        const pinned = active || protect.includes(run)
        let reserved = 0
        if (active) {
          const value = json(join(run, '.lock')).reserve
          reserved = Number.isFinite(value) && value > 0 ? value : 0
        }
        if (apply && !active) recover(run, state)
        records.push({ run, state, bytes: plainTree(run), pinned, reserved })
      } catch { /* 未知、损坏或含链接的目录不删除。 */ }
    }
  }
  // 未知/损坏目录不删除，但其真实占用也计入容量，避免不可清理的积累绕过上限。
  let bytes = bytesWithoutFollowingLinks(root) + records.reduce((n, item) => n + item.reserved, 0)
  const removed = []
  function remove(item) {
    removed.push(item.run)
    bytes -= item.bytes
    if (apply) rmSync(item.run, { recursive: true })
  }
  const candidates = records.filter((item) => !item.pinned)
  for (const item of candidates) {
    const expiry = item.state.status === 'completed' ? 7 * DAY : 30 * DAY
    if (now - Date.parse(item.state.lastActivity) > expiry) remove(item)
  }
  candidates.sort((a, b) => {
    const completed = (a.state.status === 'completed' ? 0 : 1) - (b.state.status === 'completed' ? 0 : 1)
    return completed || Date.parse(a.state.lastActivity) - Date.parse(b.state.lastActivity)
  })
  for (const item of candidates) {
    if (bytes + reserve <= maxBytes) break
    if (!removed.includes(item.run)) remove(item)
  }
  if (bytes + reserve > maxBytes) throw new Error('活跃或当前产物占满容量；停止新增，已有交接保留')
  return { removed, bytes }
}

export function git(repo, args, buffer = false) {
  return execFileSync('git', ['--no-optional-locks', '-c', 'core.fsmonitor=false', ...args], {
    cwd: repo, encoding: buffer ? undefined : 'utf8', maxBuffer: 64 * MiB,
    env: { ...process.env, GIT_OPTIONAL_LOCKS: '0', GIT_LITERAL_PATHSPECS: '1' },
    stdio: ['ignore', 'pipe', 'pipe'],
  })
}

export function hashFile(path) {
  const hash = createHash('sha256')
  const fd = openSync(path, 'r')
  const buffer = Buffer.alloc(64 * 1024)
  try {
    let bytes
    while ((bytes = readSync(fd, buffer, 0, buffer.length, null))) hash.update(buffer.subarray(0, bytes))
    return hash.digest('hex')
  } finally { closeSync(fd) }
}

export function rulesFingerprint(rules) {
  return createHash('sha256').update(JSON.stringify(rules)).digest('hex')
}

function validPath(path) {
  if (typeof path !== 'string' || !path || path.includes('\0') || path.includes('\\') ||
      isAbsolute(path) || path.split('/').includes('..') || path.startsWith('-')) throw new Error(`需要仓库相对路径：${path}`)
  return posix.normalize(path).replace(/\/$/, '') || '.'
}

export function scopePaths(scope) {
  if (scope.paths === undefined) return []
  if (!Array.isArray(scope.paths) || !scope.paths.length) throw new Error('paths 必须是非空相对路径数组')
  return scope.paths.map(validPath)
}

function ref(repo, value) {
  if (typeof value !== 'string' || !value || value.startsWith('-')) throw new Error('需要有效 Git ref')
  return git(repo, ['rev-parse', '--verify', `${value}^{commit}`]).trim()
}

export function resolveScope(repo, scope) {
  const paths = scopePaths(scope)
  scope = { ...scope, ...(scope.paths ? { paths } : {}) }
  const head = ref(repo, 'HEAD')
  if (scope.kind === 'worktree') return { ...scope, head, base: head }
  if (scope.kind === 'snapshot') {
    if (scope.base !== undefined) throw new Error('snapshot 不使用比较基线 base')
    const target = scope.target === undefined ? undefined : ref(repo, scope.target)
    if (target && target !== head) throw new Error('请在目标提交对应的 checkout 中复核；当前 HEAD 与 target 不同')
    return { ...scope, head, ...(target ? { target } : {}) }
  }
  if (!['branch', 'range'].includes(scope.kind)) throw new Error('scope.kind 必须为 worktree / branch / range / snapshot')
  const target = ref(repo, scope.target || 'HEAD')
  let base
  try { base = ref(repo, scope.base) } catch (error) {
    if (scope.kind !== 'branch') throw error
    base = ref(repo, `${scope.base}@{upstream}`)
  }
  if (scope.kind === 'branch') {
    try {
      const upstream = ref(repo, `${scope.base}@{upstream}`)
      git(repo, ['merge-base', '--is-ancestor', base, upstream])
      base = upstream
    } catch { /* 无 upstream 或分叉时沿用本地基线。 */ }
    base = git(repo, ['merge-base', base, target]).trim()
  }
  if (head !== target) throw new Error('请在目标提交对应的 checkout 中复核；当前 HEAD 与 target 不同')
  return { ...scope, head, base, target }
}

export function snapshot(repo, scope) {
  const head = ref(repo, 'HEAD')
  const args = ['diff', '--no-ext-diff', '--no-textconv', '--binary']
  const paths = scopePaths(scope)
  const staged = git(repo, [...args, '--cached', 'HEAD', '--'], true)
  const unstaged = git(repo, [...args, '--'], true)
  const untracked = git(repo, ['ls-files', '--others', '--exclude-standard', '-z'], true).toString().split('\0').filter(Boolean)
  const working = createHash('sha256').update(staged).update(unstaged)
  const newFiles = []
  for (const path of untracked.sort()) {
    const full = join(repo, path)
    const stat = lstatSync(full)
    // 用 Git 读取 symlink blob 不适用于未跟踪链接；不跟随链接读取仓库外内容。
    if (stat.isSymbolicLink()) throw new Error(`未跟踪链接无法作为稳定复核输入：${path}`)
    if (!stat.isFile()) throw new Error(`未跟踪特殊文件：${path}`)
    const hash = hashFile(full)
    working.update(`${path}\0${hash}\0`)
    newFiles.push({ path, sha256: hash, bytes: stat.size })
  }
  if ((['branch', 'range'].includes(scope.kind) || (scope.kind === 'snapshot' && scope.target)) && (staged.length || unstaged.length || newFiles.length)) {
    throw new Error('提交范围需要干净 checkout；请使用 worktree 范围或独立 checkout')
  }
  const diffArgs = scope.kind === 'worktree' ? [scope.base] : [scope.base, scope.target]
  const diff = scope.kind === 'snapshot' ? Buffer.alloc(0) : git(repo, [...args, ...diffArgs, '--', ...paths], true)
  const changed = (scope.kind === 'snapshot'
    ? git(repo, ['ls-files', '-z', '--', ...paths], true)
    : git(repo, ['diff', '--no-ext-diff', '--no-textconv', '--name-only', '-z', ...diffArgs, '--', ...paths], true))
    .toString().split('\0').filter(Boolean)
  const selectedNew = newFiles.filter(({ path }) => !paths.length || paths.some((p) => p === '.' || path === p || path.startsWith(`${p}/`)))
  const files = [...new Set([...changed, ...selectedNew.map((f) => f.path)])].sort()
  const workingDigest = working.digest('hex')
  const fingerprint = createHash('sha256').update(JSON.stringify({ head, scope, workingDigest })).update(diff).digest('hex')
  const stagedPaths = git(repo, ['diff', '--no-ext-diff', '--no-textconv', '--cached', '--name-only', '-z', 'HEAD', '--'], true)
  const unstagedPaths = git(repo, ['diff', '--no-ext-diff', '--no-textconv', '--name-only', '-z', '--'], true)
  const workingPaths = [...new Set([...stagedPaths.toString().split('\0'), ...unstagedPaths.toString().split('\0'), ...untracked])].filter(Boolean).sort()
  const workingFiles = workingPaths.map((path) => {
    const full = join(repo, path)
    if (!existsSync(full)) return { path, deleted: true }
    const stat = lstatSync(full)
    if (stat.isSymbolicLink()) return { path, symlink: readlinkSync(full) }
    return stat.isFile() ? { path, sha256: hashFile(full) } : { path, type: 'directory' }
  })
  return { head, scope, fingerprint, workingDigest, files, workingFiles, newFiles: selectedNew, diff }
}

export function validateInput(input) {
  if (!input || !input.scope || !Array.isArray(input.findings)) throw new Error('需要 scope 和 findings 数组')
  scopePaths(input.scope)
  const ids = new Set()
  for (const finding of input.findings) {
    if (!/^CR-\d{3,}$/.test(finding.id) || ids.has(finding.id)) throw new Error('Finding 编号必须唯一，如 CR-001')
    ids.add(finding.id)
    if (!/^P[0-3]$/.test(finding.priority)) throw new Error('priority 必须为 P0–P3')
    for (const key of ['title', 'claim']) {
      if (typeof finding[key] !== 'string' || !finding[key].trim()) throw new Error(`Finding 缺少 ${key}`)
    }
    validPath(finding.location?.path)
    if (!Number.isInteger(finding.location?.line) || finding.location.line < 1) throw new Error('需要有效行号')
    if (finding.basis !== undefined && typeof finding.basis !== 'string') throw new Error('basis 必须为字符串')
    validateOrigin(finding.origin)
  }
  for (const key of ['checks', 'gaps', 'ruleFiles']) {
    if (input[key] !== undefined && (!Array.isArray(input[key]) || input[key].some((v) => typeof v !== 'string'))) {
      throw new Error(`${key} 必须为字符串数组`)
    }
  }
  let profiles
  if (input.profiles !== undefined) {
    if (!Array.isArray(input.profiles)) throw new Error('profiles 必须为数组')
    const selected = new Set()
    profiles = input.profiles.map((profile) => {
      if (!profile || typeof profile.id !== 'string' || !/^[a-z][a-z0-9-]*$/.test(profile.id) ||
          typeof profile.basis !== 'string' || !profile.basis.trim()) {
        throw new Error('专项需要有效 id、root 和非空 basis 选择依据')
      }
      const root = validPath(profile.root)
      const key = `${profile.id}\0${root}`
      if (selected.has(key)) throw new Error('同一适用目录的专项不能重复')
      selected.add(key)
      return { id: profile.id, root, basis: profile.basis }
    })
  }
  return { ...input, ...(profiles !== undefined ? { profiles } : {}), findings: input.findings.map((finding) => ({ ...finding,
    location: { ...finding.location, path: validPath(finding.location.path) },
  })) }
}

export function collectRules(repo, files, explicit = []) {
  const candidates = new Set()
  const required = new Set(explicit.map((path) => join(repo, validPath(path))))
  for (const path of ['', ...files.map(dirname)]) {
    let dir = resolve(repo, path)
    while (inside(repo, dir)) {
      for (const name of ['AGENTS.md', 'CLAUDE.md', 'CODING_STANDARDS.md', 'CONTRIBUTING.md']) candidates.add(join(dir, name))
      if (dir === repo) break
      dir = dirname(dir)
    }
  }
  // ancestor AGENTS 也可能约束整个 checkout。
  let parent = dirname(repo)
  while (true) {
    candidates.add(join(parent, 'AGENTS.md'))
    if (dirname(parent) === parent) break
    parent = dirname(parent)
  }
  for (const path of required) candidates.add(path)
  const rules = []
  let bytes = 0
  for (const path of candidates) {
    const missing = !existsSync(path) ? '文件不存在' : !lstatSync(path).isFile() ? '不是普通文件' : null
    if (missing) {
      if (required.has(path)) rules.push({ path, missing })
      continue
    }
    const text = readFileSync(path, 'utf8')
    bytes += Buffer.byteLength(text)
    if (bytes > MiB) throw new Error('项目规则超过 1 MiB，请缩小范围或整理显式规则；不静默截断')
    rules.push({ path, text })
  }
  return rules
}

export function makeRun(root, repo, now = new Date()) {
  const hash = createHash('sha256').update(repo).digest('hex').slice(0, 10)
  const label = basename(repo).replace(/[^\w.-]/g, '-').slice(0, 48) || 'repo'
  const time = now.toISOString().slice(0, 19).replace(/[-:]/g, '') + 'Z'
  const group = join(root, `${label}-${hash}`)
  if (existsSync(group) && lstatSync(group).isSymbolicLink()) throw new Error('仓库缓存目录不能是链接')
  return join(group, `${time}-${randomBytes(3).toString('hex')}`)
}
