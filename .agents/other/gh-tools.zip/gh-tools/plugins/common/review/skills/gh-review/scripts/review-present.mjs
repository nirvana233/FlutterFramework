import { validateInput, originText } from './review-store.mjs'

function line(value, name, max = 1200) {
  if (typeof value !== 'string' || !value.trim() || value.length > max) throw new Error(`${name} 需要非空文字，至多 ${max} 字符`)
  return value.trim().replace(/\s+/g, ' ').replace(/[\\`*_{}\[\]<>#!|]/g, '\\$&')
}

// 只决定展示结构；不会证明模型提供的事实、判级或缺口真实。
export function presentReview(input, final = null) {
  const payload = validateInput(input)
  const scope = line(input.scopeLabel, 'scopeLabel', 240)
  const gaps = (payload.gaps || []).map((gap) => line(gap, 'gap', 400))
  let items, summary
  if (final) {
    if (final.resultSource !== 'final' || !['completed', 'partial'].includes(final.status)) {
      throw new Error('没有当前有效最终裁决；请按 status 处理未完成或过期状态')
    }
    items = final.results.filter((r) => r.status !== 'Refuted').map((r) => ({
      ...r.finding, id: r.id, status: r.status, basis: r.evidence, origin: r.origin || r.finding?.origin,
    }))
    validateInput({ scope: input.scope, findings: items })
    const count = (s) => final.results.filter((r) => r.status === s).length
    summary = `已审查：${scope}。${final.status === 'partial' ? '复核或裁决未完成；' : ''}确认 ${count('Confirmed')} 项，排除 ${count('Refuted')} 项，待确认 ${count('Uncertain')} 项。`
  } else {
    items = payload.findings
    summary = `已审查：${scope}。` + (items.length ? `发现 ${items.length} 项问题。` : '')
  }
  const body = [...items].sort((a, b) => a.priority.localeCompare(b.priority)).map((f) => {
    const title = line(f.title, 'title', 180)
    const location = `${line(f.location.path, 'path', 500)}:${f.location.line}`
    const evidence = f.basis?.trim() ? ` ${line(f.basis, 'basis')}` : ''
    const detail = f.status === 'Uncertain' ? line(f.basis, 'Uncertain evidence') : line(f.claim, 'claim') + evidence
    return `- ${f.id} [${f.priority}]${f.status === 'Uncertain' ? ' 待确认' : ''} ${title} — ${location}。${detail} ${line(originText(f.origin), 'origin', 1500)}`
  })
  const boundary = gaps.length ? `未验证：${gaps.join('；')}。` : ''
  if (!items.length && (!final || final.status === 'completed')) {
    return `✅ **${final ? '确认 0 项问题' : 'No findings'}**\n\n` + summary + (boundary ? '\n\n' + boundary : '') + '\n'
  }
  return body.length ? [summary, body.join('\n'), boundary].filter(Boolean).join('\n\n') + '\n'
    : summary + (boundary ? ' ' + boundary : '') + '\n'
}
