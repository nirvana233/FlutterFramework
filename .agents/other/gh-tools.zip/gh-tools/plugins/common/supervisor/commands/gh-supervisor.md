---
description: gh-supervisor · AI 监工
argument-hint: "[要完成的任务或需要纠偏的行为]"
---

按下列 Skill 正文处理请求。其中的相对引用以
`${CLAUDE_PLUGIN_ROOT}/skills/gh-supervisor/` 为基准解析：

@${CLAUDE_PLUGIN_ROOT}/skills/gh-supervisor/SKILL.md

用户请求：

$ARGUMENTS
