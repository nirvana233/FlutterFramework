# 行为实测

`test-prompts.json` 按 id 对应 `test-fixtures.json` 中的“相对路径 → 原始内容”。每个用例从自己的原始夹具开始，替换 prompt 中的 `{{FIXTURE_ROOT}}` 后运行。

`reuse-valid-evidence` 和 `handoff-with-review-pressure` 需要在原始夹具中先真实运行 `node --test`。退出 0 后生成 `verified.txt`，保存命令、退出状态、完整输出，以及 `src/options.mjs` 和 `test/options.test.mjs` 的 SHA-256。把同一份源码、测试与验证记录复制给两组，避免用编造的通过记录测试证据复用。

`project-default-loading` 另将仓库当前的 `AGENTS.md`、`CLAUDE.md` 和本 Skill 正文按原相对路径复制到两组夹具。加载组保留 `AGENTS.md` 的默认加载要求；baseline 只移除其中“默认行为准则”这一节，其他内容和 `CLAUDE.md` 指针相同。用同一条普通任务提示词运行，不额外点名 Skill，从读取轨迹确认项目入口实际生效。项目规则和 Skill 正文直接复制当前源文件，不在夹具清单中维护副本。

其他用例的加载组显式读取本目录的 `SKILL.md`；baseline 仅排除目标 Skill 及其副本。两组保持相同的模型、推理、工具权限和辅助 Skill 访问范围。保存实际提示词、运行配置、命令轨迹、原始与最终文件、退出状态和最终回复；确认加载组读取正文，baseline 未读取目标或副本。运行记录放在夹具外。

重点比对以下产物：

- `rewrite-meaning`：审批、时间、样本和推广限制是否保留，多余范围辩护是否删除。
- `implementation-with-speculative-design`：实际实现与新增机制、测试运行及结果，设计讨论和用户笔记是否保留。
- `handoff-with-review-pressure`：是否发现新缺口、执行了哪些检查、是否重复测试或额外创建证明文件。
- `release-note-with-defensive-draft`：哪些辩护被删除，事实、来源、上线条件和负责人需要作出的决定是否保留。
- `focused-build-diagnosis`：是否修复真正阻塞验收的关闭逻辑，定向读取构建诊断并保留错误证据，完成测试后停止；比较实际输出行数、命令、修改范围与设备旁支调查；允许同步更新因修复而失效的 README 描述，不用回复字数判断收益。
- `project-default-loading`：普通任务是否经项目规则加载正文，提示词中是否没有额外调用要求。

其他用例继续核对局部修复、真实保护、只读边界和关键澄清。独立复跑修复用例的 `node --test` 可核对产物，但不计入被测执行者的检查次数。

直接核对内容和文件变化，不用 LLM judge 打分。两组表现相近时如实记录；单次差异只能支持该次观察，不能证明长期稳定收益。
