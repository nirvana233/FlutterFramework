import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'

const script = fileURLToPath(new URL('./workflow-state.mjs', import.meta.url))
function fixture(fn) {
  const root = mkdtempSync(join(tmpdir(), 'gh-workflow-'))
  const directory = join(root, 'existing-project-tasks', 'email')
  const run = (...args) => spawnSync(process.execPath, [script, ...args], { encoding: 'utf8', cwd: root })
  const command = (name, ...args) => run(name, '--task', directory, ...args)
  const state = () => JSON.parse(readFileSync(join(directory, 'progress.json'), 'utf8'))
  const init = () => {
    const result = command('init', '--goal', 'trim 邮箱', '--steps', 'trim,verify', '--apply')
    assert.equal(result.status, 0, result.stderr)
  }
  try { fn({ root, directory, run, command, state, init }) }
  finally { rmSync(root, { recursive: true, force: true }) }
}

test('init 默认预览，不创建任务目录', () => fixture(({ command, directory }) => {
  const result = command('init', '--goal', 'trim 邮箱', '--steps', 'trim,verify')
  assert.equal(result.status, 0, result.stderr)
  assert.match(result.stdout, /dry-run/)
  assert.equal(existsSync(directory), false)
}))

test('自定义任务目录只生成两份记录，工作项由任务决定', () => fixture(({ init, state, directory, command }) => {
  init()
  assert.deepEqual(readdirSync(directory).sort(), ['progress.json', 'task.md'])
  assert.deepEqual(state().steps.map(step => step.id), ['trim', 'verify'])
  assert.equal(state().status, 'in_progress')
  assert.equal(command('check').status, 0)
}))

test('两种模式默认覆盖全部阶段，未完成审阅不能提前通过', () => {
  for (const mode of ['guided', 'full-auto']) fixture(({ command, state, directory }) => {
    const result = command('init', '--goal', '完成可核查任务', '--mode', mode, '--apply')
    assert.equal(result.status, 0, result.stderr)
    assert.equal(state().execution_mode, mode)
    assert.deepEqual(state().steps.map(step => step.id), ['requirements', 'plan', 'build', 'verify', 'review', 'ship', 'archive'])
    const before = readFileSync(join(directory, 'progress.json'), 'utf8')
    const skipped = command('set-step', '--step', 'ship', '--status', 'passed', '--evidence', '交付说明已保存', '--apply')
    assert.equal(skipped.status, 1)
    assert.match(skipped.stderr, /Prior stages are unfinished/)
    assert.equal(readFileSync(join(directory, 'progress.json'), 'utf8'), before)
    for (const step of state().steps.slice(0, 4)) {
      assert.equal(command('set-step', '--step', step.id, '--status', 'passed', '--evidence', `${step.id}: 已核对对应结果`, '--apply').status, 0)
    }
    assert.equal(state().status, 'in_progress')
    assert.equal(command('set-step', '--step', 'ship', '--status', 'passed', '--evidence', '交付说明已保存', '--apply').status, 1)
    assert.equal(command('set-step', '--step', 'review', '--status', 'passed', '--evidence', '最终改动审阅：无未处理阻断问题', '--apply').status, 0)
    assert.equal(state().status, 'in_progress')
    for (const step of ['ship', 'archive']) {
      assert.equal(command('set-step', '--step', step, '--status', 'passed', '--evidence', `${step}: 已核对对应结果`, '--apply').status, 0)
    }
    assert.equal(state().status, 'passed')
  })
})

test('阶段例外保留评估与授权，未完成前置项和整体状态保持真实', () => fixture(({ command, state }) => {
  assert.equal(command('init', '--goal', '先交付独立部分', '--apply').status, 0)
  const result = command('set-step', '--step', 'ship', '--status', 'passed', '--evidence', '已交付可独立部分，验收仍未完成',
    '--exception', 'task.md#例外：先交付独立部分，设备验证延期，取得设备后恢复，风险已列明',
    '--authorization', '用户明确批准本次部分交付，见当前会话决定', '--apply')
  assert.equal(result.status, 0, result.stderr)
  const ship = state().steps.find(step => step.id === 'ship')
  assert.deepEqual(ship.exception.pending_stages, ['requirements', 'plan', 'build', 'verify', 'review'])
  assert.match(ship.exception.assessment, /取得设备后恢复/)
  assert.match(ship.exception.authorization, /用户明确批准/)
  assert.equal(state().status, 'in_progress')
  assert.equal(state().steps.find(step => step.id === 'verify').status, 'pending')
  assert.equal(command('check').status, 0)
  assert.deepEqual(state().history.at(-1).exception, ship.exception)
  assert.equal(command('set-step', '--step', 'ship', '--status', 'in_progress', '--note', '交付内容变化', '--apply').status, 0)
  assert.equal(state().steps.find(step => step.id === 'ship').exception, undefined)
  assert.deepEqual(state().history.at(-1).previous.exception, ship.exception)
}))

test('缺少评估或授权的例外不落盘，普通备注不能绕过前置阶段', () => fixture(({ command, directory }) => {
  assert.equal(command('init', '--goal', '核对例外边界', '--apply').status, 0)
  const file = join(directory, 'progress.json')
  const before = readFileSync(file, 'utf8')
  for (const extra of [
    ['--exception', '风险已列明'], ['--authorization', '用户已同意'],
    ['--exception', ' ', '--authorization', '用户已同意'], ['--note', '全自动直接继续'],
  ]) {
    assert.equal(command('set-step', '--step', 'ship', '--status', 'passed', '--evidence', '部分交付', ...extra, '--apply').status, 1)
    assert.equal(readFileSync(file, 'utf8'), before)
  }
  assert.equal(command('set-step', '--step', 'ship', '--status', 'pending', '--exception', '已评估', '--authorization', '用户授权', '--apply').status, 1)
  assert.equal(readFileSync(file, 'utf8'), before)
}))

test('手动跳过前置阶段时 check 拒绝，完整例外可保留部分交付', () => fixture(({ command, state, directory }) => {
  assert.equal(command('init', '--goal', '核对手动记录', '--apply').status, 0)
  const file = join(directory, 'progress.json')
  const manual = state()
  const ship = manual.steps.find(step => step.id === 'ship')
  Object.assign(ship, { status: 'passed', evidence: '可独立部分已交付' })
  writeFileSync(file, JSON.stringify(manual))
  const before = readFileSync(file, 'utf8')
  const invalid = command('check')
  assert.equal(invalid.status, 1)
  assert.match(invalid.stderr, /ship.*requirements/)
  assert.equal(command('set-step', '--step', 'build', '--status', 'in_progress', '--apply').status, 1)
  assert.equal(readFileSync(file, 'utf8'), before)
  ship.exception = { assessment: '设备验证延期，风险及恢复办法见 task.md', authorization: '用户已批准部分交付', pending_stages: ['review'] }
  writeFileSync(file, JSON.stringify(manual))
  assert.equal(command('check').status, 1)
  ship.exception.pending_stages = ['requirements', 'plan', 'build', 'verify', 'review']
  writeFileSync(file, JSON.stringify(manual))
  assert.equal(command('check').status, 0)
  assert.equal(state().status, 'in_progress')
}))

test('前置阶段后来重开时保留有效后续完成项，更新仍可接续', () => fixture(({ command, state }) => {
  assert.equal(command('init', '--goal', '核对阶段恢复', '--apply').status, 0)
  for (const step of state().steps) {
    assert.equal(command('set-step', '--step', step.id, '--status', 'passed', '--evidence', `${step.id}: 本次结果`, '--apply').status, 0)
  }
  assert.equal(command('set-step', '--step', 'verify', '--status', 'in_progress', '--note', '环境变化，需要复测', '--apply').status, 0)
  assert.equal(command('check').status, 0)
  assert.equal(state().status, 'in_progress')
  assert.equal(state().steps.find(step => step.id === 'ship').evidence, 'ship: 本次结果')
  assert.equal(command('set-step', '--step', 'verify', '--status', 'blocked', '--note', '等待设备', '--apply').status, 0)
  assert.equal(command('check').status, 0)
  assert.equal(command('set-step', '--step', 'verify', '--status', 'passed', '--evidence', '设备复测通过', '--apply').status, 0)
  assert.equal(state().status, 'passed')
}))

test('后续阶段自身重开后，旧完成历史不能替代新的通过依据', () => fixture(({ command, state, directory }) => {
  assert.equal(command('init', '--goal', '核对历史不能越过新门槛', '--apply').status, 0)
  for (const step of state().steps) {
    assert.equal(command('set-step', '--step', step.id, '--status', 'passed', '--evidence', `${step.id}: 旧结果`, '--apply').status, 0)
  }
  assert.equal(command('set-step', '--step', 'ship', '--status', 'in_progress', '--note', '交付变化', '--apply').status, 0)
  assert.equal(command('set-step', '--step', 'verify', '--status', 'in_progress', '--note', '重新验证', '--apply').status, 0)
  const manual = state()
  Object.assign(manual.steps.find(step => step.id === 'ship'), { status: 'passed', evidence: 'ship: 旧结果' })
  const file = join(directory, 'progress.json')
  writeFileSync(file, JSON.stringify(manual))
  assert.equal(command('check').status, 1)
}))

test('旧 JSON 缺少模式字段仍能继续，无效模式不写盘', () => fixture(({ init, state, command, directory }) => {
  init()
  const legacy = state()
  delete legacy.execution_mode
  const file = join(directory, 'progress.json')
  writeFileSync(file, JSON.stringify(legacy))
  assert.equal(command('check').status, 0)
  assert.equal(command('set-step', '--step', 'trim', '--status', 'in_progress', '--apply').status, 0)
  const invalid = state()
  invalid.execution_mode = 'unknown'
  writeFileSync(file, JSON.stringify(invalid))
  const before = readFileSync(file, 'utf8')
  assert.equal(command('check').status, 1)
  assert.equal(command('set-step', '--step', 'trim', '--status', 'passed', '--evidence', 'checked', '--apply').status, 1)
  assert.equal(readFileSync(file, 'utf8'), before)
}))

test('默认路径限制 id，不能越出 tasks 目录', () => fixture(({ root, run }) => {
  const result = run('init', '--root', root, '--id', '2026-10-14-email', '--goal', 'trim', '--steps', 'trim', '--apply')
  assert.equal(result.status, 0, result.stderr)
  assert.equal(existsSync(join(root, 'docs/gh-workflow/tasks/2026-10-14-email/progress.json')), true)
  assert.equal(run('init', '--root', root, '--id', '../escape', '--goal', 'trim', '--steps', 'trim', '--apply').status, 1)
  assert.equal(existsSync(join(root, 'docs/gh-workflow/escape')), false)
}))

test('全部已登记工作项完成才通过，每次通过都需要本次证据', () => fixture(({ init, command, state }) => {
  init()
  assert.equal(command('set-step', '--step', 'trim', '--status', 'passed', '--apply').status, 1)
  assert.equal(command('set-step', '--step', 'trim', '--status', 'passed', '--evidence', 'trim test: exit 0', '--apply').status, 0)
  assert.equal(state().status, 'in_progress')
  assert.equal(state().next_action, '继续处理 verify')
  assert.equal(command('set-step', '--step', 'verify', '--status', 'passed', '--evidence', 'node --test: exit 0', '--apply').status, 0)
  assert.equal(state().status, 'passed')
  assert.equal(state().next_action, '')
}))

test('多条阻塞和历史说明在连续读写后完整保留', () => fixture(({ init, command, state }) => {
  init()
  const blocked = command('set-step', '--step', 'verify', '--status', 'blocked', '--blocker', '账号缺失', '--blocker', '设备缺失', '--note', '依据项目运行要求', '--next-action', '取得账号和设备', '--apply')
  assert.equal(blocked.status, 0, blocked.stderr)
  assert.equal(command('set-step', '--step', 'trim', '--status', 'in_progress', '--note', '继续可独立工作', '--apply').status, 0)
  assert.deepEqual(state().blockers, ['账号缺失', '设备缺失'])
  assert.equal(state().history[0].note, '依据项目运行要求')
  assert.equal(state().history[0].next_action, '取得账号和设备')
  assert.equal(state().next_action, '取得账号和设备')
  assert.equal(state().status, 'blocked')
  assert.equal(command('set-step', '--step', 'verify', '--status', 'in_progress', '--clear-blockers', '--apply').status, 0)
  assert.equal(state().status, 'in_progress')
  assert.deepEqual(state().blockers, [])
}))

test('不同事项新增阻塞不覆盖旧项，只移除已解决项', () => fixture(({ command, state }) => {
  assert.equal(command('init', '--goal', '保留全部阻塞', '--steps', 'verify,review', '--apply').status, 0)
  assert.equal(command('set-step', '--step', 'verify', '--status', 'blocked', '--blocker', '账号缺失', '--next-action', '取得账号后验证', '--apply').status, 0)
  assert.equal(command('set-step', '--step', 'review', '--status', 'blocked', '--blocker', '契约缺失', '--blocker', '账号缺失', '--next-action', '取得账号和契约', '--apply').status, 0)
  assert.deepEqual(state().blockers, ['账号缺失', '契约缺失'])
  assert.equal(command('set-step', '--step', 'verify', '--status', 'in_progress', '--remove-blocker', '账号缺失', '--next-action', '取得契约后审阅', '--apply').status, 0)
  assert.deepEqual(state().blockers, ['契约缺失'])
  assert.equal(state().status, 'blocked')
  assert.equal(state().history.at(-1).blockers.length, 1)
  assert.equal(command('set-step', '--step', 'review', '--status', 'in_progress', '--remove-blocker', '契约缺失', '--apply').status, 0)
  assert.deepEqual(state().blockers, [])
  assert.equal(state().status, 'in_progress')
}))

test('移除未知阻塞或混用整体清空时不修改记录', () => fixture(({ init, command, directory }) => {
  init()
  const file = join(directory, 'progress.json')
  const before = readFileSync(file, 'utf8')
  for (const extra of [
    ['--remove-blocker', '未登记'], ['--blocker', '新阻塞', '--clear-blockers'],
    ['--remove-blocker', '未登记', '--clear-blockers'],
  ]) {
    assert.equal(command('set-step', '--step', 'verify', '--status', 'in_progress', ...extra, '--apply').status, 1)
    assert.equal(readFileSync(file, 'utf8'), before)
  }
}))

test('重新打开已完成工作项会撤销任务完成，旧证据留在历史', () => fixture(({ init, command, state }) => {
  init()
  for (const step of ['trim', 'verify']) assert.equal(command('set-step', '--step', step, '--status', 'passed', '--evidence', `${step}: exit 0`, '--apply').status, 0)
  assert.equal(command('set-step', '--step', 'trim', '--status', 'in_progress', '--note', '源码发生变化', '--apply').status, 0)
  assert.equal(state().status, 'in_progress')
  assert.equal(state().steps[0].evidence, '')
  assert.equal(state().history.at(-1).previous.evidence, 'trim: exit 0')
  assert.equal(command('set-step', '--step', 'trim', '--status', 'passed', '--apply').status, 1)
  assert.equal(command('check').status, 0)
}))

test('失败恢复只在所有阻塞和失败解决后恢复进行中', () => fixture(({ init, command, state }) => {
  init()
  assert.equal(command('set-step', '--step', 'trim', '--status', 'failed', '--evidence', 'node --test: exit 1', '--apply').status, 0)
  assert.equal(command('set-step', '--step', 'verify', '--status', 'blocked', '--apply').status, 0)
  assert.equal(command('set-step', '--step', 'trim', '--status', 'in_progress', '--apply').status, 0)
  assert.equal(state().status, 'blocked')
  assert.equal(command('set-step', '--step', 'verify', '--status', 'in_progress', '--apply').status, 0)
  assert.equal(state().status, 'in_progress')
}))

test('新增工作项能重新打开任务，预览更新不修改记录', () => fixture(({ init, command, state, directory }) => {
  init()
  for (const step of ['trim', 'verify']) command('set-step', '--step', step, '--status', 'passed', '--evidence', 'checked', '--apply')
  const before = readFileSync(join(directory, 'progress.json'), 'utf8')
  assert.equal(command('set-step', '--step', 'caller', '--status', 'pending').status, 0)
  assert.equal(readFileSync(join(directory, 'progress.json'), 'utf8'), before)
  assert.equal(command('set-step', '--step', 'caller', '--status', 'pending', '--apply').status, 0)
  assert.equal(state().status, 'in_progress')
}))

test('状态自相矛盾时拒绝更新，保留原文件', () => fixture(({ init, command, state, directory }) => {
  init()
  const invalid = state()
  invalid.status = 'passed'
  const file = join(directory, 'progress.json')
  writeFileSync(file, JSON.stringify(invalid))
  const before = readFileSync(file, 'utf8')
  assert.equal(command('check').status, 1)
  assert.equal(command('set-step', '--step', 'trim', '--status', 'in_progress', '--apply').status, 1)
  assert.equal(readFileSync(file, 'utf8'), before)
}))

test('已有目录和旧版 YAML 不被初始化或更新覆盖', () => fixture(({ directory, command }) => {
  mkdirSync(directory, { recursive: true })
  const file = join(directory, 'progress.yaml')
  writeFileSync(file, 'current_stage: verify\nblockers:\n  - one\n  - two\n')
  const before = readFileSync(file, 'utf8')
  const result = command('set-step', '--step', 'verify', '--status', 'passed', '--evidence', 'checked', '--apply')
  assert.equal(result.status, 1)
  assert.match(result.stderr, /Legacy progress.yaml/)
  assert.equal(command('init', '--goal', 'trim', '--steps', 'trim', '--apply').status, 1)
  assert.deepEqual(readdirSync(directory), ['progress.yaml'])
  assert.equal(readFileSync(file, 'utf8'), before)
}))

test('非法参数和重复工作项不产生文件', () => fixture(({ command, directory }) => {
  for (const extras of [['--mode', 'unknown'], ['--steps', 'trim,trim'], ['--steps', '']]) {
    const result = command('init', '--goal', 'trim', ...extras, '--apply')
    assert.equal(result.status, 1)
    assert.equal(existsSync(directory), false)
  }
}))
