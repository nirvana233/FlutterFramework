# 任务记录

项目已有等价记录时直接沿用。没有约定时使用目标项目的 `docs/gh-workflow/tasks/YYYY-MM-DD-<slug>/`，默认创建两个文件：

- `task.md`：按 [需求与切片](spec-and-slices.md) 记录目标、范围、非目标、验收与验证方法、计划、关键决策，以及实际验证、审阅、交付和归档决定。复杂计划或大量证据确有需要时再拆文件。
- `progress.json`：阶段和交付单元的状态、推进约定、当前阻塞与下一动作。`history` 保留更新时的证据与说明，避免重开工作项后丢掉历史。

默认记录 `requirements,plan,build,verify,review,ship,archive` 七个阶段，可追加交付单元；项目已有等价阶段时使用项目定义并核对职责覆盖。已有旧任务包继续沿用原计划、阶段及确认记录，不因记录格式不同重跑。

当前记录按适用范围写明负责人、工作区与可写范围、待验收成果、已验收证据、阻塞影响及下一动作。已有看板、任务文档或进度文件能承载时就地补充；无需为了这些内容再建 `process.md`、调度器或多份交接副本。

## JSON 记录约定

新建 JSON 记录使用 `schema_version: 2`，包含非空的 `task_id`、`goal`，以及下列字段：

```json
{
  "schema_version": 2,
  "task_id": "example",
  "goal": "任务目标",
  "execution_mode": "guided",
  "status": "in_progress",
  "next_action": "核对需求与验收标准",
  "steps": [
    { "id": "requirements", "status": "pending", "evidence": "" },
    { "id": "plan", "status": "pending", "evidence": "" },
    { "id": "build", "status": "pending", "evidence": "" },
    { "id": "verify", "status": "pending", "evidence": "" },
    { "id": "review", "status": "pending", "evidence": "" },
    { "id": "ship", "status": "pending", "evidence": "" },
    { "id": "archive", "status": "pending", "evidence": "" }
  ],
  "blockers": [],
  "history": [],
  "updated_at": "2026-10-15T00:00:00Z"
}
```

`execution_mode` 记录已有推进约定，值为 `guided | full-auto`；旧 JSON 缺少该字段仍可读取，实际授权与用户要求为准。`evidence` 写结果与来源，较长记录可指向 `task.md` 的对应部分。手动重开事项前，将旧状态、证据、失效原因与时间保留在 `history`；使用工具时自动保存旧状态与证据。

负责人、范围和协作交接写在任务说明或已有记录中；JSON 以 `evidence`、历史说明和 `next_action` 引用即可。执行者报告完成时，验收事项仍为 `in_progress`，说明成果位置及待核查内容；核对实际成果与证据后才将验收事项标为 `passed`。已有完成状态表示实现已结束时保留其语义，另在现有记录注明待验收，避免将报告完成误作整体验收。

阶段例外按 [基线与例外](lifecycle.md#基线与例外) 决定。工具将评估或记录引用、授权来源及当时未完成的前置阶段保存在该事项的 `exception: { assessment, authorization, pending_stages }` 和历史中；重开后原例外留在历史，重新通过时核对是否仍适用。

## 可选状态工具

`scripts/workflow-state.mjs` 无第三方依赖。默认预览，`--apply` 才写盘；已有记录可直接编辑，不必使用工具。

```bash
# 默认路径和七个阶段；--root 指定目标项目
node <skill-dir>/scripts/workflow-state.mjs init --root <project> \
  --id 2026-10-15-example --goal "任务目标" --apply

# 显式全自动时记录模式；项目等价阶段可用 --steps 指定
node <skill-dir>/scripts/workflow-state.mjs init --task <task-directory> \
  --goal "任务目标" --mode full-auto --apply

# 完成工作项必须提供本次证据；重开时旧证据留在 history
node <skill-dir>/scripts/workflow-state.mjs set-step --task <task-directory> \
  --step verify --status passed --evidence "项目测试命令：exit 0；验收结果见 task.md" --apply
node <skill-dir>/scripts/workflow-state.mjs set-step --task <task-directory> \
  --step verify --status in_progress --note "调用方改变，需要重新验证" \
  --next-action "核对新调用方并复测" --apply

# 阻塞增量添加并去重；解决哪项就移除哪项
node <skill-dir>/scripts/workflow-state.mjs set-step --task <task-directory> \
  --step verify --status blocked --blocker "缺少测试账号" --blocker "设备不可用" \
  --next-action "取得账号和设备后运行集成检查" --apply
node <skill-dir>/scripts/workflow-state.mjs set-step --task <task-directory> \
  --step verify --status blocked --remove-blocker "缺少测试账号" \
  --next-action "设备可用后运行集成检查" --apply

# 已评估且获授权的顺序例外；前置项仍保留未完成状态
node <skill-dir>/scripts/workflow-state.mjs set-step --task <task-directory> \
  --step ship --status passed --evidence "已交付可独立部分，整体验收未完成" \
  --exception "task.md#例外：原因、影响、风险、替代验证与恢复办法" \
  --authorization "用户批准本次部分交付的会话决定" --apply

node <skill-dir>/scripts/workflow-state.mjs check --task <task-directory>
```

工作项状态为 `pending | in_progress | passed | failed | blocked`。任务状态从工作项和阻塞列表推导；每次将工作项标为 `passed` 都需新证据。对已登记的标准阶段，工具按默认顺序核对前置项；顺序例外须同时提供评估和授权来源，普通备注或模式字段不能代替。`--steps` 用于项目等价流程，不代替例外评估和授权；自定义事项的依赖及受改动影响的其他完成项由执行者核对，工具不推断源码依赖。

`--blocker` 增量添加，`--remove-blocker` 显式移除；仅在全部已解决时使用 `--clear-blockers`。尚有阻塞时，更新无关事项默认保留原下一动作；恢复条件改变时显式更新 `--next-action`。

任务级 `blocked` 是汇总状态，不能据此停止所有单元；依赖范围和仍可执行的下一动作由现有任务记录说明，无关事项可继续更新。它不承担并发调度或文件锁职责。

`check` 同样核对标准阶段前置关系。前置项未完成时，后续通过项需有覆盖该前置项的例外，或有历史表明后续项通过时前置项已完成、之后才重开；否则拒绝记录。手动维护历史时沿用工具结构：`step`、`status`、`evidence` 与 `previous: { status, evidence }`，按更新顺序保存。重开后，哪些后续证据受影响仍由执行者判断并重新打开，工具保留有效完成项。

工具不能鉴别证据、评估或授权来源的真实性。`check` 成功不等于任务完成；`passed` 只说明已登记工作项全部通过，整体完成仍需核对当前验收、职责覆盖、授权与真实证据。

工具以 JSON 读写状态，并在替换前写临时文件，避免截断原状态。它不执行开发命令，也不管理 Git。旧版 YAML 任务包继续沿用原文件，工具会明确提示旧格式，不自动覆盖或迁移；按旧证据与当前事实继续即可，无需为了历史模式字段重复确认。
