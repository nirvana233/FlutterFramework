#!/usr/bin/env node

import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { basename, join, resolve } from 'node:path'
import { execFileSync } from 'node:child_process'

const STATUSES = new Set(['pending', 'in_progress', 'passed', 'failed', 'blocked'])
const STAGES = ['requirements', 'plan', 'build', 'verify', 'review', 'ship', 'archive']
const MODES = new Set(['guided', 'full-auto'])
const ID = /^[a-z0-9][a-z0-9-]{0,95}$/

function fail(message) { throw new Error(message) }
function usage() {
  return `Usage:
  workflow-state.mjs init --goal <goal> [--mode guided|full-auto] [--steps <id,id,...>] [--task <directory> | --root <project> --id <id>] [--apply]
  workflow-state.mjs set-step --step <id> --status <status> [--evidence <text>] [--note <text>] [--next-action <text>] [--exception <assessment>] [--authorization <source>] [--blocker <text> ...] [--remove-blocker <text> ... | --clear-blockers] [--task <directory> | --root <project> --id <id>] [--apply]
  workflow-state.mjs check [--task <directory> | --root <project> --id <id>]`
}

function args(argv, command) {
  const common = ['task', 'root', 'id']
  const allowed = new Set([...common, ...(command === 'init' ? ['goal', 'mode', 'steps', 'apply']
    : command === 'set-step' ? ['step', 'status', 'evidence', 'note', 'next-action', 'exception', 'authorization', 'blocker', 'remove-blocker', 'clear-blockers', 'apply'] : [])])
  const result = {}
  for (let i = 0; i < argv.length; i++) {
    const key = argv[i].startsWith('--') ? argv[i].slice(2) : ''
    if (!allowed.has(key)) fail(`Unknown option: ${argv[i]}\n${usage()}`)
    if (!['blocker', 'remove-blocker'].includes(key) && key in result) fail(`Duplicate option: --${key}`)
    if (['apply', 'clear-blockers'].includes(key)) { result[key] = true; continue }
    const value = argv[++i]
    if (value === undefined || value.startsWith('--')) fail(`Missing value: --${key}`)
    if (['blocker', 'remove-blocker'].includes(key)) (result[key] ??= []).push(value)
    else result[key] = value
  }
  if (result.task && (result.root || result.id)) fail('Use --task or --root/--id, not both')
  if ((result.blocker || result['remove-blocker']) && result['clear-blockers']) fail('Use individual blocker updates or --clear-blockers, not both')
  return result
}

function taskDirectory(options) {
  if (options.task) return resolve(options.task)
  if (!ID.test(options.id ?? '')) fail('A valid --id or --task is required')
  let root = options.root
  if (!root) {
    try { root = execFileSync('git', ['rev-parse', '--show-toplevel'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim() }
    catch { root = process.cwd() }
  }
  return resolve(root, 'docs', 'gh-workflow', 'tasks', options.id)
}

function taskStatus(state) {
  if (state.steps.some(step => step.status === 'failed')) return 'failed'
  if (state.blockers.length || state.steps.some(step => step.status === 'blocked')) return 'blocked'
  return state.steps.length && state.steps.every(step => step.status === 'passed') ? 'passed' : 'in_progress'
}

function priorStages(state, id) {
  return state.steps.filter(step => STAGES.includes(step.id) && STAGES.indexOf(step.id) < STAGES.indexOf(id))
}

function completedBeforeReopen(state, step, prior) {
  const completedAt = state.history.findLastIndex(event => event?.step === step.id)
  const completion = state.history[completedAt]
  if (completion?.status !== 'passed' || completion.evidence !== step.evidence) return false
  const changes = state.history.slice(completedAt + 1).filter(event => event?.step === prior.id)
  const before = changes[0]?.previous
  const current = changes.at(-1)
  return before?.status === 'passed' && typeof before.evidence === 'string' && !!before.evidence.trim()
    && current.status === prior.status && current.evidence === prior.evidence
}

function validate(state) {
  if (state.schema_version !== 2 || typeof state.task_id !== 'string' || !state.task_id.trim()
    || typeof state.goal !== 'string' || !state.goal.trim()) fail('Invalid task identity or schema_version')
  if (state.execution_mode !== undefined && !MODES.has(state.execution_mode)) fail('Invalid execution_mode')
  for (const field of ['blockers', 'history', 'steps']) if (!Array.isArray(state[field])) fail(`Invalid ${field}`)
  if (!state.steps.length) fail('At least one work item is required')
  if (state.blockers.some(value => typeof value !== 'string' || !value.trim())) fail('Invalid blocker')
  const ids = new Set()
  for (const step of state.steps) {
    if (!step || !ID.test(step.id ?? '') || ids.has(step.id) || !STATUSES.has(step.status)) fail('Invalid or duplicate work item')
    ids.add(step.id)
    if (typeof step.evidence !== 'string' || (step.status === 'passed' && !step.evidence.trim())) fail(`Passed work item requires evidence: ${step.id}`)
    if (step.exception !== undefined && (step.status !== 'passed'
      || typeof step.exception?.assessment !== 'string' || !step.exception.assessment.trim()
      || typeof step.exception.authorization !== 'string' || !step.exception.authorization.trim()
      || !Array.isArray(step.exception.pending_stages)
      || step.exception.pending_stages.some(id => !STAGES.includes(id)
        || STAGES.indexOf(id) >= STAGES.indexOf(step.id)))) fail(`Invalid exception: ${step.id}`)
  }
  for (const step of state.steps.filter(item => item.status === 'passed')) {
    const missing = priorStages(state, step.id).filter(prior => prior.status !== 'passed'
      && !step.exception?.pending_stages.includes(prior.id) && !completedBeforeReopen(state, step, prior))
    if (missing.length) fail(`Stage ${step.id} passed before prior stages: ${missing.map(item => item.id).join(', ')}; record the exception or completion/reopen history`)
  }
  if (state.status !== taskStatus(state)) fail('Task status does not match work items and blockers')
  if (typeof state.next_action !== 'string' || (state.status !== 'passed' && !state.next_action.trim())) fail('Unfinished task requires next_action')
}

function save(file, state, apply, fresh = false) {
  validate(state)
  const content = JSON.stringify(state, null, 2) + '\n'
  if (!apply) { console.log(`dry-run: would write ${file}\n${content}`); return }
  if (fresh) writeFileSync(file, content, { flag: 'wx' })
  else {
    const temporary = `${file}.${process.pid}.tmp`
    writeFileSync(temporary, content, { flag: 'wx' })
    renameSync(temporary, file)
  }
  console.log(`updated ${file}`)
}

function main() {
  const [command, ...argv] = process.argv.slice(2)
  if (!['init', 'set-step', 'check'].includes(command)) fail(usage())
  const options = args(argv, command)
  const directory = taskDirectory(options)
  const file = join(directory, 'progress.json')
  if (existsSync(join(directory, 'progress.yaml'))) fail('Legacy progress.yaml: read and continue the existing package manually; no files were changed')
  if (command === 'init') {
    if (existsSync(directory)) fail(`Refusing to overwrite existing task directory: ${directory}`)
    const ids = options.steps === undefined ? STAGES : options.steps.split(',')
    const state = {
      schema_version: 2, task_id: options.id ?? basename(directory), goal: options.goal,
      execution_mode: options.mode ?? 'guided',
      status: 'in_progress', next_action: '明确范围和完成标准，按工作项推进',
      steps: ids.map(id => ({ id, status: 'pending', evidence: '' })),
      blockers: [], history: [], updated_at: new Date().toISOString(),
    }
    validate(state)
    if (options.apply) {
      mkdirSync(directory, { recursive: true })
      writeFileSync(join(directory, 'task.md'), `# ${state.task_id}\n\n## 问题与目标\n${state.goal}\n\n## 范围与非目标\n\n## 验收与验证方法\n\n## 计划\n\n## 关键决策与依据\n\n## 验证与审阅记录\n\n## 交付与归档\n`, { flag: 'wx' })
    }
    save(file, state, options.apply, true)
    return
  }
  const state = JSON.parse(readFileSync(file, 'utf8'))
  validate(state)
  if (command === 'check') {
    console.log(JSON.stringify({ ok: true, ...state }, null, 2))
    return
  }
  if (!ID.test(options.step ?? '') || !STATUSES.has(options.status)) fail('Valid --step and --status are required')
  if (options.status === 'passed' && !options.evidence?.trim()) fail('Passing a work item requires fresh --evidence')
  const hasException = options.exception !== undefined || options.authorization !== undefined
  if (hasException && (options.status !== 'passed' || !options.exception?.trim() || !options.authorization?.trim())) {
    fail('An exception requires passed status, --exception assessment and --authorization source')
  }
  const pendingStages = priorStages(state, options.step).filter(item => item.status !== 'passed').map(item => item.id)
  if (options.status === 'passed' && pendingStages.length && !hasException) {
    fail(`Prior stages are unfinished: ${pendingStages.join(', ')}; assess and authorize an exception before passing out of order`)
  }
  for (const blocker of options['remove-blocker'] ?? []) {
    if (!state.blockers.includes(blocker)) fail(`Unknown blocker: ${blocker}`)
  }
  const wasBlocked = state.status === 'blocked'
  let step = state.steps.find(item => item.id === options.step)
  if (!step) { step = { id: options.step, status: 'pending', evidence: '' }; state.steps.push(step) }
  const previous = { ...step }
  step.status = options.status
  step.evidence = options.evidence ?? ''
  delete step.exception
  if (hasException) step.exception = { assessment: options.exception, authorization: options.authorization, pending_stages: pendingStages }
  state.blockers = [...new Set([...state.blockers, ...(options.blocker ?? [])])]
    .filter(blocker => !options['remove-blocker']?.includes(blocker))
  if (options['clear-blockers']) state.blockers = []
  state.status = taskStatus(state)
  state.next_action = options['next-action'] ?? (state.status === 'passed' ? ''
    : wasBlocked && state.status === 'blocked' && !options['remove-blocker'] && !options['clear-blockers'] ? state.next_action
    : `继续处理 ${state.steps.find(item => item.status !== 'passed')?.id ?? '阻塞项'}`)
  state.updated_at = new Date().toISOString()
  state.history.push({ at: state.updated_at, step: step.id, previous, status: step.status,
    evidence: step.evidence, ...(step.exception ? { exception: step.exception } : {}),
    note: options.note ?? '', next_action: state.next_action, blockers: [...state.blockers] })
  save(file, state, options.apply)
}

try { main() } catch (error) { console.error(error.message); process.exitCode = 1 }
