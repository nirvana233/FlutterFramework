---
description: gh-workflow · 开发工作流
disable-model-invocation: true
argument-hint: "[任务目标或现有任务包]"
---

按下列 Skill 正文处理任务。其中的相对引用以
`${CLAUDE_PLUGIN_ROOT}/skills/gh-workflow/` 为基准解析：

@${CLAUDE_PLUGIN_ROOT}/skills/gh-workflow/SKILL.md

用户任务：

$ARGUMENTS
