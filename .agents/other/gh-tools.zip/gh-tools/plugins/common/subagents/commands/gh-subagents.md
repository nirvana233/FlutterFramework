---
description: gh-subagents · 多代理协作
argument-hint: "[协作任务、已有进度或待验收成果]"
---

按下列 Skill 正文处理请求。其中的相对引用以
`${CLAUDE_PLUGIN_ROOT}/skills/gh-subagents/` 为基准解析：

@${CLAUDE_PLUGIN_ROOT}/skills/gh-subagents/SKILL.md

用户请求：

$ARGUMENTS
