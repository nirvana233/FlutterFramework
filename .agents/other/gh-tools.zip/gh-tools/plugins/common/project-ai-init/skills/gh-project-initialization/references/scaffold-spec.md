# AI 规则目录与链接规范

本文件是结构、链接、脚本输出与保护边界的权威定义；[SKILL.md](../SKILL.md) 定义内容检查与执行流程。脚本实现本规范中的确定性补缺，不能验证规则内容质量或客户端实际加载。

## 默认骨架与现有布局

空项目默认使用以下结构；已有项目按实际客户端和现有事实源补缺，保留有效自定义布局。

```text
<项目根>/
├── AGENTS.md                        常驻边界与任务路由
├── CLAUDE.md                        默认 @AGENTS.md 入口
├── .cursor/rules/project.mdc        默认指向 AGENTS.md 的规则
├── .agents/skills/                  项目 Skill 事实源，空目录用 .gitkeep 占位
├── .claude/skills                   整目录链接或逐项链接（见下）
├── .workbuddy/memory/               可选的本地记忆
└── docs/knowledge/                  无已有知识目录时的归档落点
```

各客户端识别的入口与引用语法按其安装版本核对官方资料：[Codex 项目规则](https://developers.openai.com/codex/guides/agents-md/)、[Codex Skills](https://developers.openai.com/codex/skills/)、[Claude Code memory](https://code.claude.com/docs/en/memory)、[Claude Code Skills](https://code.claude.com/docs/en/skills)、[Cursor rules](https://cursor.com/docs/context/rules)。这些位置是适配入口，不代表所有客户端以同样优先级读取全部文件。

已有知识目录按 `docs/knowledge` → `docs/architecture` → `docs/decisions` → `docs/adr` 顺序复用第一个目录，不另建平行知识库。WorkBuddy 仅在显式 `--workbuddy` 或已有 `.workbuddy/` 目录时补 `memory/`。不生成 CI、hooks、工程代码或 MCP 配置。

## 两种等价 Skill 入口

共享事实源为 `.agents/skills/`，每个项目 Skill 对应可解析的目录及可读 `SKILL.md`。`.gitkeep` 只占位，不算 Skill；其他无法识别为 Skill 的源项单独报告。

- **整目录链接**：`.claude/skills` 解析后的真实目录等于 `.agents/skills` 的真实目录。按真实目标判断，链接文字不必完全一致；断链、循环、错误目标都不等价。
- **逐项链接**：`.claude/skills` 为真实目录；事实源中的每个 Skill 均有同名软链，解析到同一 Skill 的真实目录。覆盖完整、每项有效且没有额外项时才等价。空事实源与空入口目录可等价；真实文件、真实子目录或副本均保留并报告，不能因其位于这个目录就判定有效。

`.claude/skills` 入口缺失时，新建默认整目录链接；已有逐项布局保持逐项布局，只补缺失项。macOS / Linux 新建相对软链；Windows 新建目录 junction。已有相对 / 绝对链接均按解析后的目标核对。

异常处理：

| 现状 | 动作与报告 |
| --- | --- |
| 事实源缺失，已有逐项目录为空 | 列为 `prerequisites`，创建源目录后再复查；预检不宣称等价，也不误报永久冲突 |
| 逐项入口缺失，源 Skill 有效 | dry-run 列 `missing` 和创建计划；apply 仅补不存在的同名链接 |
| 同名坏链接、断链、循环或错误目标 | `issues` 中列路径和原因，保留原项 |
| 同名真实文件 / 目录 | 冲突并保留，不复制、合并或删除 |
| 目标有源目录不存在的额外项 | 列路径和类型并保留，不能视为完整等价布局 |
| 事实源不是实际目录，或源项不是可读 Skill | 报冲突，不把异常来源复制到入口 |
| 写入动作的父路径为文件或软链 | 报冲突，避免沿父路径意外写入其他位置 |

局部冲突不阻止其他独立安全补缺。已有项目维护脚本可继续作为维护入口；读取其真实实现后复用，不能把只比对名称集合的检查当成真实目标验证。

## 规则和已有内容保护

脚本只对缺失的规则文件写骨架；已有 `AGENTS.md`、`CLAUDE.md`、Cursor 规则文件逐项跳过。这只表示“脚本未覆盖”，不是内容已经核验。目录、文件、软链等实际类型由报告说明，语义检查与最小编辑按主流程完成。既有权威来源不在 `AGENTS.md` 时仍沿用，通过可达入口引用，避免强制搬迁。

`.agents/skills/` 的项目内容正常入库。`.claude/skills` 若是整目录链接可整体忽略；若是逐项布局，只忽略已核验或计划补齐的链接路径，合并后稳定排序，使额外实际内容仍可见，补缺后重跑无额外改写。默认脚本维护 `.gitignore` 的以下边界，区块外内容保留：

```gitignore
# >>> project-ai-init >>>
# AI 工具本地状态与可重建的软链，不入库；真实内容保持可见。
.workbuddy/
# 此处按布局列出整目录链接，或逐项链接路径
.claude/settings.local.json
# <<< project-ai-init <<<
```

已有项目在区块外另有忽略规则时需要检查其效果，脚本不自动改写。不要忽略整个 `.claude/`；其中可能有共享配置。重跑初始化可重建缺失链接，真实 Skill 内容不应依赖本机临时状态。

受管标记必须各占一行，恰好出现一对且开始在结束之前。缺失半边、重复或倒序时报告冲突并保留整个 `.gitignore`，其他独立安全动作继续；由用户检查边界后再处理。没有标记时追加区块，保留原文件的全部字节，包括空白。

## 脚本契约和证据范围

`node scripts/init.mjs --help` 列参数，默认 dry-run；`--apply` 才写入，`--json` 给出：

- `detected.projectState`：空目录或已有内容；`markers` 是已识别的配置文件。
- `detected.commands`：从配置提取且有包管理器 / 工具依据的命令；`commandCandidates` 是仍需核实的生态惯例或包管理器候选。两者 `verification: not-run`，脚本均不执行。未支持的配置由 agent 读取核实。
- `actions`：各项计划 / 执行状态和原因。已有规则跳过后仍需内容检查。
- `skillLayout`：检查时的布局、`sourceSkills`、`valid`、`missing`、`prerequisites`（尚需补齐的前置条件）、`issues`（真实冲突）、`equivalent`；apply 后另给 `skillLayoutAfter`，区分计划与写入后的检查结果。前置条件不算冲突，创建失败仍按失败退出，不能宣称等价。
- `summary`：新建、更新、跳过、冲突、失败数量。

退出码 `0` 表示无冲突或写入失败（正常跳过也为 0）；`1` 表示冲突或局部写入失败，其余安全动作可能已完成；`2` 表示参数错误或目标根缺失 / 不是目录，未进入写入。失败和冲突不靠删除用户内容消除。

配置探测、链接检查、规则走读和实际执行是不同证据；完成判定使用主流程的验证要求，不能只用脚本退出 0 代替。
