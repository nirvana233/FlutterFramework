import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, lstatSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, readlinkSync, realpathSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const SCRIPT = fileURLToPath(new URL('./init.mjs', import.meta.url))
const FIXTURES = JSON.parse(readFileSync(new URL('../test-fixtures.json', import.meta.url), 'utf8'))

function fixture(t) {
  const prefix = join(tmpdir(), 'gh project 初始化-')
  const root = mkdtempSync(prefix)
  t.after(() => {
    assert.ok(root.startsWith(prefix))
    rmSync(root, { recursive: true, force: true })
  })
  return root
}

function run(root, ...args) {
  return spawnSync(process.execPath, [SCRIPT, '--root', root, '--json', ...args], { encoding: 'utf8' })
}

function put(root, path, content) {
  const abs = join(root, path)
  mkdirSync(dirname(abs), { recursive: true })
  writeFileSync(abs, content)
}

function link(root, path, target) {
  mkdirSync(dirname(join(root, path)), { recursive: true })
  symlinkSync(target, join(root, path), process.platform === 'win32' ? 'junction' : 'dir')
}

function skill(root, name) {
  put(root, `.agents/skills/${name}/SKILL.md`, `---\nname: ${name}\ndescription: Test skill.\n---\nTest.\n`)
}

function seed(root, id) {
  const input = FIXTURES[id]
  for (const [path, content] of Object.entries(input.files ?? input)) {
    if (path.startsWith('$')) continue
    put(root, path, content.replaceAll('{{FIXTURE_ROOT}}', root))
  }
  for (const path of input.$directories ?? []) mkdirSync(join(root, path), { recursive: true })
  for (const [path, target] of Object.entries(input.$symlinks ?? {})) link(root, path, target)
}

function snapshot(root, path = '') {
  const out = {}
  for (const name of readdirSync(join(root, path)).sort()) {
    const rel = path ? `${path}/${name}` : name
    const abs = join(root, rel)
    const stat = lstatSync(abs)
    if (stat.isSymbolicLink()) out[rel] = { link: readlinkSync(abs) }
    else if (stat.isDirectory()) Object.assign(out, snapshot(root, rel))
    else out[rel] = readFileSync(abs, 'utf8')
  }
  return out
}

test('default dry-run and apply omit WorkBuddy; an idempotent rerun exits 0', (t) => {
  const root = fixture(t)
  const preview = run(root)
  assert.equal(preview.status, 0, preview.stderr)
  assert.deepEqual(readdirSync(root), [])
  const action = JSON.parse(preview.stdout).actions.find((item) => item.id === 'workbuddy-memory')
  assert.equal(action.status, 'skipped')
  assert.equal(action.write, null)

  const first = run(root, '--apply')
  assert.equal(first.status, 0, first.stderr)
  assert.equal(JSON.parse(first.stdout).skillLayoutAfter.equivalent, true)
  assert.equal(realpathSync(join(root, '.claude', 'skills')), realpathSync(join(root, '.agents', 'skills')))
  assert.equal(existsSync(join(root, '.workbuddy')), false)
  writeFileSync(join(root, 'AGENTS.md'), '# User rules\n')
  const before = snapshot(root)
  const second = run(root, '--apply')
  assert.equal(second.status, 0, second.stderr)
  assert.ok(JSON.parse(second.stdout).summary.skip > 0)
  assert.equal(readFileSync(join(root, 'AGENTS.md'), 'utf8'), '# User rules\n')
  assert.deepEqual(snapshot(root), before)
})

test('malformed managed markers preserve the entire ignore file and report a conflict', (t) => {
  const begin = '# >>> project-ai-init >>>'
  const end = '# <<< project-ai-init <<<'
  for (const content of [`before\n${end}\nUSER\n${begin}\nafter\n`, `${begin}\nUSER\n`, `${begin}\n${end}\n${begin}\n${end}\n`]) {
    const root = fixture(t)
    put(root, '.gitignore', content)
    for (const args of [[], ['--apply']]) {
      const result = run(root, ...args)
      assert.equal(result.status, 1, result.stdout)
      assert.equal(JSON.parse(result.stdout).actions.find((item) => item.id === 'gitignore').status, 'conflict')
      assert.equal(readFileSync(join(root, '.gitignore'), 'utf8'), content)
    }
    assert.equal(existsSync(join(root, 'AGENTS.md')), true)
  }
})

test('appending to a whitespace-only ignore file preserves its bytes', (t) => {
  const root = fixture(t)
  put(root, '.gitignore', '  \n\t')
  const result = run(root, '--apply')
  assert.equal(result.status, 0, result.stdout)
  assert.ok(readFileSync(join(root, '.gitignore'), 'utf8').startsWith('  \n\t\n\n'))
})

test('--workbuddy explicitly enables memory creation and remains dry-run by default', (t) => {
  const root = fixture(t)
  const preview = run(root, '--workbuddy')
  assert.equal(preview.status, 0, preview.stderr)
  assert.equal(JSON.parse(preview.stdout).actions.find((item) => item.id === 'workbuddy-memory').status, 'will-create')
  assert.equal(existsSync(join(root, '.workbuddy')), false)
  const applied = run(root, '--workbuddy', '--apply')
  assert.equal(applied.status, 0, applied.stderr)
  assert.equal(existsSync(join(root, '.workbuddy', 'memory')), true)
})

test('an existing .workbuddy directory enables memory creation without replacing its content', (t) => {
  const root = fixture(t)
  mkdirSync(join(root, '.workbuddy'))
  writeFileSync(join(root, '.workbuddy', 'settings.json'), '{}\n')
  const result = run(root, '--apply')
  assert.equal(result.status, 0, result.stderr)
  assert.equal(existsSync(join(root, '.workbuddy', 'memory')), true)
  assert.equal(readFileSync(join(root, '.workbuddy', 'settings.json'), 'utf8'), '{}\n')
})

test('a real .claude/skills directory is preserved and reported with exit 1', (t) => {
  const root = fixture(t)
  mkdirSync(join(root, '.claude', 'skills'), { recursive: true })
  writeFileSync(join(root, '.claude', 'skills', 'user.txt'), 'keep')
  const before = snapshot(root)
  const preview = run(root)
  assert.equal(preview.status, 1, preview.stdout)
  assert.deepEqual(snapshot(root), before)
  const result = run(root, '--apply')
  assert.equal(result.status, 1, result.stderr)
  assert.equal(JSON.parse(result.stdout).summary.conflict, 1)
  assert.deepEqual(JSON.parse(result.stdout).skillLayoutAfter.issues.map((item) => item.path), ['.claude/skills/user.txt'])
  assert.equal(readFileSync(join(root, '.claude', 'skills', 'user.txt'), 'utf8'), 'keep')
  assert.equal(existsSync(join(root, 'AGENTS.md')), true)
})

test('an empty per-Skill directory with a missing source is a satisfiable prerequisite, not a conflict', (t) => {
  const root = fixture(t)
  mkdirSync(join(root, '.claude/skills'), { recursive: true })
  const before = snapshot(root)
  const preview = run(root)
  assert.deepEqual(snapshot(root), before)
  assert.equal(existsSync(join(root, '.agents/skills')), false)
  const first = run(root, '--apply')
  assert.equal(preview.status, 0, preview.stdout)
  const planned = JSON.parse(preview.stdout)
  assert.equal(planned.skillLayout.equivalent, false)
  assert.deepEqual(planned.skillLayout.issues, [])
  assert.equal(planned.skillLayout.prerequisites[0].path, '.agents/skills')
  assert.equal(planned.actions.find((item) => item.id === 'agents-skills').status, 'will-create')
  assert.equal(first.status, 0, first.stdout)
  const result = JSON.parse(first.stdout)
  assert.equal(result.skillLayout.equivalent, false)
  assert.equal(result.skillLayoutAfter.equivalent, true)
  assert.equal(result.summary.conflict, 0)
  assert.equal(lstatSync(join(root, '.claude/skills')).isSymbolicLink(), false)
  assert.deepEqual(before, {})
  const after = snapshot(root)
  const secondPreview = run(root)
  assert.equal(secondPreview.status, 0, secondPreview.stdout)
  assert.equal(JSON.parse(secondPreview.stdout).summary.update, 0)
  const second = run(root, '--apply')
  assert.equal(second.status, 0, second.stdout)
  assert.deepEqual(snapshot(root), after)
})

test('adding an alphabetically earlier missing link keeps ignore ordering stable on the first apply', (t) => {
  const root = fixture(t)
  skill(root, 'alpha')
  skill(root, 'beta')
  link(root, '.claude/skills/beta', '../../.agents/skills/beta')
  const before = snapshot(root)
  const preview = run(root)
  assert.equal(preview.status, 0, preview.stderr)
  assert.deepEqual(snapshot(root), before)
  assert.deepEqual(JSON.parse(preview.stdout).skillLayout.missing, ['alpha'])
  const first = run(root, '--apply')
  assert.equal(first.status, 0, first.stdout)
  assert.equal(JSON.parse(first.stdout).skillLayoutAfter.equivalent, true)
  const after = snapshot(root)
  const secondPreview = run(root)
  assert.equal(secondPreview.status, 0, secondPreview.stdout)
  assert.equal(JSON.parse(secondPreview.stdout).summary.update, 0, secondPreview.stdout)
  const second = run(root, '--apply')
  assert.equal(second.status, 0, second.stdout)
  assert.equal(JSON.parse(second.stdout).summary.update, 0)
  assert.deepEqual(snapshot(root), after)
})

test('a missing target exits 2 before writing anything', (t) => {
  const root = fixture(t)
  const missing = join(root, 'missing')
  const result = run(missing, '--apply')
  assert.equal(result.status, 2)
  assert.equal(existsSync(missing), false)
})

test('directory links are compared by real target, including an alias', (t) => {
  const root = fixture(t)
  skill(root, 'alpha')
  link(root, 'alias', '.agents/skills')
  link(root, '.claude/skills', '../alias')
  const before = readlinkSync(join(root, '.claude/skills'))
  const result = run(root, '--apply')
  assert.equal(result.status, 0, result.stderr)
  assert.equal(JSON.parse(result.stdout).skillLayout.equivalent, true)
  assert.equal(readlinkSync(join(root, '.claude/skills')), before)
})

test('FeelDrama-shaped 21 per-Skill links are valid and preserved', (t) => {
  const root = fixture(t)
  for (let i = 1; i <= 21; i += 1) {
    const name = `skill-${String(i).padStart(2, '0')}`
    skill(root, name)
    link(root, `.claude/skills/${name}`, `../../.agents/skills/${name}`)
  }
  const preview = run(root)
  assert.equal(preview.status, 0, preview.stderr)
  const layout = JSON.parse(preview.stdout).skillLayout
  assert.equal(layout.layout, 'item-links')
  assert.equal(layout.equivalent, true)
  assert.equal(layout.valid.length, 21)
  const applied = run(root, '--apply')
  assert.equal(applied.status, 0, applied.stderr)
  assert.equal(lstatSync(join(root, '.claude/skills')).isSymbolicLink(), false)
  const before = snapshot(root)
  assert.equal(run(root, '--apply').status, 0)
  assert.deepEqual(snapshot(root), before)
})

test('a missing per-Skill link is previewed, safely added and then idempotent', (t) => {
  const root = fixture(t)
  seed(root, 'item-links-valid')
  const before = snapshot(root)
  const preview = run(root)
  assert.equal(preview.status, 0, preview.stderr)
  assert.deepEqual(JSON.parse(preview.stdout).skillLayout.missing, ['domain-notes'])
  assert.deepEqual(snapshot(root), before)
  const applied = run(root, '--apply')
  assert.equal(applied.status, 0, applied.stderr)
  assert.equal(JSON.parse(applied.stdout).skillLayoutAfter.equivalent, true)
  const after = snapshot(root)
  assert.equal(run(root, '--apply').status, 0)
  assert.deepEqual(snapshot(root), after)
})

test('broken, wrong, extra and real items remain intact while an independent missing link is added', (t) => {
  const root = fixture(t)
  seed(root, 'item-links-conflicts')
  const before = snapshot(root)
  const preview = run(root)
  assert.equal(preview.status, 1)
  assert.deepEqual(snapshot(root), before)
  const applied = run(root, '--apply')
  assert.equal(applied.status, 1, applied.stderr)
  const result = JSON.parse(applied.stdout)
  assert.deepEqual(result.skillLayout.valid, ['alpha'])
  assert.deepEqual(result.skillLayout.missing, ['delta'])
  assert.equal(result.skillLayout.issues.length, 4)
  assert.equal(result.skillLayoutAfter.missing.length, 0)
  assert.equal(result.skillLayoutAfter.equivalent, false)
  const after = snapshot(root)
  for (const [path, content] of Object.entries(before)) assert.deepEqual(after[path], content, path)
  assert.equal(realpathSync(join(root, '.claude/skills/delta')), realpathSync(join(root, '.agents/skills/delta')))
  const ignore = readFileSync(join(root, '.gitignore'), 'utf8')
  assert.match(ignore, /^\.claude\/skills\/alpha$/m)
  assert.match(ignore, /^\.claude\/skills\/delta$/m)
  assert.doesNotMatch(ignore, /^\.claude\/skills$/m)
  assert.doesNotMatch(ignore, /epsilon|extra\.txt/)
  assert.equal(run(root, '--apply').status, 1)
  assert.deepEqual(snapshot(root), after)
})

test('broken or wrong whole-directory links are conflicts and never replaced', (t) => {
  for (const target of ['../missing', '../other']) {
    const root = fixture(t)
    skill(root, 'alpha')
    mkdirSync(join(root, 'other'))
    link(root, '.claude/skills', target)
    const result = run(root, '--apply')
    assert.equal(result.status, 1)
    assert.equal(readlinkSync(join(root, '.claude/skills')), target)
    assert.equal(JSON.parse(result.stdout).skillLayout.equivalent, false)
  }
})

test('an invalid source cannot create a dangling whole-directory link', (t) => {
  const root = fixture(t)
  put(root, '.agents/skills', 'user content\n')
  const result = run(root, '--apply')
  assert.equal(result.status, 1)
  assert.equal(existsSync(join(root, '.claude/skills')), false)
  assert.equal(readFileSync(join(root, '.agents/skills'), 'utf8'), 'user content\n')
})

test('source entries without a readable SKILL.md are reported, not mirrored', (t) => {
  const root = fixture(t)
  skill(root, 'alpha')
  mkdirSync(join(root, '.agents/skills/not-a-skill'))
  mkdirSync(join(root, '.claude/skills'), { recursive: true })
  const result = run(root, '--apply')
  assert.equal(result.status, 1)
  assert.equal(existsSync(join(root, '.claude/skills/not-a-skill')), false)
  assert.equal(realpathSync(join(root, '.claude/skills/alpha')), realpathSync(join(root, '.agents/skills/alpha')))
})

test('a symlink parent is not traversed for writes', (t) => {
  const root = fixture(t)
  const outside = fixture(t)
  link(root, '.agents', outside)
  const result = run(root, '--apply')
  assert.equal(result.status, 1)
  assert.deepEqual(readdirSync(outside), [])
  assert.equal(JSON.parse(result.stdout).actions.find((item) => item.id === 'agents-skills').status, 'conflict')
  assert.equal(existsSync(join(root, '.claude')), false)
})

test('existing custom authority files are preserved; skip is labelled as requiring content review', (t) => {
  const root = fixture(t)
  seed(root, 'existing-custom-authority')
  put(root, 'AGENTS.md', '# Custom root\nRead docs/engineering.md.\n')
  const before = snapshot(root)
  const result = run(root, '--apply')
  assert.equal(result.status, 0, result.stderr)
  const after = snapshot(root)
  for (const [path, content] of Object.entries(before)) assert.deepEqual(after[path], content, path)
  assert.match(JSON.parse(result.stdout).actions.find((item) => item.id === 'agents-md').note, /仍需检查/)
})

test('an architecture-only project is existing, reuses its knowledge directory and invents no commands', (t) => {
  const root = fixture(t)
  seed(root, 'architecture-only')
  const result = run(root, '--apply')
  assert.equal(result.status, 0, result.stderr)
  const detected = JSON.parse(result.stdout).detected
  assert.equal(detected.projectState, 'existing')
  assert.deepEqual(detected.markers, [])
  assert.deepEqual(detected.commands, [])
  assert.equal(existsSync(join(root, 'docs/knowledge')), false)
  assert.equal(existsSync(join(root, 'pubspec.yaml')), false)
})

test('configuration-derived commands and ecosystem candidates remain distinct and never executed', (t) => {
  const root = fixture(t)
  put(root, 'package.json', '{"packageManager":"pnpm@10.0.0","scripts":{"test":"node scripts/check.mjs"}}')
  put(root, 'pubspec.yaml', 'name: fixture\n')
  put(root, 'pyproject.toml', '[project]\nname = "fixture"\n')
  const preview = run(root)
  assert.equal(preview.status, 0)
  const detected = JSON.parse(preview.stdout).detected
  assert.equal(detected.commands.length, 1)
  assert.equal(detected.commands[0].command, 'pnpm test')
  assert.equal(detected.commands[0].verification, 'not-run')
  assert.deepEqual(detected.commandCandidates.map((item) => item.command), ['flutter analyze', 'flutter test'])
  assert.equal(detected.commands.some((item) => /pytest|ruff/.test(item.command)), false)
})

test('rule-entry directories and dangling links are conflicts, not completed content checks', (t) => {
  const root = fixture(t)
  mkdirSync(join(root, 'AGENTS.md'))
  link(root, 'CLAUDE.md', 'missing-rules.md')
  mkdirSync(join(root, '.cursor/rules/project.mdc'), { recursive: true })
  const result = run(root, '--apply')
  assert.equal(result.status, 1)
  const actions = JSON.parse(result.stdout).actions
  for (const id of ['agents-md', 'claude-md', 'cursor-rule']) {
    assert.equal(actions.find((item) => item.id === id).status, 'conflict')
  }
  assert.equal(lstatSync(join(root, 'AGENTS.md')).isDirectory(), true)
  assert.equal(readlinkSync(join(root, 'CLAUDE.md')), 'missing-rules.md')
})

test('a file named like a knowledge candidate is not reused as a directory', (t) => {
  const root = fixture(t)
  put(root, 'docs/architecture', 'USER-CONTENT\n')
  const result = run(root, '--apply')
  assert.equal(result.status, 0)
  assert.equal(JSON.parse(result.stdout).detected.existingKnowledgeDir, null)
  assert.equal(existsSync(join(root, 'docs/knowledge/.gitkeep')), true)
  assert.equal(readFileSync(join(root, 'docs/architecture'), 'utf8'), 'USER-CONTENT\n')
})

test('a non-directory at the default knowledge path is preserved as a conflict', (t) => {
  const root = fixture(t)
  put(root, 'docs/knowledge', 'USER-CONTENT\n')
  const result = run(root, '--apply')
  assert.equal(result.status, 1)
  assert.equal(JSON.parse(result.stdout).actions.find((item) => item.id === 'docs-knowledge').status, 'conflict')
  assert.equal(readFileSync(join(root, 'docs/knowledge'), 'utf8'), 'USER-CONTENT\n')
})

test('a runtime mkdir denial skips its dependent link and continues independent CLI actions', (t) => {
  const root = fixture(t)
  const injection = fixture(t)
  put(injection, 'deny-mkdir.mjs', [
    "import fs from 'node:fs'",
    "import { resolve } from 'node:path'",
    "import { syncBuiltinESMExports } from 'node:module'",
    'const original = fs.mkdirSync',
    'fs.mkdirSync = (path, ...args) => {',
    '  if (resolve(String(path)) === process.env.GH_INIT_FAIL_MKDIR_TARGET) {',
    "    const error = new Error('EACCES: injected mkdir denial')",
    "    error.code = 'EACCES'",
    '    throw error',
    '  }',
    '  return original(path, ...args)',
    '}',
    'syncBuiltinESMExports()',
    '',
  ].join('\n'))
  const result = spawnSync(process.execPath, ['--import', join(injection, 'deny-mkdir.mjs'), SCRIPT, '--root', root, '--json', '--apply'], {
    encoding: 'utf8',
    env: { ...process.env, GH_INIT_FAIL_MKDIR_TARGET: join(root, '.agents/skills') },
  })
  assert.equal(result.status, 1, result.stderr)
  const report = JSON.parse(result.stdout)
  const source = report.actions.find((item) => item.id === 'agents-skills')
  const destination = report.actions.find((item) => item.id === 'claude-skills-link')
  assert.equal(source.status, 'failed')
  assert.match(source.note, /EACCES/)
  assert.equal(destination.status, 'skipped')
  assert.match(destination.note, /依赖目标目录创建失败/)
  assert.equal(existsSync(join(root, '.claude')), false)
  assert.equal(report.skillLayoutAfter.equivalent, false)
  assert.equal(report.actions.find((item) => item.id === 'gitignore').status, 'created')
  assert.equal(existsSync(join(root, 'docs/knowledge/.gitkeep')), true)
  assert.equal(report.summary.failed, 1)

  const existingEntryRoot = fixture(t)
  mkdirSync(join(existingEntryRoot, '.claude/skills'), { recursive: true })
  const existingEntryPreview = run(existingEntryRoot)
  assert.equal(existingEntryPreview.status, 0, existingEntryPreview.stdout)
  const existingEntryResult = spawnSync(process.execPath, ['--import', join(injection, 'deny-mkdir.mjs'), SCRIPT, '--root', existingEntryRoot, '--json', '--apply'], {
    encoding: 'utf8',
    env: { ...process.env, GH_INIT_FAIL_MKDIR_TARGET: join(existingEntryRoot, '.agents/skills') },
  })
  assert.equal(existingEntryResult.status, 1, existingEntryResult.stderr)
  const existingEntryReport = JSON.parse(existingEntryResult.stdout)
  assert.equal(existingEntryReport.actions.find((item) => item.id === 'agents-skills').status, 'failed')
  assert.equal(existingEntryReport.skillLayoutAfter.equivalent, false)
  assert.equal(existingEntryReport.skillLayoutAfter.prerequisites[0].path, '.agents/skills')
  assert.equal(existingEntryReport.summary.conflict, 0)
  assert.equal(existingEntryReport.summary.failed, 1)
  assert.deepEqual(readdirSync(join(existingEntryRoot, '.claude/skills')), [])
  assert.equal(lstatSync(join(existingEntryRoot, '.claude/skills')).isSymbolicLink(), false)
  assert.equal(existsSync(join(existingEntryRoot, 'docs/knowledge/.gitkeep')), true)
})
