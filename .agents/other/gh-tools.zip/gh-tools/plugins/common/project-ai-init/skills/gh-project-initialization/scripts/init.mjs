#!/usr/bin/env node
/**
 * 给一个项目铺 AI 地基：规则入口、skill 落脚点、工程配套。
 *
 * 建成什么样以 `references/scaffold-spec.md` 为准，本脚本只是它的执行器。
 * 客户端约定（谁读哪个路径、软链往哪指）会随客户端版本变，一律先改规范再同步这里，
 * 不要在脚本里另立一套。
 *
 * 只做确定性的事：建目录、写骨架、建软链、维护 .gitignore 受管区块。
 * 规则正文（AGENTS.md 里的命令、结构、禁区）属于「内容」，由 agent 探测项目后填写，
 * 本脚本只生成带 [待确认] 标记的骨架，不编造任何命令。
 *
 * 用法：
 *   node init.mjs [--root <path>] [--workbuddy] [--json] [--apply]
 *
 * 默认 dry-run，只打印计划；加 --apply 才写盘。
 * 全部动作幂等：不覆盖已有规则或链接；保留整目录链接或逐项链接布局，只安全补缺。
 *
 * 退出码：0 = 成功（含「无事可做」），1 = 有 conflict 或失败，2 = 参数错误
 */

import {
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  readlinkSync,
  realpathSync,
  statSync,
  symlinkSync,
  writeFileSync,
} from 'node:fs'
import { dirname, join, relative, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'

/** .gitignore 受管区块的边界标记。区块内容由本脚本整体替换，标记外的内容不动。 */
const MANAGED_BEGIN = '# >>> project-ai-init >>>'
const MANAGED_END = '# <<< project-ai-init <<<'

/** 只忽略可重建的链接；逐项布局里的真实内容仍可见。 */
function managedLines(skillLayout) {
  const links = skillLayout.layout === 'item-links'
    ? [...skillLayout.valid, ...skillLayout.missing].sort().map((name) => `.claude/skills/${name}`)
    : skillLayout.layout === 'missing' || skillLayout.equivalent ? ['.claude/skills'] : []
  return [
    MANAGED_BEGIN,
    '# AI 工具本地状态与可重建的软链，不入库；真实内容保持可见。',
    '.workbuddy/',
    ...links.map((path) => path.replace(/[\\*?\[\]#! ]/g, '\\$&')),
    '.claude/settings.local.json',
    MANAGED_END,
  ]
}

/** 知识目录的等价候选：项目已有任意一个就不再新建 */
const KNOWLEDGE_DIRS = ['docs/knowledge', 'docs/architecture', 'docs/decisions', 'docs/adr']

/** 探测入口：文件 → 生态与命令来源 */
const DETECTORS = [
  {
    file: 'package.json',
    ecosystem: 'node',
    commands: (root) => {
      const pkg = readJsonFile(join(root, 'package.json'))
      if (!pkg || typeof pkg.scripts !== 'object' || pkg.scripts === null) return []
      const runner = nodeRunner(root)
      // 包管理器的依据必须一并写进来源：只写 scripts.test 会让人以为 `npm` 也是配置里读到的
      const runnerSource = runner.source ?? '无锁文件也未声明 packageManager，按 npm 兜底（未核实）'
      const out = []
      for (const [name, script] of Object.entries(pkg.scripts)) {
        const cmd = name === 'start' || name === 'test' ? `${runner.name} ${name}` : `${runner.name} run ${name}`
        out.push({
          purpose: name,
          command: cmd,
          source: `package.json:scripts.${name}；包管理器依据 ${runnerSource}`,
          script,
          candidate: runner.source === null,
        })
      }
      return out
    },
  },
  {
    file: 'pubspec.yaml',
    ecosystem: 'flutter',
    candidate: true,
    commands: () => [
      {
        purpose: 'analyze',
        command: 'flutter analyze',
        source: 'pubspec.yaml（生态标准子命令，未在本环境核实）',
      },
      {
        purpose: 'test',
        command: 'flutter test',
        source: 'pubspec.yaml（生态标准子命令，未在本环境核实）',
      },
    ],
  },
  {
    file: 'pyproject.toml',
    ecosystem: 'python',
    commands: () => [],
  },
  {
    file: 'tox.ini',
    ecosystem: 'python',
    commands: () => [{ purpose: 'test', command: 'tox', source: 'tox.ini' }],
  },
  {
    file: 'Cargo.toml',
    ecosystem: 'rust',
    candidate: true,
    commands: () => [
      { purpose: 'test', command: 'cargo test', source: 'Cargo.toml' },
      { purpose: 'lint', command: 'cargo clippy', source: 'Cargo.toml' },
      { purpose: 'build', command: 'cargo build', source: 'Cargo.toml' },
    ],
  },
  {
    file: 'go.mod',
    ecosystem: 'go',
    candidate: true,
    commands: () => [
      { purpose: 'test', command: 'go test ./...', source: 'go.mod' },
      { purpose: 'vet', command: 'go vet ./...', source: 'go.mod' },
      { purpose: 'build', command: 'go build ./...', source: 'go.mod' },
    ],
  },
  {
    file: 'Makefile',
    ecosystem: 'task',
    candidate: true,
    commands: () => [{ purpose: 'task', command: 'make', source: 'Makefile（目标名需人工确认）' }],
  },
  {
    file: 'Taskfile.yml',
    ecosystem: 'task',
    candidate: true,
    commands: () => [
      { purpose: 'task', command: 'task --list', source: 'Taskfile.yml（目标名需人工确认）' },
    ],
  },
]

function readJsonFile(path) {
  try {
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch {
    return null
  }
}

/**
 * Node 项目的包管理器，返回 { name, source }。
 *
 * 依据按可信度排序：package.json 的 packageManager（corepack 标准，最权威，monorepo 子包
 * 也常只写它而不放锁文件）→ 锁文件 → 都没有时按 npm 兜底并令 source 为 null。
 * source 为 null 表示这个包管理器是猜的，调用方必须把它如实标进命令来源，不能当作已核实。
 */
function nodeRunner(root) {
  const pkg = readJsonFile(join(root, 'package.json'))
  const declared = typeof pkg?.packageManager === 'string' ? pkg.packageManager.split('@')[0].trim() : ''
  if (declared) return { name: declared, source: 'package.json:packageManager' }
  if (existsSync(join(root, 'pnpm-lock.yaml'))) return { name: 'pnpm', source: 'pnpm-lock.yaml' }
  if (existsSync(join(root, 'yarn.lock'))) return { name: 'yarn', source: 'yarn.lock' }
  // Bun 1.2 起默认生成文本格式的 bun.lock，bun.lockb 是旧格式，两种都认
  if (existsSync(join(root, 'bun.lock')) || existsSync(join(root, 'bun.lockb'))) {
    return { name: 'bun', source: 'bun.lock' }
  }
  if (existsSync(join(root, 'package-lock.json'))) return { name: 'npm', source: 'package-lock.json' }
  return { name: 'npm', source: null }
}

/** 配置探测不执行命令；没有已知标记也不代表空项目。 */
export function detectProject(root) {
  const matched = []
  for (const detector of DETECTORS) {
    if (!existsSync(join(root, detector.file))) continue
    let commands = []
    try {
      commands = detector.commands(root)
    } catch {
      commands = []
    }
    matched.push({ file: detector.file, ecosystem: detector.ecosystem, commands: commands.map((command) => ({ ...command, candidate: command.candidate ?? detector.candidate ?? false, verification: 'not-run' })) })
  }
  const knowledgeDir = KNOWLEDGE_DIRS.find((dir) => realDirectory(join(root, dir))) ?? null
  // 去重：pyproject.toml + tox.ini 都是 python，不去重会输出 "python+python"
  const ecosystems = [...new Set(matched.map((m) => m.ecosystem))]
  return {
    projectState: readdirSync(root).length === 0 ? 'empty' : 'existing',
    ecosystem: ecosystems.length > 0 ? ecosystems.join('+') : null,
    markers: matched.map((m) => m.file),
    commands: matched.flatMap((m) => m.commands).filter((command) => !command.candidate),
    commandCandidates: matched.flatMap((m) => m.commands).filter((command) => command.candidate),
    existingKnowledgeDir: knowledgeDir,
  }
}

function realDirectory(path) {
  try {
    return statSync(path).isDirectory() ? realpathSync(path) : null
  } catch {
    return null
  }
}

/** 结构检查，不执行 Skill，也不替代规则内容或客户端加载验证。 */
export function inspectSkillLayout(root) {
  const source = join(root, '.agents', 'skills')
  const destination = join(root, '.claude', 'skills')
  const sourceState = pathState(source)
  const state = pathState(destination)
  const result = { layout: state === 'dir' ? 'item-links' : state === 'absent' ? 'missing' : 'directory-link', equivalent: false, valid: [], missing: [], prerequisites: [], issues: [] }
  const issue = (path, reason) => result.issues.push({ path, reason })
  if (sourceState === 'absent') {
    result.prerequisites.push({ path: '.agents/skills', reason: '事实源尚未创建，补齐后再核对布局等价性' })
  }
  if (sourceState !== 'dir' && sourceState !== 'absent') {
    issue('.agents/skills', `事实源不是实际目录（${sourceState}），保留现状`)
  }
  const names = []
  if (sourceState === 'dir') {
    for (const name of readdirSync(source).sort()) {
      if (name === '.gitkeep') continue
      const path = join(source, name)
      if (!realDirectory(path) || readTextFile(join(path, 'SKILL.md')) === null) {
        issue(`.agents/skills/${name}`, '不是可读的 Skill 目录（需目录及 SKILL.md）')
      } else names.push(name)
    }
  }
  result.sourceSkills = names
  if (state === 'absent') return result
  if (state === 'symlink') {
    const actual = realDirectory(destination)
    const expected = realDirectory(source)
    if (actual && expected && actual === expected) {
      result.valid = names
      result.equivalent = result.issues.length === 0
    } else {
      issue('.claude/skills', `整目录链接未解析到事实源（链接值 ${readLinkTarget(destination)}）`)
    }
    return result
  }
  if (state !== 'dir') {
    result.layout = 'invalid'
    issue('.claude/skills', `入口不是目录或链接（${state}）`)
    return result
  }
  for (const name of names) {
    const path = join(destination, name)
    const itemState = pathState(path)
    if (itemState === 'absent') result.missing.push(name)
    else if (itemState !== 'symlink') issue(`.claude/skills/${name}`, `同名项是实际内容（${itemState}），保留`)
    else if (!realDirectory(path)) issue(`.claude/skills/${name}`, '断链、循环或目标不是目录，保留')
    else if (realDirectory(path) !== realDirectory(join(source, name))) issue(`.claude/skills/${name}`, `链接目标错误（${readLinkTarget(path)}），保留`)
    else result.valid.push(name)
  }
  for (const name of readdirSync(destination).sort()) {
    if (!names.includes(name)) issue(`.claude/skills/${name}`, `事实源无对应 Skill 的额外项（${pathState(join(destination, name))}），保留`)
  }
  result.equivalent = sourceState === 'dir' && result.missing.length === 0 && result.issues.length === 0
  return result
}

/** 路径现状。断链软链 existsSync 会返回 false，所以必须先 lstat。 */
function pathState(path) {
  try {
    const stat = lstatSync(path)
    if (stat.isSymbolicLink()) return 'symlink'
    if (stat.isDirectory()) return 'dir'
    if (stat.isFile()) return 'file'
    return 'other'
  } catch {
    return 'absent'
  }
}

/** AGENTS.md 骨架：段落顺序按「命令优先」，内容一律标 [待确认]，不编造命令 */
const AGENTS_MD_LINES = [
  '# AGENTS.md',
  '',
  '本文件保留项目常驻边界与任务路由；领域细节引用既有事实源，按任务加载。',
  '',
  '## 项目概览',
  '',
  '[待确认] 项目做什么、给谁用、当前阶段。一到三句话，不要抄 README。',
  '',
  '## 命令',
  '',
  '[待确认] 从实际配置或用户选择填写命令与来源；探测到和执行通过分开标注。',
  '',
  '| 用途 | 命令 | 来源与验证状态 |',
  '| --- | --- | --- |',
  '| [待确认] | [待确认] | [待确认] |',
  '',
  '## 任务路由',
  '',
  '[待确认] 写明哪类任务读取哪个现有 Skill / reference，使用可达路径。无独立任务域时省略。',
  '',
  '## 常驻边界',
  '',
  '[待确认] 按项目真实约定写修改范围、生成物事实源、验证和交付边界；无依据的禁区不填。',
  '',
  '---',
  '',
  '<!-- 本文件由 gh-project-initialization 生成骨架。「[待确认]」处需按项目实际情况填实：',
  '     写成命令式的具体动作，不要写成偏好陈述。 -->',
]

/** CLAUDE.md：Claude Code 支持 @ 导入，用一行指针引用，不复制正文 */
const CLAUDE_MD_LINES = ['@AGENTS.md']

/** Cursor 规则：规则正文在 AGENTS.md，这里只做确定性指路 */
const CURSOR_RULE_LINES = [
  '---',
  'description: 项目 AI 规则入口 —— 规则正文在仓库根目录的 AGENTS.md',
  'alwaysApply: true',
  '---',
  '',
  '本项目的 AI agent 规则入口为仓库根目录 `AGENTS.md`，先读常驻边界，再按任务路由读取相关规则。',
]

/**
 * 算出全部动作及其状态，不碰磁盘。
 * 返回 { root, apply, detected, actions }。
 */
export function planActions(root, { apply = false, workbuddy = false } = {}) {
  const actions = []
  const add = (action) => actions.push(action)

  // --- 规则入口 ---
  const agentsMd = join(root, 'AGENTS.md')
  const agentsState = pathState(agentsMd)
  add({
    id: 'agents-md',
    path: 'AGENTS.md',
    kind: 'file',
    status: agentsState === 'absent' ? (apply ? 'created' : 'will-create') : readTextFile(agentsMd) !== null ? 'skipped' : 'conflict',
    note:
      agentsState === 'absent'
        ? '生成骨架，正文带 [待确认] 标记，需探测项目后填实'
        : `已存在（${agentsState}），脚本不覆盖；${readTextFile(agentsMd) !== null ? '规则内容及任务路由仍需检查' : '不是可读规则文件，需处理冲突'}`,
    write: agentsState === 'absent' ? 'text' : null,
    content: agentsState === 'absent' ? `${AGENTS_MD_LINES.join('\n')}\n` : null,
  })

  const claudeMd = join(root, 'CLAUDE.md')
  const claudeState = pathState(claudeMd)
  add({
    id: 'claude-md',
    path: 'CLAUDE.md',
    kind: 'file',
    status: claudeState === 'absent' ? (apply ? 'created' : 'will-create') : readTextFile(claudeMd) !== null ? 'skipped' : 'conflict',
    note:
      claudeState === 'absent'
        ? 'Claude Code 入口，用 @AGENTS.md 导入，正文不重复'
        : `已存在（${claudeState}），不覆盖；${readTextFile(claudeMd) !== null ? '仍需检查引用与自定义内容' : '不是可读规则文件，需处理冲突'}`,
    write: claudeState === 'absent' ? 'text' : null,
    content: claudeState === 'absent' ? `${CLAUDE_MD_LINES.join('\n')}\n` : null,
  })

  const cursorRule = join(root, '.cursor', 'rules', 'project.mdc')
  const cursorState = pathState(cursorRule)
  add({
    id: 'cursor-rule',
    path: '.cursor/rules/project.mdc',
    kind: 'file',
    status: cursorState === 'absent' ? (apply ? 'created' : 'will-create') : readTextFile(cursorRule) !== null ? 'skipped' : 'conflict',
    note:
      cursorState === 'absent'
        ? 'Cursor 规则入口，指向 AGENTS.md 的常驻边界与任务路由'
        : `已存在（${cursorState}），不覆盖；${readTextFile(cursorRule) !== null ? '仍需检查引用与自定义内容' : '不是可读规则文件，需处理冲突'}`,
    write: cursorState === 'absent' ? 'text' : null,
    content: cursorState === 'absent' ? `${CURSOR_RULE_LINES.join('\n')}\n` : null,
  })

  // --- skill 落脚点 ---
  const agentsSkillsDir = join(root, '.agents', 'skills')
  const agentsSkillsState = pathState(agentsSkillsDir)
  let asWrite = null
  let asStatus = 'skipped'
  let asNote = '已存在，不覆盖'
  if (agentsSkillsState === 'absent') {
    asWrite = 'dir-with-keep'
    asStatus = apply ? 'created' : 'will-create'
    asNote = '共享 Skill 事实源目录，放 .gitkeep 占位'
  } else if (agentsSkillsState === 'dir' && needsKeep(agentsSkillsDir)) {
    // 目录已经在了但空着又没占位文件：git 里这个目录等于不存在，团队 clone 拿不到
    asWrite = 'keep-only'
    asStatus = apply ? 'updated' : 'will-update'
    asNote = '目录已存在但为空且无占位文件，补 .gitkeep（否则该目录在 git 里丢失）'
  } else if (agentsSkillsState !== 'dir') {
    asStatus = 'conflict'
    asNote = `已存在但不是目录（${agentsSkillsState}）—— 不覆盖也不建软链，需人工处理`
  }
  add({
    id: 'agents-skills',
    path: '.agents/skills/',
    kind: 'dir',
    status: asStatus,
    note: asNote,
    write: asWrite,
    target: agentsSkillsDir,
  })

  const skillLayout = inspectSkillLayout(root)
  const shouldLink = skillLayout.layout === 'missing' && asStatus !== 'conflict' && skillLayout.issues.length === 0
  const linkStatus = skillLayout.issues.length > 0 ? 'conflict' : shouldLink ? (apply ? 'created' : 'will-create') : 'skipped'
  add({
    id: 'claude-skills-link',
    path: '.claude/skills',
    kind: skillLayout.layout === 'item-links' ? 'dir' : 'symlink',
    status: linkStatus,
    note: skillLayout.issues.length > 0
      ? skillLayout.issues.map((item) => `${item.path}: ${item.reason}`).join('；')
      : shouldLink ? '新建指向 .agents/skills 的整目录链接'
        : skillLayout.prerequisites.length > 0 ? '保留现有逐项目录；事实源补齐后再复查等价性'
        : `${skillLayout.layout}：已核对真实目标；有效 ${skillLayout.valid.length}，缺失 ${skillLayout.missing.length}，保留布局`,
    write: shouldLink ? 'symlink' : null,
    target: agentsSkillsDir,
  })
  // 逐项布局只补不存在的入口；已有坏链接和实际内容均保留，即使其他项可安全补齐。
  if (skillLayout.layout === 'item-links' && asStatus !== 'conflict') {
    for (const name of skillLayout.missing) add({
      id: `claude-skill-${name}`,
      path: `.claude/skills/${name}`,
      kind: 'symlink',
      status: apply ? 'created' : 'will-create',
      note: '补缺失的逐项链接，不替换已有项',
      write: 'symlink',
      target: join(agentsSkillsDir, name),
    })
  }

  // --- 工程配套 ---
  const gitignorePath = join(root, '.gitignore')
  const gitignoreState = pathState(gitignorePath)
  const ignoreContent = managedLines(skillLayout).join('\n')
  // 同软链：写入与否用独立布尔量判断，status 只负责展示。
  let shouldWriteIgnore = false
  let ignoreStatus = 'will-create'
  let ignoreNote = '创建并把受管区块写进去'
  if (gitignoreState === 'file') {
    const text = readTextFile(gitignorePath)
    if (text === null) {
      ignoreStatus = 'conflict'
      ignoreNote = '存在但读不到（权限或竞态）—— 不写入，需人工处理'
    } else {
      const markers = managedMarkers(text)
      if (markers.invalid) {
        ignoreStatus = 'conflict'
        ignoreNote = '受管区块标记缺失、重复或顺序错误——保留原文件，需人工处理'
      } else if (markers.present && extractManagedBlock(text) === ignoreContent) {
        ignoreStatus = 'skipped'
        ignoreNote = '受管区块已是最新'
      } else if (markers.present) {
        shouldWriteIgnore = true
        ignoreStatus = 'will-update'
        ignoreNote = '受管区块内容过时，整体替换（区块外内容不动）'
      } else {
        shouldWriteIgnore = true
        ignoreStatus = 'will-update'
        ignoreNote = '追加受管区块（现有内容不动）'
      }
    }
  } else if (gitignoreState === 'dir' || gitignoreState === 'symlink') {
    ignoreStatus = 'conflict'
    ignoreNote = `.gitignore 是${gitignoreState === 'dir' ? '目录' : '软链'}，需人工处理`
  } else {
    shouldWriteIgnore = true
  }
  if (shouldWriteIgnore && apply) {
    ignoreStatus = ignoreStatus === 'will-create' ? 'created' : 'updated'
  }
  add({
    id: 'gitignore',
    path: '.gitignore',
    kind: 'file',
    status: ignoreStatus,
    note: ignoreNote,
    write: shouldWriteIgnore ? 'gitignore' : null,
    content: ignoreContent,
  })

  const workbuddyMemory = join(root, '.workbuddy', 'memory')
  const wbState = pathState(workbuddyMemory)
  const useWorkbuddy = workbuddy || pathState(join(root, '.workbuddy')) === 'dir'
  add({
    id: 'workbuddy-memory',
    path: '.workbuddy/memory/',
    kind: 'dir',
    status: useWorkbuddy && wbState === 'absent' ? (apply ? 'created' : 'will-create') : 'skipped',
    note:
      !useWorkbuddy
        ? '未启用 WorkBuddy，跳过；使用时传入 --workbuddy'
        : wbState === 'absent'
          ? '本地工作记忆目录（已在 .gitignore 里忽略）'
          : '已存在，不覆盖',
    write: useWorkbuddy && wbState === 'absent' ? 'dir' : null,
    target: workbuddyMemory,
  })

  const knowledgeDir = join(root, 'docs', 'knowledge')
  const existingKnowledge = KNOWLEDGE_DIRS.find((dir) => realDirectory(join(root, dir)))
  const knowledgeState = pathState(knowledgeDir)
  let knowledgeStatus = 'skipped'
  let knowledgeNote = '项目已有其他知识目录，不新建平行结构'
  let knowledgeWrite = null
  if (existingKnowledge && resolve(join(root, existingKnowledge)) !== knowledgeDir) {
    knowledgeNote = `已有 ${existingKnowledge}，不新建平行结构`
  } else if (knowledgeState === 'absent') {
    knowledgeStatus = apply ? 'created' : 'will-create'
    knowledgeNote = '知识归档落点，放 .gitkeep 占位'
    knowledgeWrite = 'dir-with-keep'
  } else if (knowledgeState === 'dir' && needsKeep(knowledgeDir)) {
    knowledgeStatus = apply ? 'updated' : 'will-update'
    knowledgeNote = '目录已存在但为空且无占位文件，补 .gitkeep（否则该目录在 git 里丢失）'
    knowledgeWrite = 'keep-only'
  } else if (!realDirectory(knowledgeDir)) {
    knowledgeStatus = 'conflict'
    knowledgeNote = `已存在但不是有效知识目录（${knowledgeState}），保留`
  } else {
    knowledgeNote = '已存在'
  }
  add({
    id: 'docs-knowledge',
    path: 'docs/knowledge/',
    kind: 'dir',
    status: knowledgeStatus,
    note: knowledgeNote,
    write: knowledgeWrite,
    target: knowledgeDir,
  })

  for (const action of actions) {
    if (!action.write) continue
    let parent = dirname(join(root, action.path.replace(/\/$/, '')))
    while (parent !== root && parent.startsWith(`${root}${sep}`)) {
      const state = pathState(parent)
      if (state !== 'dir' && state !== 'absent') {
        action.status = 'conflict'
        action.note = `父路径 ${relative(root, parent)} 是 ${state}，保留现状，未安排写入`
        action.write = null
        break
      }
      parent = dirname(parent)
    }
  }
  if (actions.find((action) => action.id === 'agents-skills').status === 'conflict') {
    for (const action of actions) {
      if (action.write !== 'symlink') continue
      action.status = 'conflict'
      action.note = '共享事实源的补缺被冲突阻止，不新建依赖它的链接'
      action.write = null
    }
  }
  return { root, apply, detected: detectProject(root), skillLayout, actions }
}

/** 空目录且在 git 里没有占位文件时，需要补 .gitkeep；有内容或有占位文件都不需要 */
function needsKeep(dir) {
  if (existsSync(join(dir, '.gitkeep'))) return false
  try {
    return readdirSync(dir).length === 0
  } catch {
    return false
  }
}

function readLinkTarget(path) {
  try {
    return readlinkSync(path)
  } catch {
    return null
  }
}

/** 读文本文件，失败时返回 null（权限、编码、竞态都归为「读不到」） */
function readTextFile(path) {
  try {
    return readFileSync(path, 'utf8')
  } catch {
    return null
  }
}

/** 只接受独占整行的一对有序标记；异常边界不能安全替换。 */
function managedMarkers(text) {
  const lines = [...text.matchAll(/^# (?:>>> project-ai-init >>>|<<< project-ai-init <<<)\r?$/gm)]
  if (lines.length === 0) return { present: false, invalid: false }
  const valid = lines.length === 2 && lines[0][0].replace(/\r$/, '') === MANAGED_BEGIN && lines[1][0].replace(/\r$/, '') === MANAGED_END
  return { present: valid, invalid: !valid, start: lines[0].index, end: valid ? lines[1].index + MANAGED_END.length : undefined }
}

/** 取出受管区块（含标记行）；没有则返回空串 */
function extractManagedBlock(text) {
  const markers = managedMarkers(text)
  return markers.present ? text.slice(markers.start, markers.end) : ''
}

/** 写盘。只处理 write 字段非 null 的动作。 */
function applyActions(planned) {
  const failures = []
  for (const action of planned.actions) {
    if (!action.write) continue
    const abs = join(planned.root, action.path)
    try {
      if (action.write === 'text') {
        mkdirSync(dirname(abs), { recursive: true })
        writeFileSync(abs, action.content, { flag: 'wx' })
      } else if (action.write === 'dir') {
        mkdirSync(abs, { recursive: true })
      } else if (action.write === 'dir-with-keep') {
        mkdirSync(abs, { recursive: true })
        const keep = join(abs, '.gitkeep')
        if (pathState(keep) === 'absent') writeFileSync(keep, '', { flag: 'wx' })
      } else if (action.write === 'keep-only') {
        writeFileSync(join(abs, '.gitkeep'), '', { flag: 'wx' })
      } else if (action.write === 'gitignore') {
        const current = existsSync(abs) ? readFileSync(abs, 'utf8') : ''
        writeFileSync(abs, mergeGitignore(current, action.content))
      } else if (action.write === 'symlink') {
        if (!realDirectory(action.target)) {
          const dependencyFailed = planned.actions.some((dependency) => dependency.status === 'failed' && resolve(planned.root, dependency.path) === action.target)
          if (dependencyFailed) {
            action.status = 'skipped'
            action.note = '依赖目标目录创建失败，跳过链接；独立动作继续'
            continue
          }
          throw new Error(`链接目标不是可用目录，未创建链接：${action.target}`)
        }
        mkdirSync(dirname(abs), { recursive: true })
        createDirLink(action.target, abs)
      }
    } catch (error) {
      action.status = 'failed'
      action.note = `写入失败：${error.message}`
      failures.push(action.path)
    }
  }
  return failures
}

/** 把受管区块并入 .gitignore：已有区块整体替换，没有则追加；区块外一个字节不动 */
export function mergeGitignore(current, block) {
  const markers = managedMarkers(current)
  if (markers.invalid) throw new Error('受管区块标记缺失、重复或顺序错误')
  if (markers.present) {
    return current.slice(0, markers.start) + block + current.slice(markers.end)
  }
  if (current === '') return `${block}\n`
  const separator = current.endsWith('\n') ? '\n' : '\n\n'
  return `${current}${separator}${block}\n`
}

/** 相对软链便于整个项目目录移动；Windows 的 junction 只接受绝对路径。 */
function createDirLink(targetAbs, linkPath) {
  if (process.platform === 'win32') {
    symlinkSync(targetAbs, linkPath, 'junction')
  } else {
    symlinkSync(relative(dirname(linkPath), targetAbs), linkPath, 'dir')
  }
}

function formatHuman(result) {
  const lines = []
  lines.push(`目标项目：${result.root}`)
  const detected = result.detected
  if (detected.ecosystem) {
    lines.push(`探测到：${detected.ecosystem}（依据 ${detected.markers.join('、')}）`)
    for (const cmd of detected.commands) {
      lines.push(`  - ${cmd.purpose}: ${cmd.command}   [来源 ${cmd.source}]`)
    }
    for (const cmd of detected.commandCandidates) {
      lines.push(`  - 待核实候选 ${cmd.purpose}: ${cmd.command}   [来源 ${cmd.source}]`)
    }
    if (detected.commands.length === 0) {
      lines.push('  （未从配置里提取到可用命令，需人工确认）')
    }
  } else {
    lines.push(detected.projectState === 'empty'
      ? '探测到：空目录，项目选择与命令待确认'
      : '探测到：已有内容但无已知项目标记，需读取实际配置与规则，不能按空项目处理')
  }
  lines.push('')
  lines.push(result.apply ? '执行结果：' : '计划（未写盘，加 --apply 执行）：')
  for (const action of result.actions) {
    lines.push(`  [${action.status}] ${action.path} — ${action.note}`)
  }
  const summary = summarize(result.actions)
  lines.push('')
  lines.push(
    `合计：新建 ${summary.create}，更新 ${summary.update}，跳过 ${summary.skip}，冲突 ${summary.conflict}，失败 ${summary.failed}`,
  )
  if (!result.apply && summary.create + summary.update > 0) {
    lines.push('写入计划已获授权时，重跑并加 --apply；否则先展示计划取得授权。')
  }
  return lines.join('\n')
}

function summarize(actions) {
  const count = (list) => actions.filter((a) => list.includes(a.status)).length
  return {
    create: count(['will-create', 'created']),
    update: count(['will-update', 'updated']),
    skip: count(['skipped']),
    conflict: count(['conflict']),
    failed: count(['failed']),
  }
}

function printHelp() {
  console.log(
    [
      '用法：node init.mjs [--root <path>] [--workbuddy] [--json] [--apply]',
      '',
      '给目标项目铺 AI 地基：AGENTS.md 骨架、CLAUDE.md 指针、.agents/skills/、',
      '.claude/skills 软链、Cursor 规则、.gitignore 受管区块、可选 .workbuddy/memory/、',
      'docs/knowledge/（仅在项目无等价知识目录时）。',
      '',
      '默认 --root 为当前工作目录；默认 dry-run，加 --apply 才写盘。',
      '仅 --workbuddy 或已有 .workbuddy/ 目录时创建 WorkBuddy memory。',
      '支持整目录链接与有效逐项链接，核对实际目标；仅补缺，冲突保留。',
      '脚本不覆盖已有规则；规则内容检查与加载路径走读由 agent 完成。',
      '加 --json 输出机器可读结果，供 agent 解析。',
      '退出码：0 无冲突/失败（含正常跳过），1 冲突或局部写入失败，2 参数或目标根错误。',
    ].join('\n'),
  )
}

export function main(argv = process.argv.slice(2), cwd = process.cwd()) {
  const options = { root: cwd, apply: false, json: false, workbuddy: false }
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i]
    if (arg === '--apply') options.apply = true
    else if (arg === '--workbuddy') options.workbuddy = true
    else if (arg === '--json') options.json = true
    else if (arg === '--help' || arg === '-h') {
      printHelp()
      return 0
    } else if (arg === '--root') {
      const value = argv[i + 1]
      if (value === undefined || value.startsWith('-')) {
        console.error('error --root 需要一个路径参数')
        return 2
      }
      options.root = resolve(cwd, value)
      i += 1
    } else {
      console.error(`error 未知参数：${arg}`)
      console.error('运行 node init.mjs --help 查看用法。')
      return 2
    }
  }

  const root = resolve(options.root)
  if (!existsSync(root)) {
    console.error(`error 目标目录不存在：${root}`)
    return 2
  }
  // --root 指向文件时，后续 join 出来的路径全是垃圾，必须在写盘前拦掉
  if (!statSync(root).isDirectory()) {
    console.error(`error 目标不是目录：${root}`)
    return 2
  }

  const result = planActions(root, { apply: options.apply, workbuddy: options.workbuddy })
  const failures = options.apply ? applyActions(result) : []
  if (options.apply) result.skillLayoutAfter = inspectSkillLayout(root)

  if (options.json) {
    console.log(JSON.stringify({ ...result, summary: summarize(result.actions) }, null, 2))
  } else {
    console.log(formatHuman(result))
  }

  const summary = summarize(result.actions)
  if (failures.length > 0 || summary.conflict > 0) {
    if (!options.json) {
      console.error(
        `\n注意：${summary.conflict} 处冲突、${failures.length} 处写入失败，需要人工处理，未做任何覆盖。`,
      )
    }
    return 1
  }
  return 0
}

// 用 realpath 比较：脚本可能经软链入口被调用，resolve 不会解析软链。
if (process.argv[1] && realpathSync(process.argv[1]) === fileURLToPath(import.meta.url)) {
  process.exit(main())
}
