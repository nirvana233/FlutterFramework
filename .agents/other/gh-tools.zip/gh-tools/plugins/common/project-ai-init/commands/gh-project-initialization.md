---
description: gh-project-initialization · 项目初始化
disable-model-invocation: true
argument-hint: "[项目根路径，默认为当前目录] [初始化或检查完善要求]"
---

按下列 Skill 正文处理请求。其中的相对引用以
`${CLAUDE_PLUGIN_ROOT}/skills/gh-project-initialization/` 为基准解析：

@${CLAUDE_PLUGIN_ROOT}/skills/gh-project-initialization/SKILL.md

用户请求：

$ARGUMENTS
