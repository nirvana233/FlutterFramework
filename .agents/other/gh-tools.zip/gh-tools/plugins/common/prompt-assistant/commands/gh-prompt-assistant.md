---
description: gh-prompt-assistant · 提示词补全
argument-hint: "[问题、需求、产品想法或待补全提示词]"
---

按下列 Skill 正文处理请求。其中的相对引用以
`${CLAUDE_PLUGIN_ROOT}/skills/gh-prompt-assistant/` 为基准解析：

@${CLAUDE_PLUGIN_ROOT}/skills/gh-prompt-assistant/SKILL.md

用户请求：

$ARGUMENTS
