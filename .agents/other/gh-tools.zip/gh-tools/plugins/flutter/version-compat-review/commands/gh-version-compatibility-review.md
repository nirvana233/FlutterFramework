---
description: gh-version-compatibility-review · 版本兼容审查
disable-model-invocation: true
argument-hint: "[可选：审查范围（commit / 模块目录），或要做设计核对的功能描述]"
---

按下列 Skill 正文处理范围或设计。其中的相对引用以
`${CLAUDE_PLUGIN_ROOT}/skills/gh-version-compatibility-review/` 为基准解析：

@${CLAUDE_PLUGIN_ROOT}/skills/gh-version-compatibility-review/SKILL.md

审查范围或功能设计：

$ARGUMENTS
