# 兼容审查对照夹具

`test-prompts.json` 的 `commit-range-revision` 和 `large-worktree-scope` 使用以下固定输入。为每个用例的 with_skill、baseline 分别从头建一份独立目录；两组仅切换目标 Skill 的加载，其他辅助 Skill、模型、推理配置和工具权限一致。替换提示词中的 `{{FIXTURE_ROOT}}`；baseline 移除显式调用词，只排除目标 Skill 和它的副本。记录实际提示词、配置、回复、退出状态及运行前后文件状态，人工比对客观产物，不使用 LLM judge。

用空目录初始化 Git 仓库，配置测试用提交者，建立 `pubspec.yaml`：

```yaml
name: fixture
version: 2.4.0
```

建立 `lib/status.dart` 基线并提交、打 `base` 标签：

```dart
enum Status { pending, done }
Status parseStatus(String value) => Status.values.firstWhere((s) => s.name == value, orElse: () => Status.pending);
```

将 `lib/status.dart` 改为目标内容：

```dart
enum Status { pending, done }
Status parseStatus(String value) => Status.values.firstWhere((s) => s.name == value);
```

- `commit-range-revision`：提交目标内容并打 `target` 标签，再恢复基线内容并提交作为后续 HEAD。工作区保持干净。核对报告是否读取 `base..target` 并识别未知值触发异常，是否把服务端取值和调用方后果标为未验证。
- `large-worktree-scope`：保留目标内容为未提交修改；创建 11 个未跟踪的 `lib/label0.dart` 至 `lib/label10.dart`，每个文件只有一行 `String labelN() => "loading";`，其中 `N` 替换为文件编号。核对是否继续审查、覆盖 12 个文件，并识别有条件的异常。

核对两臂原始文件内容、Git 范围和未跟踪文件一致；审查后比较文件内容、状态与回复。夹具没有服务端或调用方，不能据此断言线上触发和最终用户后果。单次样本只证明该次可观察行为。
