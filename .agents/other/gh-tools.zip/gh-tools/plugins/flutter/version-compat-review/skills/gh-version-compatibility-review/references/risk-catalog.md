# Risk Catalog

`audit` 模式的扫描深度以 SKILL.md 的 Scan 规则为准：涉及持久化、接口、枚举或路由时执行完整 A-I；其它单点改动深入检查相关类别，其余在报告中说明不适用或未纳入原因。`design` 模式只读取与方案有关的类别。命令先收敛到审查范围，命中后必须阅读源码。以下 `git diff HEAD` 仅示例本地改动；其他范围按 [Audit workflow](audit-workflow.md) 使用选定的基线和目标版本。检索工具不可用时逐文件阅读确认，不能因工具缺失跳过应检查的类别。

| 类别 | 兼容轴 |
| --- | --- |
| A | 未完成入口与依赖闭环 |
| B | 接口字段、类型、必填性和语义 |
| C | 枚举和 type 分发 |
| D | 服务端下发展示与跳转 |
| E | 本地缓存和持久化 |
| F | 路由与深链 |
| G | 版本门控 |
| H | 跨版本共享用户态 |
| I | 重构丢失既有兜底 |

## A. Incomplete Entry

检查新增按钮、Tab、卡片和弹窗入口是否依赖尚未就位的资源、文案、路由、字段或开关：

```bash
rg -n --no-messages 'TODO|FIXME|待实现|暂未|先写死|临时' "$SRC" -g '*.dart'
rg -n --no-messages 'assets/[^"'"'"']*\$' "$SRC" -g '*.dart'
rg -n --no-messages "assets/.*\.(png|webp|svg|json)'" "$SRC" -g '*.dart' \
  | rg '\? |case |\['
```

逐个确认声明资源实际存在、入口线上可达、未知类型的终态以及服务端开关是否带版本维度。

- 有终态兜底但显示错图、原始 code 或空白：按实际用户后果判为中/高。
- 无兜底并抛异常或卡死：阻断。
- 候选方案：支持类型白名单、未知类型不渲染并上报、服务端 URL 配网络图兜底、入口按版本关闭。

## B. API Contract

检查 Model/DTO 字段增删改、类型变化、可选变必填、改名和语义变化：

```bash
rg -n --no-messages ' as int| as String| as List| as Map|int\.parse\(|double\.parse\(' \
  "$SRC" -g '*.dart' -g '!*.g.dart'
git diff HEAD -- '*/Model/*.dart' '*/model/*.dart' '*.g.dart'
```

新增未知 JSON key 通常安全，但新数据可能改变历史版本行为。确认生成文件同步，并优先复用项目已有 converter/null 兜底。

候选方案：新增字段替代原地改类型，旧字段保留兼容窗口；字段缺失有展示兜底；服务端只在确认版本上报存在时按版本返回结构。

## C. Enum and Dispatch

检查字符串转枚举、`switch(type)`、`type ==` 和其他分发点：

```bash
rg --pcre2 -n -U --no-messages \
  'firstWhere\((?:(?!orElse)[^;])*?\);' "$SRC" \
  -g '*.dart' -g '!*.g.dart' -o
rg -n --no-messages '\.byName\(|\.values\[' "$SRC" -g '*.dart' -g '!*.g.dart'
rg -n --no-messages 'switch \(|type ==|jumpType|actionType|linkType' "$SRC" -g '*.dart'
rg -n --no-messages 'fromString|fromValue|fromCode' "$SRC" -g '*.dart' -g '!*.g.dart'
```

区分安全忽略、静默错分支和异常。支付/订单链路中无 `orElse` 的 `firstWhere` 可能中断状态确认，按资损后果判级。

候选方案：显式 `unknown` / `case null`，未知值不渲染、不跳转或提示升级；解析层安全失败，调用方选择终态。

## D. Server-driven UI and Navigation

检查服务端下发的入口、类型、样式、资源和跳转目标：

```bash
rg -n --no-messages 'Get\.toNamed\(|Navigator\.(push|pushNamed)|pushNamed\(' \
  "$SRC" -g '*.dart'
```

沿统一配置入口确认老版本是否会收到新值，本地映射缺失时的表现，以及 route/icon/text 是否同版本存在。

候选方案：按版本过滤或携带 `minVersion`；下发历史版本可识别的降级目标；未知目标进入统一终态。

## E. Persistence

检查 Hive、SharedPreferences 和落盘 JSON：

```bash
rg -n --no-messages '@HiveField\(' "$SRC" -g '*.dart' -g '!*.g.dart'
rg -n --no-messages 'fields\[' "$SRC" -g '*.g.dart'
rg -n --no-messages 'final int typeId' "$SRC" -g '*.g.dart' \
  | rg -o 'typeId = \d+' | sort | uniq -c
git diff HEAD -- '*.g.dart'
```

对照源文件 `@HiveField` 与生成代码 `fields[n]`：新字段追加最大序号；检查 typeId 冲突、新旧版本轮流读写、降级安装以及同 key 换类型/语义。

候选方案：追加可空字段；破坏性变更使用新 typeId、box 或 key；读取不兼容缓存时安全丢弃该条并记录。

## F. Routes and Deep Links

检查新增 route、深链、分享/推送 payload 和历史版本落点：

```bash
rg -n --no-messages 'onGenerateRoute|onUnknownRoute' "$SRC" -g '*.dart'
rg -n --no-messages -A5 \
  'Route<dynamic>\? .*generateRoute|generateRoute\(' "$SRC" -g '*.dart'
```

确认未知 route 是静默无反应、可感知提示还是异常；解析返回 `null` 后调用方是否有终态。仅当前版本内的路由边界归 gh-review 的只初审模式，按项目选择 Flutter 专项。

候选方案：统一 unknown route/日志；解析层安全返回，调用方提示升级或安全降级；服务端只向支持版本投递目标。

## G. Version Gate

需要只对新版本生效的功能，检查实际门控能力：

```bash
rg -n --no-messages 'PackageInfo\.fromPlatform|packageInfo|buildNumber' \
  "$SRC" -g '*.dart'
rg -n --no-messages 'isVersionNeedUpdate|compareVersion|versionCompare|latestVersion' \
  "$SRC" -g '*.dart'
```

版本比对工具可能只用于升级提示，不能据此假定已有功能门控。报告实际先例与能力。

| 方式 | 回滚 | 适用 |
| --- | --- | --- |
| 服务端按上报版本下发 | 即时配置 | 有可靠版本上报的入口、样式、跳转 |
| 客户端最小版本 | 需要发版 | 后端无法感知的纯本地能力 |
| 灰度 / AB | 调整流量 | 分批放量；历史版本明确排除 |

无论选择哪种，都写清历史版本命中时是隐藏入口、提示升级还是异常。

## H. Shared User State

检查新旧版本轮流读写的订单、支付、登录/权益、阅读进度、收藏和埋点语义：

- 未知权益/等级按最低权限处理。
- 未知订单/支付状态回源查询，不由历史客户端本地判失败。
- 新版本写入时保留历史版本可读字段，新结构使用新增字段。
- 同名埋点语义变化会污染看板，使用新事件或参数名。

同时评估“历史版本读不懂”和“历史版本把状态写坏”；后者按数据完整性或资损判级。

## I. Fallback Regression

重构、搬迁或抽组件时，逐条对照删除行中的既有终态：

```bash
git diff HEAD -- '*.dart' | rg '^-' \
  | rg 'orElse|\?\?|default:|catch|== null|isEmpty|placeholder'
```

检查 null/default/catch、错误态/空态、统一跳转入口、阈值和布尔条件是否等价。删掉的兜底逐条说明为有意变更或漏搬；无法判断时列为“需确认”。
