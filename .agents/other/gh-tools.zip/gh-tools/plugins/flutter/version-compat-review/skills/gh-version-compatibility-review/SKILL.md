---
name: gh-version-compatibility-review
description: >
  Review Flutter changes or designs for compatibility between old and new app
  versions sharing a backend or persisted state. Use only when explicitly invoked
  for version compatibility review or 版本兼容审查. For current-version-only
  questions use gh-review in preliminary review mode instead.
disable-model-invocation: true
---

# gh-version-compatibility-review · 版本兼容审查

识别“新版本正常、历史版本出错”“新版本读坏旧状态”以及“本版本半成品被提前触发”的风险。产出可定位、可判级、可决策的报告，不直接修改实现。

## Mode

| 模式 | 输入 | 产出 |
| --- | --- | --- |
| `audit` | 本地 diff、commit 范围或模块 | 分级风险清单、未纳入项和待决策项 |
| `design` | 尚未实现的功能/接口/缓存/门控方案 | 九条兼容原则的逐项结论和关键设计选择 |

用户未说明模式时：有代码范围或没有参数都使用 `audit`（没有参数审查本地未提交、暂存和未跟踪改动）；只有方案描述使用 `design`。

## Audit

执行 `Scope -> Axis -> Scan -> Evidence -> Report -> Gate`：

1. **Scope**：读 [Audit workflow](references/audit-workflow.md)，定位项目坐标、Git 范围、未跟踪 Dart 文件和调试/GM 边界。
2. **Axis**：确认当前版本、仍需兼容的历史版本、共享后端/配置/持久状态。缺少线上最低版本时标为假设或待确认。
3. **Scan**：读 [Risk catalog](references/risk-catalog.md)，对 A-I 九类逐项检查；工作区或 diff 范围触及持久化、接口、枚举或路由时执行完整 A-I，单点改动只查相关类别、其余在“未纳入”中一行说明。检索只生成候选，风险结论来自实际源码和调用链。
4. **Evidence**：每条风险记录 `文件:行`、性质、触发、影响版本、后果、可行方案和待确认事实。服务端方案必须有项目坐标支持。
5. **Report**：按 [Report contract](references/report-contract.md) 判级。范围内每个文件归入风险或“未纳入”，九类未命中项也说明原因。
6. **Gate**：给出结论并等待开发者决策；审查本身停在报告，不修改文件。

## Design

1. 读 [Design principles](references/design-principles.md)，九条逐项写“如何满足 / 为什么不适用”。
2. 只读取 [Risk catalog](references/risk-catalog.md) 中与方案相关的类别，核对接口字段、枚举、入口、路由、缓存和共享状态；设计模式不运行审查检索命令。
3. 明确门控方式、历史版本命中后的行为、接口扩展方式和回滚路径；缺少后端或线上事实时列为决策项。
4. 输出设计结论并等待确认，不产出风险数量，也不进入代码实施。

## Evidence Rules

- 项目规则和当前源码优先；通用修复模式只在项目现有能力支持时作为候选。
- 观察、推断和未验证契约分开书写。不确定项使用“需确认”并给出能确认它的具体来源。
- 调试、GM 和内部预览代码默认不进入发布风险；确认线上可达时再纳入并说明入口。
- 严重级别由可复现后果决定：有终态兜底的错分支与无兜底异常分开判断。
- 范围外文件、真实后端、线上版本分布、设备和账号未验证时，明确保留边界。

## Done

- `audit`：项目坐标和版本轴有来源；A-I 全部有处置说明，按 Scan 的范围规则深入检查相关类别，其余说明不适用或未纳入原因；范围文件全部归属；每条风险可定位、可触发、可判级；报告停在决策 Gate。
- `design`：九条原则全部有结论；门控、未知值、持久化和回滚行为明确；关键假设与待决策项可验证。
- 两种模式都没有把 grep 命中当风险、把假设写成事实，或产生未经授权的文件修改。
