# Audit Workflow

> 意图优先：`$SRC` 指 app 源码根，默认为 `lib`；下文 `rg`/`git` 命令是意图示例，在工作区用等效检索与改动查看方式执行，不改变检查意图。

代码审查模式按 `Scope -> Axis -> Scan` 建立证据基础。

## Project Coordinates

先读取项目规则并确定源码根：

```bash
SRC=lib
```

多 package 仓库使用实际 app package 的源码根。按需定位下列角色，并把实际路径写入报告；不存在时写“本项目无此角色”及其影响。

| 角色 | 探测方式 |
| --- | --- |
| 包版本声明 | `rg -n '^version:' pubspec.yaml` |
| 版本上报处 | `rg -n --no-messages 'version|appVersion|buildNumber' "$SRC" -g '*.dart' | rg -i 'header|interceptor|request'` |
| 统一配置入口 | `rg -ln --no-messages 'class .*Config(Mgr|Manager|Model|Result)' "$SRC" -g '*.dart'` |
| 版本比对工具 | `rg -n --no-messages 'PackageInfo|packageInfo|isVersion|needUpdate|compareVersion' "$SRC" -g '*.dart'` |
| 路由表 | `rg -ln --no-messages 'onGenerateRoute|generateRoute|GetPage\(' "$SRC" -g '*.dart'` |
| 深链解析 | `rg -ln --no-messages -i 'deeplink|applink|universallink|uni_links' "$SRC" -g '*.dart'` |
| 容错解析 | `rg -ln --no-messages 'FromJson|JsonConverter|@JsonKey\(' "$SRC" -g '*.dart' -g '!*.g.dart'` |
| 持久化层 | `rg -ln --no-messages '@HiveField|SharedPreferences|getApplicationDocumentsDirectory' "$SRC" -g '*.dart' -g '!*.g.dart'` |
| 网络图片兜底 | `rg -ln --no-messages 'CachedNetworkImage|Image\.network|errorWidget|placeholder' "$SRC" -g '*.dart'` |
| 调试 / GM 目录 | `rg --files "$SRC" | rg -i '(^|/)(debug|gm|devtool)(/|$)'` |

再找 2-3 个项目已有的容错范式，方案优先复用它们：

```bash
rg -n --no-messages 'orElse:|@JsonKey\(defaultValue' "$SRC" \
  -g '*.dart' -g '!*.g.dart' | head -20
rg -n --no-messages 'required (int|String|bool|double) ' "$SRC" \
  -g '*.dart' -g '!*.g.dart' | head -10
```

## Scope

用户指定范围优先；未指定时审查全部本地改动，记录范围摘要与文件计数后继续。只有范围或基线无法确定且会改变审查结果时才询问。

```bash
git status --short
git diff HEAD --stat
git diff HEAD
git ls-files --others --exclude-standard -- '*.dart'
```

指定 commit 或范围：

```bash
git show --stat --name-status <sha>
git diff <base>..<head>
```

`git diff HEAD` 包含暂存和未暂存改动，但不包含未跟踪文件；两者都必须进入范围。模块审查按整个模块读取，不局限于 diff。

先固定本次范围和基线；下文风险目录中涉及 `git diff HEAD` 的示例只适用于本地改动。commit、commit 区间或模块审查须替换为对应范围，读取目标版本的源码及必要的旧版源码；不能用当前工作区的内容代替所选版本。新增、删除、重命名和非 Dart 配置或资源也计入文件归属，按其与兼容风险的关联检查。

## Search Discipline

先取得范围内未删除的 Dart 文件，再逐文件检索：

```bash
git diff HEAD --name-only --diff-filter=d -- '*.dart' \
  | while IFS= read -r f; do
      rg -n -H --no-messages 'TODO|FIXME' "$f"
    done
```

范围为空时循环不会退化成全仓库扫描，`-H` 保留文件名。对多行调用判断“缺少某分支”时使用整块匹配，不用逐行反向过滤：

```bash
rg --pcre2 -n -U --no-messages \
  'firstWhere\((?:(?!orElse)[^;])*?\);' "$SRC" \
  -g '*.dart' -g '!*.g.dart' -o
```

所有命中都要打开源码确认可达性、调用方和终态；注释、测试桩、废弃代码和 grep 命中本身不构成风险。

## Version Axis

报告开头明确：

| 项 | 来源 |
| --- | --- |
| 当前包版本 | app 壳 `pubspec.yaml` |
| 需兼容历史版本 | 用户指定；未指定时以上一个已发布版本为审查假设 |
| 服务端/配置侧 | 接口字段、统一配置、灰度或其他共享状态入口 |

```bash
rg -n '^version:' pubspec.yaml
git log -p --format='COMMIT %h %ad' --date=short -- pubspec.yaml \
  | rg '^COMMIT|^\+version:' | rg -B1 '^\+version:' | head -30
```

版本变更 commit 只是近似时间，不等于商店上架时间。线上最低版本无法从仓库确认时，报告“需确认：线上仍在服务的最低版本”。

只有实际找到版本上报链路时，才把“服务端按版本下发”列为可行方案；否则选择客户端门控或把后端能力列为前置条件。
