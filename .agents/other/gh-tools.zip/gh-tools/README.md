# gh-tools

个人工具与自建 agent skill 的插件市场，供团队内部安装使用。插件市场主要支持 **Claude Code** 和 **Codex**；刷新工具另支持 WorkBuddy / CodeBuddy，以及 Cursor / OpenCode / Kiro 的 skills 同步。

仓库同时是一个多平台 plugin marketplace（`.claude-plugin/marketplace.json` + `.agents/plugins/marketplace.json`）和一个个人命令行工具集（`tools/`）。两者互不干扰：市场只认根目录那两个清单文件，其余目录它不管。两个清单里只有 `.claude-plugin/` 那份手写，Codex 读的那份由生成器产出（见「安装文档」）。

## 插件清单

|安装名 / Skill 调用名|显示名|领域|说明|
|---|---|---|---|
|`gh-version-compatibility-review`|gh-version-compatibility-review · 版本兼容审查|flutter|多版本客户端共存下的兼容性风险审查（提前埋的入口、接口/枚举/Model 变更、缓存结构、版本门控）。**仅手动触发**：`/gh-version-compatibility-review:gh-version-compatibility-review`（Claude Code）/ `$gh-version-compatibility-review`（Codex）|
|`gh-prompt-assistant`|gh-prompt-assistant · 提示词补全|common|结合上下文补全用户原意，默认交付可直接发给 AI 的提示词；能力推荐与已授权的后续执行按需处理。显式入口：`/gh-prompt-assistant:gh-prompt-assistant`（Claude Code）/ `$gh-prompt-assistant`（Codex）。|
|`gh-project-initialization`|gh-project-initialization · 项目初始化|common|给一个新项目建出统一的 AI 地基：`AGENTS.md` 作唯一真相源，`CLAUDE.md` 与 Cursor 规则只做指针不复制正文，`.agents/skills/` 作跨客户端 skill 目录并软链给 Claude Code，外加 `.gitignore` 受管区块。命令从项目实际配置探测并逐条标注来源，取不到来源的一律留 `[待确认]`；不覆盖任何已有文件。**仅手动触发**：`/gh-project-initialization:gh-project-initialization`（Claude Code）/ `$gh-project-initialization`（Codex）|
|`gh-skill-optimizer`|gh-skill-optimizer · Skill 优化|common|按目标 Skill 的用途与实际反馈优化能力、流程和规则，保留有效基础与必要保护；依任务授权审阅或修改，用相关产物验证效果。调用名为 `gh-skill-optimizer`。|
|`gh-workflow`|gh-workflow · 开发工作流|common|项目感知的标准开发流程：需求、计划、实现、验证、审阅、交付和知识归档分别核对结果，保留可恢复进度与证据。支持 guided/full-auto，复用已确认内容；标准及长任务默认用两份记录承载规格、计划与验收，复杂任务按需拆分。**手动触发**：`/gh-workflow:gh-workflow`（Claude Code）/ `$gh-workflow`（Codex）；执行范围沿用原任务授权。|
|`gh-subagents`|gh-subagents · 多代理协作|common|独立的协作规则权威源：分派、执行连续性、整合、返修与证据验收。显式入口：`/gh-subagents:gh-subagents`（Claude Code）/ `$gh-subagents`（Codex）；可被工作流按需加载，加载本身不要求创建子代理。|
|`gh-supervisor`|gh-supervisor · AI 监工|common|融合 Karpathy、HERO 与 STSS 的行为准则：改动聚焦需求，验证适度，表达直接，保留必要保护和真实限制。显式入口：`/gh-supervisor:gh-supervisor`（Claude Code 插件）/ `$gh-supervisor`（Codex）；支持按需自动调用，不修改已有 Karpathy 引用。|
|`gh-review`|gh-review · 代码审查|common|默认由当前 agent 只读初审，交付全部有证据的问题与真实缺口；Flutter 材料按需查阅。明确要求时复核已有结论、调用本地 Claude 或手动交接。**仅手动触发**：`/gh-review:gh-review`（Claude Code）/ `$gh-review`（Codex）。|

## 团队安装

`gh-review` 默认由当前 agent 审查当前改动，不要求先提供 Findings。指定功能时审查现有实现和相关调用链，无 diff 也可审查；明确限定“本次改动”时采用增量范围。源码保持只读，修复属于后续任务。

1. 普通审查：`$gh-review 审查当前改动`。有问题时询问一次是否交给 Claude 复核；无问题直接结束。明确“只初审”时不询问。
2. 两轮审查：`$gh-review 审查当前改动并用 Claude 复核`。先初审，有问题直接复核输入结论；本次任务已有授权时也不重复询问，不承诺独立查漏。
3. 只复核：`$gh-review Verify 已有 Findings`。仅核查输入问题是否成立，历史存在或不在 diff 不构成排除理由；独立标记本次引入、历史已存在或引入未确定，并附依据。

普通初审在短入口内完成并直接聊天交付，无需选择专项、整理 JSON 或运行展示脚本。需要 Flutter 约束时按所属 package 的依赖和调用链查阅材料。用户仍可指定“使用 flutter 专项”或“排除 flutter 专项”；交接时脚本校验和保存实际使用的规则。可选脚本需 Node.js 22+；Claude 复核另需 Git 与已认证的原生 Claude CLI。

目前只提供 Flutter 材料。[专项接口](plugins/common/review/skills/gh-review/references/profiles.md)保留适用条件、快照与后续接入要求。

所有插件的安装名、Skill 目录名和 frontmatter `name` 统一使用表格中的 `gh-` 完整名称。显示名使用“完整名称 · 中文说明”。Claude Code 按插件安装时使用 `/插件名:Skill名`，例如安装 `gh-supervisor@gh-tools` 后调用 `/gh-supervisor:gh-supervisor`；直接把 Skill 安装到 `~/.claude/skills/` 或项目的 `.claude/skills/` 时才使用 `/gh-supervisor`。这是 [Claude Code 的命名规则](https://code.claude.com/docs/en/skills#how-a-skill-gets-its-command-name)。Codex 使用 `$完整名称`；不注册简称或旧名称别名。已有安装需要在更新市场后移除旧插件、安装新的 `<完整名称>@gh-tools`，并替换个人启用配置；旧 `review@gh-tools` 改用 `gh-review@gh-tools`。更名不会自动迁移个人配置，OpenCode / Cursor / Kiro 需刷新 Skill 目录。

`gh-supervisor` 支持按需自动调用；需要默认遵循时，在项目规则中统一声明加载。本仓库由 [AGENTS.md](AGENTS.md) 引用 Skill 正文，Claude Code 通过 [CLAUDE.md](CLAUDE.md) 读取同一规则，无需在每次任务分派中重复说明。其他项目也需在自己的项目规则中声明加载已安装的 `gh-supervisor`。

`gh-subagents` 可单独安装（Claude Code：`claude plugin install gh-subagents@gh-tools`；Codex：在市场中启用 `gh-subagents`），也可将完整 Skill 目录安装到宿主的 skills 目录。它不依赖 `gh-workflow` 或 `gh-supervisor`。工作流仅在协作分支加载它，保留自己的阶段与状态要求；其他能力同样引用已安装 Skill 的实际位置或可访问的权威正文，不复制协作规则。只安装 `gh-workflow` 时，协作分支还需可访问的 `gh-subagents`；单代理主线照常可用。

`gh-subagents` 正文集中维护执行子代理的模型建议，包括 Codex / GPT、Claude 及 OpenCode、Cursor、Kiro 等宿主的适用方式；当前用户会话直接担任主代理，用户自己的模型与推理配置优先。项目和全局规则引用它，保留各自约束与个人覆盖配置。

### Claude Code

市场走 `source: "git"`，用你本机的 git 凭证拉取。凭证得是免交互的——Claude Code 在后台拉，弹不出输入框，没配好只会静默失败。用 SSH，或者 HTTPS 提前存一次密码：

```bash
git config --global credential.helper osxkeychain
git ls-remote https://doc-git.hmserver.club/gaohao/gh-tools.git   # 存一次，之后免密
```

走 SSH 的话把 `url` 换成 `git@doc-git.hmserver.club:gaohao/gh-tools.git`（合并进你自己的配置后再改——仓库里的片段是生成物）。

#### 合并配置

安装靠的是往你自己的 `~/.claude/settings.json` 里加两段配置。**这个文件是你的个人全局配置，我们不会替你改**——请自行合并，或者直接把下面这句话交给 AI 让它来做：

> 把 gh-tools 仓库里 `docs/settings-snippet.json` 的内容合并进我的 `~/.claude/settings.json`：
> `extraKnownMarketplaces` 和 `enabledPlugins` 两个 key 做增量合并，保留我已有的所有条目和其他字段，不要覆盖整个文件。

片段内容（也可直接手动抄）：

<!-- sync:begin claude-install-json -->
```json
{
  "extraKnownMarketplaces": {
    "gh-tools": {
      "source": {
        "source": "git",
        "url": "https://doc-git.hmserver.club/gaohao/gh-tools.git"
      }
    }
  },
  "enabledPlugins": {
    "gh-version-compatibility-review@gh-tools": true,
    "gh-prompt-assistant@gh-tools": true,
    "gh-project-initialization@gh-tools": true,
    "gh-skill-optimizer@gh-tools": true,
    "gh-workflow@gh-tools": true,
    "gh-subagents@gh-tools": true,
    "gh-supervisor@gh-tools": true,
    "gh-review@gh-tools": true
  }
}
```
<!-- sync:end claude-install-json -->

注意两点：

- `extraKnownMarketplaces` 的 key 必须是 `gh-tools`，不能改名——它要与 `marketplace.json` 里的 `name` 一致，否则整条配置会被忽略。
- `enabledPlugins` 是必需的。只注册市场不会自动安装插件，还得声明启用哪些，格式是 `<插件名>@gh-tools`。想装别的插件就往你自己的配置里加一行（下面这段是生成物，改仓库文件没用）。

合并后重启 Claude Code，用 `/plugin` 确认插件已出现。

也可以不改配置文件，直接命令行装（效果相同，会写进你的 user settings）：

<!-- sync:begin claude-install-cli -->
```bash
claude plugin marketplace add https://doc-git.hmserver.club/gaohao/gh-tools.git
claude plugin install gh-version-compatibility-review@gh-tools
claude plugin install gh-prompt-assistant@gh-tools
claude plugin install gh-project-initialization@gh-tools
claude plugin install gh-skill-optimizer@gh-tools
claude plugin install gh-workflow@gh-tools
claude plugin install gh-subagents@gh-tools
claude plugin install gh-supervisor@gh-tools
claude plugin install gh-review@gh-tools
```
<!-- sync:end claude-install-cli -->

#### 更新

市场跟随 git tag 发布。想升级到最新版本：

```bash
/plugin marketplace update gh-tools
```

---

### Codex

Codex 使用 TOML 配置文件 `~/.codex/config.toml`。参考 `docs/codex-config-snippet.toml` 进行合并，或直接交给 AI：

> 把 gh-tools 仓库里 `docs/codex-config-snippet.toml` 的内容合并进我的 `~/.codex/config.toml`：保留我已有的所有 `[marketplaces.*]` 和 `[plugins.*]` 条目，只增量添加 `gh-tools` 相关的配置，不要覆盖整个文件。

团队使用 git 源：

<!-- sync:begin codex-config-git -->
```toml
[marketplaces.gh-tools]
source_type = "git"
source = "https://doc-git.hmserver.club/gaohao/gh-tools.git"

[plugins."gh-version-compatibility-review@gh-tools"]
enabled = true

[plugins."gh-prompt-assistant@gh-tools"]
enabled = true

[plugins."gh-project-initialization@gh-tools"]
enabled = true

[plugins."gh-skill-optimizer@gh-tools"]
enabled = true

[plugins."gh-workflow@gh-tools"]
enabled = true

[plugins."gh-subagents@gh-tools"]
enabled = true

[plugins."gh-supervisor@gh-tools"]
enabled = true

[plugins."gh-review@gh-tools"]
enabled = true
```
<!-- sync:end codex-config-git -->

本地开发改用 local 源：`source_type` 换成 `local`、`source` 换成本仓库的绝对路径，`[plugins.*]` 段完全不变。`docs/codex-config-snippet.toml` 就是 local 版，可以直接照抄。

注意：

<!-- sync:begin codex-skill-names -->
- Codex 不支持自定义斜杠命令，通过 `$gh-version-compatibility-review` / `$gh-prompt-assistant` / `$gh-project-initialization` / `$gh-skill-optimizer` / `$gh-workflow` / `$gh-subagents` / `$gh-supervisor` / `$gh-review` 调用对应 skill
<!-- sync:end codex-skill-names -->
- 修改配置后需重启 Codex 或开启新对话线程
- Codex 本地迭代推荐 local 源：仓库已 clone 在本地时，Codex 直接读该目录，任何 skill 改动开新线程即生效，不用 push；只有要给团队分发或多机同步才用 git 源

---

### Cursor

Cursor 已有自己的 plugin 机制，但本仓库目前没有 `.cursor-plugin/plugin.json`，这里只接入
Agent Skills 目录扫描。仓库里的 `refresh-gh-tools` 工具会把所有 skill 软链到
`~/.cursor/skills/`（用户全局级）：

```bash
git clone https://doc-git.hmserver.club/gaohao/gh-tools.git   # 或复用已有 clone
refresh-gh-tools --cursor --apply                              # 需要 node；可先去掉 --apply 预览
```

注意：

- skill 名称即 `/` 手动调用的名字；`gh-version-compatibility-review` 带
  `disable-model-invocation: true`，在 Cursor 里同样只手动触发
- 更新：`git pull` 后重跑 `refresh-gh-tools --cursor --apply`；改 SKILL.md 无需重跑
- 脚本只动指向本仓库的软链，`~/.cursor/skills/` 下的其他内容不受影响
- skills 目录地址由脚本按平台自动解析：macOS/Linux 为 `/Users/<你>/.cursor/skills`，Windows 为 `C:\Users\<你>\.cursor\skills`（`%USERPROFILE%\.cursor\skills`），无需手配
- Windows 下自动改用 junction（目录连接）创建，无需「开发者模式」或管理员权限
- Cursor plugin、MCP 和 marketplace 安装不在当前工具范围内

## 本地开发

### Claude Code

把本仓库注册成 directory 源，一次即可：

<!-- sync:begin claude-install-cli-local -->
```bash
cd /path/to/gh-tools
claude plugin marketplace add ./
claude plugin install gh-version-compatibility-review@gh-tools
claude plugin install gh-prompt-assistant@gh-tools
claude plugin install gh-project-initialization@gh-tools
claude plugin install gh-skill-optimizer@gh-tools
claude plugin install gh-workflow@gh-tools
claude plugin install gh-subagents@gh-tools
claude plugin install gh-supervisor@gh-tools
claude plugin install gh-review@gh-tools
```
<!-- sync:end claude-install-cli-local -->

之后改 SKILL.md 刷新即生效，不需要 commit 或重装。

注意市场名固定为 `gh-tools`（取自 `marketplace.json` 的 `name`，不可自定义），所以本地 directory 源与团队的 git 源在同一台机器上不能共存——同名条目只有一个生效。你自己的机器保持 directory 源即可。

### Codex

编辑 `~/.codex/config.toml`，使用 local 源，绝对路径。完整片段见 [`docs/codex-config-snippet.toml`](docs/codex-config-snippet.toml)——那就是 local 版，把里面的用户名换成你自己的路径即可。

修改后在新对话线程中测试。

### 校验

改完之后跑校验：

```bash
node scripts/validate.mjs
```

它检查权威清单（`.claude-plugin/marketplace.json`）的结构、plugin.json 与清单的版本一致性、commands 路径是否存在、SKILL.md frontmatter 是否合规、skill 的 name 是否与目录名一致、agents/openai.yaml 是否存在、生成物是否与权威源同步（`.agents/plugins/marketplace.json` + `docs/` 两个片段 + 本文件的 5 个 `sync` 区块 + 清单条目和各 Codex plugin.json 的 `description`，逐字节比对）、本文件「插件清单」表格的插件名与顺序是否一致、skill 是否带 test-prompts.json。除语料外不一致都记为 error 并退出 1；缺语料只警告，不阻断。只读，不改文件。没配 CI，请在提交前自己跑。

改校验规则本身时，跑一遍回归——它把仓库树复制到临时目录当夹具，用负例验证新规则真的会拦（不碰真仓库）：

```bash
node --test scripts/validate.test.mjs
```

## 安装文档

`.agents/plugins/marketplace.json`、`docs/settings-snippet.json`、`docs/codex-config-snippet.toml`、本文件的 5 个 `<!-- sync:begin ... -->` 区块，以及**清单条目和各 `.codex-plugin/plugin.json` 里的 `description`**，**都是生成的**。权威源有两个：插件列表在 `.claude-plugin/marketplace.json`，每个插件怎么描述自己在它自己的 `.claude-plugin/plugin.json`——同一份内容不再有第二个手写点。

```bash
node scripts/sync-install-docs.mjs          # 预览差异，不写盘
node scripts/sync-install-docs.mjs --apply  # 写入
```

校验和生成器兼容 Windows 的 CRLF 与 macOS/Linux 的 LF。生成器更新既有文件时保留原换行格式，新文件默认使用 LF；只有换行差异时不会重写文件。

不要手改生成区（含 `.agents/plugins/marketplace.json` 和清单里的 `description`），会被下次生成覆盖，`validate.mjs` 也会拦下来。需要手写的只剩三处：各插件自己 `.claude-plugin/plugin.json` 里的 `description`（唯一来源，其余两处逐字复制它）；「插件清单」表格的说明文案（插件名与顺序由校验核对）——那是给人读的中文说明，没有机械来源；以及 Codex 侧独有的取值（`category` 对照、`policy`），集中在 `sync-install-docs.mjs` 顶部的常量里。

## 加一个新插件

1. 按领域建目录：`plugins/<common|flutter|web>/<插件名>/`
2. 写 `.claude-plugin/plugin.json` 和 `.codex-plugin/plugin.json`，`version` 必须等于 `marketplace.json` 里的 `metadata.version`（全仓库统一版本）；`description` 只在 Claude 那份里写一次，不要带平台调用语法（`/skill`、`$skill`），生成器会把它同步到清单和 Codex 那份
3. skill 放在 `skills/<skill 名>/SKILL.md`，目录名必须与 frontmatter 的 `name` 一致
4. 为每个 skill 创建 `agents/openai.yaml`（Codex 需要）
5. slash command 放在 `commands/<命令名>.md`（仅 Claude Code 支持），并在 `.claude-plugin/plugin.json` 的 `commands` 数组里声明
6. 在 `.claude-plugin/marketplace.json` 的 `plugins` 数组里登记，带上 `category`。`description` 那栏随便填——它是派生字段，下一步会用插件自己 `.claude-plugin/plugin.json` 的值覆盖掉它；Codex 读的那份清单也不用管，同样由下一步生成
7. 收尾两件事：跑 `node scripts/sync-install-docs.mjs --apply` 重新生成（`.agents/plugins/marketplace.json` + `docs/` 两个片段 + 本文件的 5 个 `sync` 区块 + 清单里的 description，不要手改）；给本文件的「插件清单」表格补一行说明，顺序与清单保持一致
8. 跑 `node scripts/validate.mjs`

所有插件与 Skill 使用 `gh-` 完整名称，安装 ID 为 `<完整名称>@gh-tools`；显示名保留完整名称并追加中文说明。

skill 正文写中文，frontmatter 的 `name` / `description` 写英文（触发匹配更稳），`description` 里中英触发词都列上——这个 `description` 属于 SKILL.md，和插件级 `plugin.json` 的 `description` 不是一回事（后者见上面第 2 步，由生成器同步到三处）。内容保持 agent-neutral，不要硬编码某个 agent 专有的工具名；`.claude-plugin/` 和 `.codex-plugin/` 只作为平台适配层。

## 发布

全仓库统一版本，所有插件跟随。

1. 改 `marketplace.json` 的 `metadata.version` 和所有 `plugin.json` 的 `version`
2. `node scripts/validate.mjs` 确认一致
3. commit 后按当前版本打 tag：`git tag v<version> && git push origin v<version>`（例如 `v0.1.2`）

## 更新已安装插件

Codex 在安装时保存插件快照。修改本地目录源或拉取新版本后，先刷新已安装的插件，再开启新对话线程；当前线程不会加载新版本。

本地开发或 Git marketplace 都可以直接使用统一刷新工具：

```bash
refresh-gh-tools --codex --apply
```

它会识别当前已安装且启用的插件；Git marketplace 会先刷新 snapshot，本地 marketplace 则保留工作区来源。手动操作仍可按以下方式执行：

```bash
codex plugin marketplace upgrade gh-tools
codex plugin remove gh-prompt-assistant@gh-tools
codex plugin add gh-prompt-assistant@gh-tools
```

用 `codex plugin list` 核对版本。Claude Code 使用 `claude plugin update gh-prompt-assistant@gh-tools`，然后重启 Claude Code。将 `gh-prompt-assistant` 换成要更新的插件名；只更新已安装的插件即可。

## 个人工具

见 [tools/README.md](tools/README.md)。简言之：`tools/` 放脚本源码，`link-bin.mjs` 在 `bin/` 生成命令入口（POSIX 软链、Windows `.cmd` shim）供 PATH 直接调用；想让 agent 主动调用则需额外写一个 skill 包装。

## 第三方 skill

本仓库不管第三方 skill。机器上那些来自 GitHub 的第三方 skill（superpowers、addyosmani、larksuite 等）由 [cc-switch](https://github.com/farion1231/cc-switch) 管理安装与更新，两套机制分开，避免争抢 `~/.claude/skills` 下的软链接。
