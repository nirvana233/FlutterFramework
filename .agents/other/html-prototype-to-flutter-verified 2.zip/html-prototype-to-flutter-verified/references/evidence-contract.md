# Prototype Evidence Contract

这是 `prototype_evidence.md` 的建议结构。表格里的稳定 ID 要被 `scenarios.json`、Flutter `Key`/`Semantics` 和截图文件名复用，避免只靠自然语言回放。

## 1. Run metadata

记录：原型根目录/URL、Flutter 根目录、run ID、reset 方法、locale、theme、确定性数据、浏览器和设备、原型基准 viewport、capture surface、开始时间和任何限制。`web/index.html` 若只是 Flutter 启动页，必须明确排除。

## 2. Page Inventory

| page_id | 页面名称 | 入口 | 层级/父页面 | 参数 | 是否可返回 | 证据 |
| --- | --- | --- | --- | --- | --- | --- |
| `home` | Home | App launch | root | none | n/a | URL/DOM/截图 |

`page_id` 表示页面语义，不表示某个截图。页面内不同的可见层、数据分支或交互结果要进入 State Matrix。

## 3. Route Graph

每条边使用：

`source_page → trigger_id → destination_page → transition_type`

`transition_type` 只能从真实行为记录：`push`、`replace`、`pop`、`tab-switch`、`nested-push`、`back` 或 `UNRESOLVED`。补充参数、动画/过渡、返回栈结果和证据。不要用普通 Page Route 代替 Dialog、Sheet 或 Drawer。

## 4. Overlay Graph

单独列出所有 Overlay：

| overlay_id | owner page/state | trigger_id | 类型 | 进入 | 关闭/返回 | 是否阻挡背景 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `settings-sheet` | `home/default` | `settings` | BottomSheet | present | drag / close | yes | DOM + capture |

类型至少区分 `dialog`、`bottom-sheet`、`drawer`、`popup`、`toast/snackbar`、`tooltip`。记录 scrim、点击外部、返回键/手势和重复打开行为。

## 5. Page × State Matrix

| page_id | state_id | 入口/前置 | Trigger | Result | 可见层/组件 | 可操作目标 | reset | status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `search` | `empty` | fresh launch | open search | empty search | header, input | input, back | reload | verified |

必须记录 default、selected/unselected、enabled/disabled、focus/filled/validation、empty/populated、loading/success/error、expanded/collapsed、Overlay、导航/back、timer/async 等原型实际暴露的状态。一个页面可以对应多个状态；无法达到或断言的状态要写 `needs_review` 或 `blocked`，不能删除。

## 6. Interaction Evidence

每个主要交互一行或一个小节：

| action_id | target | 操作 | 操作前状态 | 操作后状态 | route 改变 | overlay 改变 | 局部 UI 改变 | 断言/证据 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `search-submit` | `search-submit` | 输入 `abc` 并提交 | `search/filled` | `search/result` | no | no | result list | DOM + screenshot |

必须记录目标的稳定 selector/accessible name/`data-*` 或等价定位依据。坐标点击只能是已记录的 fallback，并说明为何无法语义定位。

## 7. Prototype Measurement Context

至少记录：

```text
viewport_width_css:
viewport_height_css:
device_pixel_ratio:
browser_zoom:
css_scale_or_transform:
prototype_design_baseline:
comparison_surface_selector:
comparison_surface_rect:
prototype_shell_selector_and_rect: optional diagnostic only
flutter_validation_logical_size:
text_scale:
safe_area_strategy:
```

所有尺寸要标明单位。CSS viewport、device pixel 和 Flutter logical pixel 不可混写。

## 8. Exploration Gate checklist

- [ ] 每个可发现页面从 reset 进入过
- [ ] 主要按钮、列表、表单控件至少操作一次
- [ ] 所有 Tab/Bottom Navigation 已切换
- [ ] 所有 Dialog/BottomSheet/Drawer/Popup 已打开和关闭
- [ ] 空/有数据、加载、成功、错误和禁用等实际存在状态已记录
- [ ] 路由、返回栈和 Overlay 没有被页面数量替代
- [ ] 每条证据都有操作前后状态和可重复 reset
- [ ] 无法确认的内容显式标记 `UNRESOLVED` / `blocked`

只有这张清单闭合后才允许进入 Flutter 样式或页面实现。
