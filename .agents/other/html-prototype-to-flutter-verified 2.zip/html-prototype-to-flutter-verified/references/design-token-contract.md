# Design Token Contract

## 1. Measurement protocol

在 live prototype 中测量，而不是从截图目测。每个视觉基准至少保留：

- `window.innerWidth` / `window.innerHeight`
- `document.documentElement.clientWidth` / `clientHeight`
- `devicePixelRatio`、browser zoom、CSS transform/scale
- content surface 的 `getBoundingClientRect()`、计算后的 `display`/`visibility`/`opacity`/`overflow`
- 关键元素的 rect、computed style、字体加载状态和资源来源

如果要使用固定基准（例如 `390 × 844`），先证明它是 live CSS viewport 和 content surface 的真实尺寸。浏览器控制 API 传入的宽高、宿主截图尺寸、浏览器面板尺寸和外层 phone shell 都不是 CSS viewport 证据。

### Phone shell boundary

把以下四个概念分开：

```text
target_css_viewport
prototype_shell                 # 可选的审查/展示外框，仅诊断
prototype_content_surface       # HTML 产品内容和比较根
native_flutter_logical_surface  # Flutter app-root 归一化比较根
```

shell 的边框、阴影、圆角、宿主留白和 device background 默认不得进入 Token 或 Flutter Widget。只有 live prototype 明确证明它是产品自己绘制的内容，才能纳入合约。不能测出独立 content surface 时，状态为 `blocked`。

## 2. Computed-style baseline

对每个必需 `page_id/state_id/viewport_id` 的可见 style-bearing element，冻结：

### Typography

`font-family`、实际加载文件、numeric `font-weight`、`font-size`、`line-height`、`letter-spacing`、`text-decoration`、`text-transform`、`white-space`、`overflow`、`text-align`、最大行数和 baseline 观察。

### Color / shape

文本、背景、surface、border、icon、disabled、semantic color、opacity、radius、border width、divider、shadow 的 offset/blur/spread/opacity。

### Layout

页面左右 padding、section gap、card/list spacing、item/control/navigation 高度、`gap`、`padding`、`margin`、min/max constraint、aspect ratio、safe-area 相关几何。

禁止把一个浏览器浮点结果直接当成独立设计值。对 `15.98 / 16 / 16.02` 先说明它来自浮点、transform、rem/em、百分比还是不同组件设计；只有同语义且原因相同才能聚类。

## 3. 三层映射

`design_token_audit.md` 要把每个观察映射到以下层级之一：

```text
Primitive:  space4, space8, radiusSm, fontSizeBody, colorNeutral900
Semantic:   textPrimary, surfacePrimary, pageHorizontalPadding,
            sectionGap, titleStyle, bodyStyle
Component:  primaryButtonHeight, primaryButtonRadius, cardPadding,
            navigationTitleStyle, bottomNavigationHeight
```

合并条件是“同值 + 同语义 + 同行为契约”，不是“数值相近”。不同页面若语义相同，必须共用 Semantic/Component Token；确实不同的设计值保留不同 Token 并说明原因。

## 4. `design_tokens.dart` 约束

项目已有主题系统时扩展它，不另起一套平行主题。至少提供与项目架构相容的：

```dart
abstract final class AppTypography {}
abstract final class AppSpacing {}
abstract final class AppColors {}
abstract final class AppRadius {}
abstract final class AppShadows {}
abstract final class AppSizes {}
abstract final class AppComponentTokens {}
```

类名可按项目约定调整，但页面不得直接声明重复的字号、字重、line height、letter spacing、padding、gap、radius、color 或 shadow。真正无法公共化的局部值必须是有原因、有范围的 exception，并在审计中链接到原型证据；不能用 `token_17_6` 伪装成设计系统。

## 5. 字体和文本 Gate

- 检查项目中字体文件是否真实存在并被加载。
- 从 Computed Style 读取解析后的 numeric CSS `font-weight`；`normal`、`bold`、`lighter`、`bolder` 等关键字必须先解析为实际数值再映射。
- 字重映射顺序必须固定：
  1. Flutter 当前加载的字体能精确表达原型数值时，保留精确值；variable font 支持对应 `wght` 数值时，记录并使用该数值。
  2. 没有精确对应值时，从项目实际可用的离散 Flutter 字重集合中选择“所有 `availableWeight <= sourceWeight` 值中的最大值”，即向下取最近字重；例如 `850 → 800`、`750 → 700`、`550 → 500`。不能四舍五入到 `900`，也不能因为 `900` 数值更近而向上取值。
  3. 没有任何不大于原型字重的可用字重时，标记为 `UNRESOLVED` / `blocked`，不能静默向上替代。
- `design_token_audit.md` 必须记录每个非精确映射的 `sourceWeight`、`targetWeight`、可用字重集合、字体文件/字体轴和降级原因。Flutter 标准 `FontWeight` 没有 `w850` 时，`850 → w800` 只是该规则下的离散字重映射，不得写成不存在的 `FontWeight.w850`。
- 重要文本逐一验证单/多行、wrap、`maxLines`、ellipsis、alignment、line height、letter spacing 和 baseline。
- 字符宽度或换行不同先排查字体 fallback、真实 font file、weight、line height 和 letter spacing，不能先改 padding 或页面宽度。
- 固定 text scale 用于视觉验收；不要在正式代码中无理由锁死无障碍字体缩放。

## 6. SafeArea Gate

在审计中写出：status bar、Dynamic Island/notch、Android status/navigation bar、Home Indicator 是系统负责还是 prototype content 自己绘制；Flutter 是否使用 `SafeArea`、view padding 或自绘系统区域；top/bottom 是否只计算一次。原型若已自绘安全区，Flutter 不得再叠一层同语义 padding。

## 7. Raw-style audit

在截图前扫描所有 parity Flutter 文件，至少检查 raw `fontSize`、`fontWeight`、颜色、`EdgeInsets`、gap、固定 spacing、radius、border、shadow、opacity、min/max constraint，以及全局 `screenWidth/designWidth` 缩放表达式。除 Token 定义文件外，剩余 literal 必须：

1. 改为现有 Primitive/Semantic/Component Token；或
2. 写入有原型证据、范围明确的 exception，并在 `design_token_audit.md` 说明。

审计通过不等于视觉通过；它只是防止把全局问题分散到每个页面。
