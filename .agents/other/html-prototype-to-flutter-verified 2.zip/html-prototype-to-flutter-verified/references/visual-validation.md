# Native Visual Validation Contract

## 1. Surface and viewport rules

原型截图和 Flutter 截图必须对应同一个逻辑 app surface。以原型真实测量的设计基准作为默认 profile；例如原型确实测得 `390 × 844`，才使用 `390 × 844` 作为 CSS/content baseline。

不要比较：

- 浏览器宿主/工具栏截图 vs Flutter app-root
- 外层 phone shell vs Flutter 页面
- 完整物理设备截图 vs CSS pixel reference
- 不同 viewport、字体或 text scale 的截图

每个 reference 和 native capture 记录：CSS viewport、content root rect、物理截图尺寸、device pixel ratio、Flutter logical size、safe-area insets、app-root bounds、safe-area owner、capture method 和文件路径。保留 raw device/browser capture 在 `diagnostics/`，比较目录只放归一化 content/app-root 图。

## 2. Golden State Set

从 `Page × State Matrix` 生成稳定文件名，例如：

```text
Home_Default.png
Home_MenuOpened.png
Search_Empty.png
Search_Result.png
Profile_Guest.png
Subscribe_Selected.png
Dialog_Opened.png
```

每张图必须有可重复 reset、操作路径、断言和对应 prototype/Flutter 截图。首屏截图只能证明首屏外观，不能证明交互或状态覆盖。

## 3. 原型参考捕获

1. 从声明的 reset 开始。
2. 校准并实测 live CSS viewport 和 content surface。
3. 操作场景，等待明确的动画/异步条件。
4. 断言 route、active layer、文本、enabled/focus 和预期状态。
5. 只捕获声明的 content surface；不能直接证明 selector capture 返回的是该元素时，使用“即时测量矩形 + bitmap scale”的可审计裁切。
6. 把 viewport calibration、capture proof、运行时错误和失败原因写入证据。

原型 capture 不能通过改 HTML、隐藏 shell、猜 crop 或把宿主截图缩放到目标尺寸来“修正”。无法证明 content surface 的截图只能放 `diagnostics/`，不能放入 Golden State。

## 4. Flutter 原生回放

使用 iOS simulator/device 和 Android emulator/device 的原生测试或项目现有 driver，按同一组 scenario、reset、等待条件、状态 ID 和文件名回放。Flutter Web、desktop Flutter、浏览器驱动 Flutter 只能作为开发辅助，不能作为本 Skill 的原生 parity 证据。

每个平台都要：

- 运行 `flutter analyze` 和相关测试；
- 在声明的原生设备上执行交互场景；
- 断言当前 route/root marker 和 session 状态；
- 保存 raw physical frame 和 normalized app-root capture；
- 记录无法运行的设备、权限、签名或系统差异。

缺少任一目标平台时，平台状态为 `blocked` / `needs_review`，整体不得 `PASS`。

## 5. Diff 分类和修复闭环

逐状态检查整体结构、X/Y 对齐、宽高、字体 family/size/weight/line height/letter spacing/baseline、颜色、圆角、阴影、图标、图片 crop、padding、gap、SafeArea、clipping 和 overflow。使用确定性像素 diff 或等价指标辅助定位，但阈值只是 triage，不是完成证明。

统一使用以下分类：

- `TokenMismatch`
- `TypographyMismatch`
- `LayoutMismatch`
- `AssetMismatch`
- `StateMismatch`
- `SafeAreaMismatch`
- `PlatformRenderingDifference`

修复优先级：

```text
Global Token
→ Semantic Token
→ Component Token
→ Public Widget
→ Page Layout
→ documented local exception
```

例如多个页面标题都偏小，应修 `titleStyle` 或字体加载，而不是给每个页面加偏移。每轮都保留：问题、分类、根因、修复文件/Token、重新截图路径、结果和是否仍有已解释的 platform difference。

## 6. `visual_validation.md` 最低字段

| state | platform | viewport | prototype capture | Flutter capture | diff | category | root cause | fix | status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `home/default` | iOS | `390x844` logical | link | link | link | `TokenMismatch` | title token | `AppTypography.title` | PASS |

文档末尾必须有：覆盖统计、未解释差异、平台限制、修复轮次和最终状态 `PASS` / `PASS_WITH_KNOWN_DEVIATIONS` / `INCOMPLETE` / `BLOCKED`。`PASS_WITH_KNOWN_DEVIATIONS` 只能用于已记录且确认为 `PlatformRenderingDifference` 的差异，不能隐藏状态缺失、Token 漂移或错误截图。
