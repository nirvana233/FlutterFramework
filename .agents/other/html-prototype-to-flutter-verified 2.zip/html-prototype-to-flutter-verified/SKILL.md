---
name: html-prototype-to-flutter-verified
description: Rebuild a runnable HTML prototype as verified native Flutter iOS and Android UI by freezing page, state, route, viewport, and design-token contracts, then replaying interactions and normalized screenshot diffs. Use for high-fidelity mobile parity; not for mock-only UI or Flutter Web/Desktop.
---

# HTML 高保真原型 → Flutter 移动端高保真还原

## 适用范围

目标平台只有 iOS 手机和 Android 手机；不把 Web、Desktop、Tablet 或横屏作为验收平台。HTML 原型是行为和视觉的唯一事实来源。已有 Flutter 架构、用户未提交改动和项目约定必须保留。

这个 Skill 不是“看一张截图写页面”。验收单位是：

`page_id × state_id × viewport_id × platform`

其中 `state_id` 包含页面内的弹窗、抽屉、Tab、表单、加载、错误和选中状态。没有证据的状态必须标记为 `UNRESOLVED` / `needs_review` / `blocked`，不能靠经验补全。

## 不可跳过的总流程

严格按下面顺序执行，前一阶段未过 Gate 不得进入下一阶段：

1. 探索并重置 HTML 原型
2. 建立页面、状态、路由和 Overlay 证据
3. 校准原型 Measurement Context，并扫描 DOM/CSS/Computed Style/字体
4. 建立 Primitive → Semantic → Component 三层 Design Token
5. 先做 Global Theme 和公共组件，再做页面、状态、路由和 Overlay
6. 按证据回放 Flutter 交互
7. 在固定逻辑 viewport 下生成 Prototype / Flutter Golden State 截图
8. 分类 Diff，定位根因，修复后重新截图和验证
9. 只有全部验收 Gate 通过，才可报告 `PASS`

### 硬性停止条件

- 找不到真实可运行的 HTML 原型，或误把 Flutter `web/index.html` 当原型：`BLOCKED`。
- 没有完成页面/状态探索、Measurement Context 或字体/Computed Style 证据：不得写 Flutter UI。
- 不能证明 iOS 和 Android 的原生回放与截图：整体不能 `PASS`。
- 发现 Diff 但没有完成“截图 → 分类 → 定位 → 修复 → 重新截图 → 再 Diff”：整体保持 `INCOMPLETE`。

## 0. 建立运行边界和证据目录

先确认：原型根目录、Flutter 项目根目录、目标 iOS/Android 设备或模拟器、原型设计基准 viewport、locale/theme、字体、可重复的测试数据和 reset 方法。原型若被 `file://` 策略阻挡，只通过 localhost 暴露原型目录，例如：

```bash
python3 -m http.server 8765 --directory "/path/to/prototype"
```

不要为了启动原型暴露 home 或整个 workspace。建议把运行证据放在 Flutter 项目的 `.ui-parity/<run-id>/`，并保持源代码与证据分开：

```text
.ui-parity/<run-id>/
  prototype_evidence.md
  design_token_audit.md
  interaction_validation.md
  visual_validation.md
  scenarios.json                         # 可选的机器可回放契约
  viewport-calibration.json
  computed-style-snapshots.json
  reference/                             # HTML 内容面截图
  flutter/ios/                           # 归一化后的 Flutter app-root 截图
  flutter/android/
  diff/
```

`design_tokens.dart` 必须放在 Flutter 现有的 theme/design-system 源码层（或项目约定的位置），报告中链接它；不要把可编译源码只放在证据目录里。

## 1. 原型探索 Gate：先冻结行为

从干净 reset 开始，真实操作所有可发现的交互元素。至少覆盖：路由跳转与返回、Tab/Bottom Navigation、按钮和列表项、Checkbox/Radio/Switch/Slider、输入/键盘/搜索/筛选、展开收起、Dropdown/Popup、Dialog、BottomSheet、Drawer、Toast/Snackbar、Tooltip、Loading/Empty/Error/Success/Disabled/Selected/Focus、滚动、横向滚动、图片状态、表单校验、异步和返回行为。

每个元素至少尝试一次；存在多个可达状态时遍历全部状态。不要把 URL 数量当页面数量，也不要把隐藏 DOM 节点直接当成已验证状态。记录操作前后：route、可见层、DOM/无障碍树、文本、enabled/focus、class/data 变化和 reset 方法。

阶段产物必须先写 `prototype_evidence.md`，结构见 [evidence-contract.md](references/evidence-contract.md)，至少包括：

- Page Inventory
- `Page × State × Trigger × Result` State Matrix
- Route Graph
- Overlay Graph（Dialog / BottomSheet / Drawer / Popup / Toast 独立记录）
- Interaction Evidence
- Prototype Measurement Context
- SafeArea Strategy

### 原型探索完成 Gate

只有在全部可发现页面、主要控件、Tab、Dialog、BottomSheet、Drawer 和可达状态都有证据，且 Route Graph、Overlay Graph、State Matrix 已建立时，才进入样式测量。无法完成的项必须明确写出原因和 `blocked` / `UNRESOLVED`，不能静默跳过。

## 2. Measurement Context 和 Design Token Gate

### 2.1 先测量，再映射

不要把 HTML `font-size: 16px` 机械映射成 Flutter `fontSize: 16`。记录并在报告中保留：

- `viewportWidth` / `viewportHeight`
- `devicePixelRatio`
- browser zoom
- CSS `scale` / `transform`
- 原型设计基准尺寸
- Flutter 验证尺寸和物理设备尺寸
- CSS viewport、device pixel、Flutter logical pixel 的换算关系

如果存在外层 `.phone` / device shell，分别测量 shell 和真正的 app content surface。默认只实现和比较 content surface；外框、阴影、壳体、宿主留白不属于 Flutter UI，除非原型证据证明它是产品自身渲染的内容。无法从 DOM 测出独立 content surface 时，标记 `BLOCKED`，不要通过目测裁图或复制 shell 尺寸解决。

扫描整个原型的 DOM、CSS、CSS variables、Computed Style、字体加载和资源尺寸。对每个必需 page/state/viewport 的可见 style-bearing element 记录字体、颜色、间距、形状、边框、阴影、透明度和几何约束。近似值必须先判断是浏览器计算误差还是不同设计值，再决定合并或保留。

### 2.2 三层 Token

生成 `design_token_audit.md`，并据此实现 `design_tokens.dart`：

- Primitive：`space4`、`space8`、`radiusMd`、`fontSizeBody` 等基础值
- Semantic：`textPrimary`、`surfacePrimary`、`pageHorizontalPadding`、`sectionGap`、`titleStyle` 等语义值
- Component：`primaryButtonHeight`、`cardPadding`、`navigationTitleStyle`、`bottomNavigationHeight` 等组件契约

禁止把每个孤立数字包装成伪 Token（例如 `padding17_6`）。页面和公共 Widget 优先引用 Semantic / Component Token；发现新视觉值时，先判断它是否应成为 Token，并把例外写入审计。`design_token_audit.md` 必须包含扫描值、重复统计、聚类判断、Primitive → Semantic → Component 映射、异常值和未解决项。

字体必须检查实际文件和 Computed Style 的 numeric `font-weight` 映射，不能用“看起来接近”的字体或字重替代而不说明。先判断项目当前加载的字体是否能精确表达原型字重：variable font 若支持对应的 `wght` 数值，可保留原值；如果 Flutter 没有对应的离散字重，则从项目实际可用的字重中选择不大于原型值的最近一个（向下取最近），例如 `850 → 800`、`750 → 700`、`550 → 500`，禁止四舍五入或向上取值。每次降级都必须在 `design_token_audit.md` 记录 `sourceWeight`、`targetWeight`、可用字重集合和降级原因；没有可用的向下字重时标记为 `UNRESOLVED` / `blocked`，不能静默向上替代。重要文本还要冻结单/多行、`maxLines`、overflow/ellipsis、softWrap、alignment、line height、letter spacing 和 baseline。

SafeArea 必须写清楚 top/bottom 是系统处理还是原型自己绘制，viewport 是否包含 status bar、Dynamic Island/notch、Android status/navigation bar 和 Home Indicator。避免重复 SafeArea 或重复底部 padding。视觉环境固定 text scale；正式产品代码不得为截图而永久破坏无障碍字体缩放。

详细字段和审计格式见 [design-token-contract.md](references/design-token-contract.md)。

## 3. Flutter 实现顺序和实现边界

按以下顺序实现：

1. `design_tokens.dart` 和 Global Theme
2. 视觉语义与行为都重复的公共 Widget
3. 页面结构和布局约束
4. Page State、路由和返回策略
5. Dialog / BottomSheet / Drawer / Popup / Toast 等 Overlay
6. 表单、异步、Loading/Error/Empty/Success 和资源状态
7. 稳定的 `Key` / `Semantics`，与证据中的目标一一对应

遵守现有 Flutter 架构；网络、存储、状态管理等边界按项目规则处理。布局优先使用 `Row`、`Column`、`Flex`、`Wrap`、`Padding`、`SizedBox`、`Spacer`、`Align`、`Expanded`、`Flexible`、`Stack` 和约束系统。组件之间优先表达为统一的 Gap/Spacing Token，不要用层层 margin 互相抵消。

相同视觉语义且行为相同的控件应公共化；明显不同的控件保留明确 Variant，禁止为了复用制造巨型 Widget。每个页面顶部加 `Prototype: <Page> / <State>` 注释，复杂组件加 `Prototype State` 注释，便于回放和 Diff 定位。

图片和 Icon 优先复用原型真实资源、SVG 或指定 Icon Font；使用 Flutter Icon 前必须证明形状一致。对每个图片状态检查 `fit`、crop、alignment、aspectRatio、radius 和 clipping。原型中的 Hover 若只是桌面展示态，不作为手机核心状态；只有它实际表达移动端的 highlight/pressed 语义时才映射到 Flutter。

禁止：

- 页面内重复声明同语义的 `fontSize`、`fontWeight`、`letterSpacing`、`lineHeight`、padding、gap、radius、color
- `screenWidth / designWidth` 后全局缩放字号、间距、圆角或阴影
- 用大量 `Positioned`、`Transform.translate`、固定坐标或截图坐标“修图”
- 用相似 Icon、截图背景或空操作替代原型真实资源/行为
- 把 Dialog、BottomSheet、Drawer 降级为普通 Page Route
- 因 Flutter 默认行为不同而擅自改变原型的路由、状态或交互

固定视觉值放到 Token；真正的局部响应式规则必须能由 CSS/多 viewport 证据证明，并记录为 named rule。不要用全局缩放掩盖字体、SafeArea 或约束问题。

## 4. 功能验收 Gate

实现后按照 `prototype_evidence.md` 逐条回放 Flutter：

`Prototype Action → Flutter Action → Expected State`

生成 `interaction_validation.md`，每条记录原型行为、Flutter 行为、路由/Overlay 结果、PASS/FAIL、修复记录和证据路径。必须覆盖 push、pop、replace、tab switch、nested navigation（若原型存在）、Dialog、BottomSheet、Drawer、表单校验、返回/关闭和状态切换。任何 FAIL 都禁止进入视觉最终验收；不能操作或断言的项保持 `INCOMPLETE` / `BLOCKED`。

## 5. 原生视觉验收 Gate

视觉验收固定在原型设计基准逻辑 viewport；原型和 Flutter 必须使用同一逻辑 app surface、locale、theme、字体可用性、text scale 和确定性数据。不要直接把完整物理设备截图与 CSS 截图做 Diff：保留物理截图作诊断，另将 Flutter app-root 归一化到逻辑 surface；系统 chrome 只有在不属于原型合同时才裁掉。

Golden State Set 必须来自 State Matrix，而不是只截默认首页。至少覆盖所有关键页面、路由、Overlay、表单分支、空/有数据、Loading/Success/Error、选中/禁用/Focus 等真实可达状态。iOS 和 Android 都要回放并保存归一化截图；只能运行一端时，报告为平台覆盖不足，不得整体 `PASS`。

对每个状态执行：

```text
Prototype screenshot
  → Flutter iOS/Android screenshot
  → dimensions / structure / typography / asset / SafeArea checks
  → classify Diff
  → locate root cause
  → fix Token/semantic/component/widget/page
  → recapture
  → re-diff
```

差异优先分类为 `TokenMismatch`、`TypographyMismatch`、`LayoutMismatch`、`AssetMismatch`、`StateMismatch`、`SafeAreaMismatch`、`PlatformRenderingDifference`。修复顺序是 Global Token → Semantic Token → Component Token → Public Widget → Page Layout → 明确记录的 Local Exception；多个页面同时出错时禁止逐页打补丁。详细截图面边界、平台证据和报告字段见 [visual-validation.md](references/visual-validation.md)。

## 最终交付和状态

必须按以下顺序提供或链接：

1. `prototype_evidence.md`
2. `design_token_audit.md`
3. `design_tokens.dart`
4. 公共组件
5. Flutter 页面及其 `Prototype Page / State` 注释
6. `interaction_validation.md`
7. `visual_validation.md`

最终自检至少确认：原型页面/状态/路由/Overlay 全覆盖；三层 Token 和字体证据齐全；页面无重复样式和截图作弊；公共组件状态齐全；iOS/Android 原生回放齐全；Golden State 全部有配对截图；所有 Diff 已分类并重新验证。

只有以下条件全部为 `PASS` 才能宣布完成：

`Interaction Coverage`、`Route Validation`、`State Coverage`、`Design Token Audit`、`Flutter Analyze`、`Visual Golden State Validation`、`No Unexplained Major Diff`。

否则最终状态必须是 `INCOMPLETE` 或 `BLOCKED`，并列出剩余证据、根因和下一步；不能用“看起来像”代替验证。
